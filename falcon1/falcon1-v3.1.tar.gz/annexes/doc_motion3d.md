# ANNEXE DOC — MOTION DESIGN 3D ADAPTÉ AU SUJET (étape R2.8)

## 1. Construire l'univers 3D de la vidéo (avant le premier draw_motion)
Écris ces 6 lignes dans save_edit_plan. Tous les motions de la vidéo en découlent :
1. **Matière dominante** : tirée du sujet (voir la matrice). Elle sert aux cartes, aux sols, aux plaques et aux textes extrudés.
2. **Objets-symboles** : 1 à 3 objets du sujet, modélisés pour CETTE vidéo (CSS 3D ou Blender). L'un d'eux est le motif signature.
3. **Décor récurrent** : le « lieu » 3D où vivent les explications (bureau d'enquêteur, salle d'archives, arène, cockpit, carte en relief…).
4. **Lumière** : celle de la bible (I1 à I6), traduite en direction, température, halo et reflets fixes.
5. **Caméra** : celle de la bible (G1 à G6), traduite en perspective, amplitude, vitesse et courbe fixes.
6. **Styles tirés** (3 ou 4 parmi M1 à M12) : chacun est décliné DANS cet univers. Exemple : une data 3D en true crime devient des barres en dossiers empilés, pas des barres génériques.

Si le sujet ne figure pas dans la matrice, applique la même méthode : quels matériaux, objets, lieux et sons sont propres à ce sujet ?

## 2. Matrice univers → monde 3D
| Univers | Matières | Objets-symboles | Décor récurrent | Styles naturels | Pièges à éviter |
|---|---|---|---|---|---|
| histoire | marbre, parchemin, bronze, carte ancienne | sceau, plume, couronne, astrolabe | salle d'archives, table de cartographe | frise M3, carte M2, parallaxe M1 | néon, HUD ; anachronismes d'objets |
| guerre | acier, béton, toile, papier militaire | casque, carte d'état-major, télégramme | table de commandement avec carte en relief | carte M2, diorama M7, silhouettes M9 | esthétisation de la violence, gros plans gratuits |
| true_crime | papier kraft, liège, métal de classeur, film photo | dossier, épingle et fil rouge, clé, polaroïd | mur d'enquête, salle d'interrogatoire | mur M6, silhouettes M9, pièce M8 | sensationnalisme, victime montrée ; reconstitution non signalée |
| celebrites | papier glacé, verre, velours, flashs | trophée, micro, couverture de magazine, pass | studio photo, scène, tapis rouge | parallaxe M1, pièce M8, texte M10 | ressemblance 3D d'une personne réelle ; rumeurs présentées comme faits |
| gaming | voxels, pixels, plastique de manette, écran CRT | manette, cartouche, HUD, curseur | salle d'arcade, menu de jeu en 3D | pièce M8, simulation M11, texte M10 | logos et assets de jeux sans droit ; trop de glitch |
| arts_martiaux | bois de dojo, papier de riz, encre, cuir | ceinture, gants, tatami, gong | dojo, octogone, cercle de lumière | silhouettes M9 (gestes décomposés), forces M11, parallaxe M1 | caricature culturelle ; violence complaisante |
| sport | gazon, parquet, chrono LED, métal de trophée | ballon, chrono, podium, maillot | stade miniature, tableau d'affichage | data M5, silhouettes M9, parallaxe M1 | logos de ligues ; stats non sourcées |
| science_espace | verre de labo, titane, plasma, lumière froide | planète, molécule, satellite, instrument | laboratoire ou orbite | vue éclatée M4, simulation M11, globe M2 | fausse précision scientifique ; échelles trompeuses non signalées |
| nature | pierre, eau, bois vivant, terre | arbre, goutte, cristal, empreinte | relief topographique, coupe de terrain | globe M2, diorama M7, simulation M11 | images de synthèse prises pour des documents |
| business | verre de tour, papier financier, or, acier brossé | logo stylisé (non officiel), graphique, signature, pièce | salle de conseil, skyline miniature | data M5, objets M12, pièce M8 | chiffres sans source ; logos officiels détournés |
| tech | aluminium, silicium, verre, lumière LED | puce, câble, smartphone générique, code | salle serveurs, établi d'électronique | vue éclatée M4, pièce M8, data M5 | marques reconnaissables sans contexte |
| automobile | acier, carbone, caoutchouc, huile | piston, clé, compteur, plaque | garage, coupe moteur | vue éclatée M4, flux M11, data M5 | mauvaise pièce montrée |
| mysteres | pierre ancienne, brume, papier jauni | symbole, lanterne, carte annotée | forêt brumeuse, crypte, carte nocturne | mur M6, carte M2, silhouettes M9 | présenter une hypothèse comme un fait |
| culture_musique | vinyle, bois d'instrument, néon de club, papier d'affiche | platine, instrument, ticket, affiche | studio d'enregistrement, scène | pièce M8, parallaxe M1, objets M12 | morceaux existants (jamais de musique tierce) |
| societe | béton, papier journal, verre urbain | bulletin, pancarte, carte d'identité stylisée | rue miniature, salle de presse | data M5, texte M10, parallaxe M1 | stéréotypes ; données non sourcées |

## 3. Recettes des 12 styles (toujours dans l'univers)
- **M1 Parallaxe 2.5D** :
  1. Détourer le sujet (rembg sur la machine Cowork).
  2. Préparer le fond : même photo, sujet effacé, agrandie à 110 %.
  3. Monter dans hf.custom : fond en translateZ -300px + flou 2 à 4 px ; sujet en Z 0 + ombre ; particules en Z ; caméra de la bible.
  Durée 3 à 7 s.
- **M2 Globe / cartes en relief** : relief en couches (lignes topographiques extrudées) ; épingles et trajets tracés (stroke-dashoffset) sur chaque mot de lieu ; vol de caméra vers le lieu. 4 à 10 s.
- **M3 Frise monumentale** : années en volume posées dans la matière de l'univers ; la caméra avance dans le temps (translateX + dolly) ; chaque date apparaît sur son mot.
- **M4 Vue éclatée / coupe** : 3 à 6 couches qui s'écartent en Z sur le mot clé, avec étiquettes reliées par des lignes.
- **M5 Data 3D** : barres, jauges et compteurs en volume, faits de la matière de l'univers. Source en petit. Les chiffres comptent jusqu'à la valeur sur le mot.
- **M6 Mur de documents** : documents et photos en profondeur. Le fil ou la ligne se trace entre deux éléments au moment où la voix fait le lien. La caméra glisse d'un indice à l'autre.
- **M7 Diorama** : maquette isométrique du lieu ; lumière du moment (jour ou nuit) ; éléments qui s'allument sur les mots.
- **M8 Pièce 3D avec écrans** : bureau, studio, salle de contrôle ; les écrans montrent les archives ; la caméra passe d'un écran à l'autre (idéal pour une transition continue).
- **M9 Silhouettes stylisées** : mannequins ou silhouettes lisses, sans visage ressemblant, pour reconstituer des positions et des trajectoires. Mention « Reconstitution » pendant tout le plan.
- **M10 Texte 3D dans l'image réelle** : texte extrudé posé en perspective sur la surface d'une archive (sol, mur), avec l'ombre et l'étalonnage de la scène.
- **M11 Simulation stylisée** : flux, particules, forces, ondes ; calée sur les mots de mécanisme.
- **M12 Objets-symboles** : l'objet-clé tourne, s'ouvre, se fissure ou s'allume ; il porte la transition entre deux chapitres.

## 4. Technique hf.custom (voie par défaut, sans aucun fichier distant)
- **Scène** : `#stage{perspective:1400px;perspective-origin:50% 45%}`, `#world{transform-style:preserve-3d}`, tous les éléments placés en translateZ.
- **Caméra** : animer #world sur toute la durée, jamais immobile. Amplitudes selon la bible : G1 dolly de -200 à 0 ; G2 orbite ±25° ; G3 travelling X de 3 à 6 % ; G4 bruit 1 à 2 px ; G5 rotateX ±15° ; G6 zoom rapide puis lent. Ease sine.inOut ou none.
- **Texte extrudé** : 12 à 20 copies en translateZ -1 à -20 px, couleur du foncé au clair de la palette, face avant en primaire avec reflet.
- **Volumes** : cubes et plaques à 6 faces, cylindres de 12 à 24 faces, épaisseurs réelles.
- **Matière** : textures en CSS ou SVG (feTurbulence pour le bois, le papier ou la pierre ; dégradés pour le métal) ; grain et vignettage de la bible.
- **Lumière** :
  - I1 : dégradé chaud latéral sur fond noir ;
  - I2 : ombres douces ;
  - I3 : liseré clair en contre-jour ;
  - I4 : deux halos colorés de la palette ;
  - I5 : ombres longues ;
  - I6 : faisceaux et poussière.
  Dans tous les cas : spéculaire qui glisse pendant l'orbite, ombre au sol, reflet au sol à 15 %.
- **Profondeur de champ** : fond flou 4 à 10 px, avant-plan 2 à 4 px, sujet net ; particules réparties en Z.
- **Performance** : 150 éléments animés au maximum ; filtres lourds sur 3 calques au maximum ; tester avec un seconds court si le rendu échoue.

## 5. Blender (voie premium, si disponible sur la machine Cowork)
- Script bpy sans interface, Eevee 1920x1080 à 30 i/s, durée = durée exacte du plan.
- Lumière et caméra de la bible ; images clés aux at[] calculés sur get_timing.
- Dépôt avec wawie_upload_link.
- Usages : globe, maquettes, objets-symboles, cartes de chapitre, transitions continues d'un seul tenant.

## 6. Transitions 3D continues (2 à 5 par vidéo)
- Le motion sortant se termine sur un élément (écran, fenêtre, objet, carte) qui devient le premier plan du suivant.
- Il ne doit y avoir ni coupure ni changement de lumière.
- Son : un whoosh grave, ou le son du motif signature.

## 7. Calage (R6)
Exemple : plan de 512.40 à 519.20 s (seconds 6.80) ; « 1969 » 512.60, « Houston » 513.90, « trois hommes » 515.55, « quatre jours » 517.30 → at = [0.20, 1.50, 3.15, 4.90].
- L'année 3D (matière de l'univers) se pose.
- Le globe pivote et s'épingle sur Houston.
- Trois silhouettes M9 s'allument.
- Un compteur tourne jusqu'à « 4 jours ».
- La caméra de la bible avance en continu.
