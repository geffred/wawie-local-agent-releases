# ANNEXE DOC — SON CRÉÉ PAR LE CODE (étape R2.10)

Le fonctionnement général du moteur est le même que pour la niche automobile. Lire aussi `python3 -m falcon1 annexe son`, sections 2, 3 et 6 : les stems, le format de cues.json, le dépôt et le storyboard. Seules les différences sont décrites ici.

## cues.json documentaire
```json
{
 "niche": "doc",
 "total": 1312.4,
 "graine": "<graine du tirage>",
 "direction_musicale": "D8",
 "gamme": "hijaz",
 "pack_sfx": "S3",
 "timing": "timing.json",
 "actes": [
  {"start": 0, "end": 45.2, "mood": "tension", "intensite": 5},
  {"start": 45.2, "end": 260.0, "mood": "mystere", "intensite": 3},
  {"start": 260.0, "end": 330.5, "mood": "emotion", "intensite": 2},
  {"start": 330.5, "end": 1250.0, "mood": "climax", "intensite": 5},
  {"start": 1250.0, "end": 1312.4, "mood": "resolution", "intensite": 2}
 ],
 "silences": [{"at": 1102.35, "duree": 1.0, "style": "battement"}],
 "relances": [[402.1, 406.0]],
 "sfx": [{"son": "page_turn", "at": 12.40}, {"son": "stamp", "at": 30.05, "hero": true}],
 "ambiances": [{"lieu": "bureau", "start": 44.6, "end": 120.0}, {"lieu": "pluie", "start": 119.5, "end": 180.0}]
}
```
- **actes** : un acte musical par séquence de la courbe d'intensité. `intensite` (1 à 5) reprend le niveau de set_scene_plan ; l'humeur donne la couleur harmonique.
  - Humeurs : tension, sombre, mystere, emotion, climax, positif, resolution.
  - Les fondus entre actes (2 s) se font tout seuls. Place les changements d'acte sur les cartes de chapitre ou les transitions 3D.
- **silences** : style tiré → `style`. Q1s = "total" (musique et effets coupés), Q2s = "ambiance" (seule l'ambiance reste), Q3s = "battement" (battement sourd ajouté), Q4s = "note" (note tenue qui s'éteint).
  - `at` = premier mot de la révélation ; `duree` de 0.8 à 1.5 s, placée dans le silence de la voix qui précède.
  - L'image continue de bouger. Un impact (héros) sur le premier mot.
- **J-cut / L-cut** : fais commencer l'ambiance du lieu suivant 0.3 à 0.8 s avant la coupe (start = coupe − 0.5), ou finir l'ambiance précédente 0.5 s après. Les fondus d'1 s rendent le chevauchement naturel.

## Directions musicales (tirage)
| Id | Couleur | Moteur | Pour quels sujets |
|---|---|---|---|
| D1 | hybride orchestral/électronique cinématique | cordes, ostinato, taikos | histoire, science, épopées |
| D2 | dark ambient + pulsations | drone, sub, battements | true crime, mystères |
| D3 | piano et cordes émotionnels | piano + cordes, sans batterie | portraits, drames, hommages |
| D4 | percussions épiques | taikos et toms denses | guerre, sport, arts martiaux, conquêtes |
| D5 | électro minimaliste tendue | pulse, arpège | tech, business, enquêtes modernes |
| D6 | synthwave / rétro | arpèges 80's | gaming, culture des années 80-90, tech |
| D7 | textures industrielles et drones | métal, drones | industrie, catastrophes, guerre froide |
| D8 | couleur culturelle | drone + percussion sur cadre + motif modal | sujet ancré dans une culture |

**Gamme pour D8** (champ "gamme"), choisie selon le sujet et sans caricature : la couleur vient des intervalles, pas d'un cliché.
- `hijaz` : Méditerranée orientale, Moyen-Orient, Andalousie, flamenco.
- `japonaise` : Japon (arts martiaux japonais, histoire du Japon).
- `pentatonique` : Asie de l'Est (Chine, Corée), folklore, sujets lumineux.
- `pentatonique_mineure` : Afrique de l'Ouest, blues, Amériques.
- `dorienne` : monde celtique, Europe médiévale.
- `hongroise` : Europe centrale et de l'Est.
Si aucune ne convient au sujet : dorienne (neutre), et le dire dans le bilan.

## Packs (60 % des moments sonores)
| Pack | Sons |
|---|---|
| S1 cinéma | impact, sub_drop, riser, reverse_swell, braam, whoosh*, heartbeat, note_tenue, body_hit |
| S2 mécanique | ratchet, wrench_clink, lock_click, gear, clock_tick, blade_clash, impact_gun |
| S3 papier et bureau | page_turn, stamp, typewriter, pen_scribble, drawer, camera_shutter, projector, flash_photo, paper |
| S4 numérique | tick, hud_beep, scan, glitch, mouse_click, police_radio, ui_select, level_up |
| S5 organique | breath, wind_gust, water_splash, wood_knock, fire_whoosh, bell_toll, thunder, siren_far, applause |

## Sons par usage
- **Carte de chapitre** : impact (héros) + sub_drop, ou le son du motif signature (clock_tick pour un compte à rebours, stamp pour un dossier, bell_toll pour l'histoire).
- **Révélation interne** : tick, page_turn (document), camera_shutter (photo d'archive), pen_scribble (annotation), scan (data).
- **Transition 3D continue** : whoosh_deep ou breath ; **light leak / volet** : swoosh_soft ; **glitch** : glitch ; **pellicule** : projector.
- **Foley** sous les plans : typewriter, drawer, wood_knock, water_splash, fire_whoosh, blade_clash, body_hit, applause, flash_photo, ui_select.
- **Climax** : riser ("duree" 2-4 s, coupé net sur le mot) + impact.

## Ambiances par lieu (`lieu`)
- Documentaires : ville, foule, foret, mer, desert, pluie, orage, bureau, nuit, salle_vide.
- Hérités de la niche automobile : atelier, habitacle, autoroute, parking, garage_ferme, hiver, station_service.

## Contrôle
- Le rapport doit dire `problemes: []` (densité 6-14 par minute, part du pack, pas de répétition à moins de 4 s, pic sous -1 dBTP sur chaque stem).
- Dans le bilan : direction, gamme, BPM, nombre d'effets et de héros, LUFS des stems, silences posés.
