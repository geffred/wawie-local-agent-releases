# ANNEXE RÉFÉRENCE — mesures sur les 4 vidéos de référence (pour calibrer, ne pas copier plan pour plan)

| Vidéo | Durée | Plans | Moyenne | Médiane | Moyenne 0-30 s | Items | Item 1 |
|---|---|---|---|---|---|---|---|
| 13 Habits… 500k Miles | 1258 s | 324 | 3.88 s | 3.67 s | 2.55 s | 13 (≈ 90 s chacun) | 22 s |
| AC Blow Twice as Cold | 891 s | 276 | 3.22 s | 2.89 s | 1.97 s | 10 + mistakes (≈ 75 s) | 42 s |
| 17 Habits… 700k Miles | 1273 s | 386 | 3.29 s | 3.02 s | 1.87 s | 17 (≈ 70 s) | 34 s |
| Never Do In An Automatic | 908 s | 258 | 3.51 s | 3.00 s | 2.43 s | 15 (≈ 58 s) | 10 s |

- **Rythme** : moyenne globale 3.45 s ; accroche 2.2 s ; 30-90 s : 3.0 s ; corps 3.6 s.
- **Répartition des durées de plan** : <1 s 8.5 % ; 1-2 s 17.1 % ; 2-3 s 21.4 % ; 3-4 s 18.6 % ; 4-5 s 13.5 % ; 5-7 s 15 % ; 7-10 s 4.4 % ; 10-15 s 1.2 % ; >15 s 0.2 %.
- **Visuel** :
  - vidéo réelle 71 à 88 % du temps ;
  - images, schémas et captures animés environ 17 % ;
  - cartes et motion 3 à 5 % (v3 : 15 à 20 % voulus) ;
  - texte majuscule sur environ 24 % des images.
- **Transitions** : environ 40 % de coupes en 1 image, environ 16 % en 2-3 images, environ 44 % en 4-8 images (flash, light leak, whip pan, glitch).
- **Audio** :
  - LRA 3.2 à 4.4 LU ;
  - pauses entre phrases : médiane 130 à 235 ms, p90 320 à 406 ms ;
  - fond musical dans les pauses -45 à -50 dBFS RMS ;
  - voix 15 à 20 dB au-dessus de la musique ;
  - environ 10 à 15 % des coupes portent un whoosh ou un impact.
