# ANNEXE DOC — ARCHÉTYPES DE MONTAGE (étape R2.3)

L'archétype tiré fixe :
- la structure narrative ;
- le profil de rythme ;
- la grammaire visuelle ;
- la place du texte ;
- la nature des motions ;
- l'approche musicale.

Les autres dimensions s'y conforment. L'ordre des éléments d'un chapitre (carte → contexte → faits → extrait → émotion) varie selon l'archétype et d'un chapitre à l'autre.

| Id | Archétype | Structure | Moteur 3D | Ouverture | Fin | Actes musicaux conseillés |
|---|---|---|---|---|---|---|
| A1 | Le compte à rebours | heure par heure / jour par jour jusqu'au point de bascule | horloge et frise 3D omniprésentes ; carte C3 (compteur) naturelle | T-moins et l'heure exacte | l'instant décisif et ses conséquences | tension 4 → montée 4-5 → climax 5 → resolution 2 |
| A2 | L'enquête | question, indices, fausses pistes, réponse sourcée | mur d'indices et dossiers 3D | la question qui dérange | ce qu'on sait, ce qu'on ignore encore | mystere 3 → sombre 3 → climax 5 → resolution 2 |
| A3 | La grande fresque | des décennies ou des siècles, par époques | globe et cartes 3D, frise monumentale | vue de l'espace qui plonge vers le lieu | retour à l'échelle du monde | un acte par époque, intensité en vagues |
| A4 | Le portrait | une vie en chapitres, chacun autour d'un moment-clé | parallaxe 2.5D, album 3D | le moment le plus célèbre | l'héritage | emotion 2 / positif 3 alternés, climax au moment-clé |
| A5 | L'explication | du visible au caché, couche par couche | vues éclatées, coupes, simulations | le phénomène spectaculaire | la vue d'ensemble reconstruite | tension 4 → positif 3 → climax 4 → resolution 2 |
| A6 | Les deux camps | deux trajectoires en alternance jusqu'à la collision | écrans partagés en profondeur, double frise | le face-à-face | l'issue et le bilan | deux couleurs alternées (sombre / positif) → climax 5 |
| A7 | La chute | ascension, sommet, fissures, effondrement, leçons | courbes 3D qui montent puis s'effondrent, matières qui se fissurent | les ruines, puis « tout avait si bien commencé » | ce qu'il en reste | positif 4 → tension 3 → sombre 4 → climax 5 → emotion 2 |
| A8 | Les N clés | N moments, raisons ou secrets en crescendo | cartes numérotées 3D, progression | aperçu du n°1 | le n°1 et la synthèse | intensité croissante 3 → 5 |
| A9 | Le lieu | un lieu raconté par ce qui s'y est passé | maquette ou carte 3D du lieu, vols de caméra | survol nocturne du lieu | le lieu aujourd'hui | mystere 3 → époques → resolution 2 |
| A10 | Mythe ou réalité | croyances examinées, verdict sourcé | balance, tampons, mur de sources | la croyance la plus répandue | le bilan des verdicts | tension 3 avec relance à chaque verdict (silence + impact) |
| A11 | Le journal de bord | récit par documents d'époque | documents 3D, bureau, carnets | le premier document | le dernier document | emotion 2 / sombre 3, cartes C4 (texte tapé) naturelles |
| A12 | Le futur | tendances → scénarios publiés, présentés comme scénarios | données 3D, villes et objets stylisés | une projection chiffrée officielle | ce qui dépend de nous | tension 3 → positif 4 → resolution 3 |

## Structures d'ouverture tirées
- H1 : le moment le plus fort, puis retour en arrière.
- H2 : la question qui dérange.
- H3 : le chiffre choc sourcé.
- H4 : une scène racontée au présent.
- H5 : la citation réelle qui intrigue.
- H6 : le contraste avant/après.

Le premier plan doit être d'une nature différente de celle des 3 vidéos précédentes (archive, 3D, document, rush, carte). L'empreinte le vérifie.

## Profils de rythme tirés
| Profil | Durée moyenne des plans |
|---|---|
| R1 rafales permanentes | 2.2 à 2.6 s |
| R2 dynamique régulier | 2.6 à 3.0 s |
| R3 vagues fortes | 2.8 à 3.2 s |
| R4 crescendo | 2.8 à 3.4 s |
| R5 tendu et précis | 3.0 à 3.4 s |
