# ANNEXE DOC — REVUE, COHÉRENCE, EMPREINTE (étape R2.11)

## Revue plan par plan
Pour chaque plan, vérifier :
- L'image correspond-elle aux mots ?
- Y a-t-il au moins un événement toutes les 4 s ?
- Tout est-il conforme à la bible (couleurs, polices, lumière, caméra, courbes, matière) ?
- Le texte, les sous-titres et les révélations sont-ils sur leur mot ?
- Le son est-il complet : ambiance du lieu, foley, sons des motions ?
- Les passages sont-ils fluides (raccords, J/L-cuts) ?
- Les faits sont-ils sourcés, les reconstitutions signalées, et rien n'est-il choquant ?

## Contrôle de cohérence
- Échantillonner 1 image toutes les 20 s (inspect_video_range sur la timeline montée).
- Comparer à la bible : palette, typographie, lumière, grain, cadres, positions.
- Lister les écarts et les corriger avant l'empreinte.

## Empreinte : fichier empreinte.json
Les mesures se prennent sur get_timeline, une fois le montage final fait.
```json
{
 "duree_totale_s": 1312.4,
 "nb_actes": 5,
 "duree_moyenne_plans_s": 2.74,
 "evenements_par_minute": 23.5,
 "courbe_intensite": [5, 3, 2, 5, 2],
 "parts_pct": {"archives": 34, "rushs": 18, "documents": 9, "motions": 31, "motions_3D": 26},
 "transitions_pct": {"coupes": 64, "stylisees": 27, "transitions_3D": 9},
 "styles_motion": {"M2": 35, "M6": 30, "M9": 20, "M12": 15},
 "premier_plan": "3D",
 "type_fin": "ce qu'on ignore encore",
 "motif_signature": "épingle rouge et fil tendu ; tic d'horloge",
 "direction_musicale": "D2",
 "nb_partitions": 5
}
```
- `premier_plan` prend l'une de ces valeurs : archive, 3D, document, rush, carte.
- Commande : `python3 -m falcon1 empreinte --run-id <run_id> --fichier empreinte.json`.

L'outil compare l'empreinte à chacune des 3 vidéos précédentes du registre :

| Critère | Seuil à respecter |
|---|---|
| Archétype | différent |
| Durée moyenne des plans | écart ≥ 0.3 s, ou profil de rythme différent |
| Densité d'événements | écart ≥ 3 par minute, ou courbe d'intensité différente |
| Styles de motion | différents à 75 % |
| Répartition des transitions | écart ≥ 10 points sur au moins une catégorie |
| Actes ou durée | ± 1 acte, ou ± 2 min |
| Dimensions visuelles | ≥ 19 sur 26 différentes |
| Ouverture | structure ET nature du premier plan différentes |

- Code 0 : réussi. Code 2 : la liste `echecs` dit quoi changer. Modifier le montage (rythme, transitions, motions, ouverture), jamais seulement les couleurs, puis relancer.
- L'empreinte est enregistrée dans le registre : la vidéo suivante sera comparée à celle-ci.

## Checklist avant render_final
- R1 : valeur originale, exactitude et éthique respectées ; narration ≥ 85 %.
- Rythme selon le profil et la courbe ; aucun plan au-delà des maximums.
- Motion : 25 à 35 % du temps, ≥ 75 % en 3D, 2 à 5 transitions 3D continues, univers 3D du sujet respecté.
- Bible appliquée sans écart.
- Son : 6 couches, rapport `problemes: []`.
- Calage 0 / +0.1 s ; durées de lecture respectées.
- Empreinte réussie ; check_sync = 0 ; quality_check ≥ 80 (cible 90).

## Métriques cibles
| Métrique | Cible |
|---|---|
| Durée moyenne des plans | 2.4 à 3.4 s |
| Événements par minute | ≥ 20 |
| Narration | ≥ 85 % |
| Part de motion | 25 à 35 % |
| Part de motion 3D | ≥ 75 % des motions |
| Transitions 3D continues | 2 à 5 |
| Moments sonores par minute | 6 à 14 |
| Volume final | -14 LUFS (Wawie) |
