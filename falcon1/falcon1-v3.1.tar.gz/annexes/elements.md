# ANNEXE ÉLÉMENTS GRAPHIQUES, TRANSITIONS ET CADRE

Toutes les couleurs et polices viennent du tirage, avec ces jetons :
- couleurs : primaire, accent, alerte, argent, fond_motion, surbrillance_3D ;
- polices : titres, mots_cles, etiquettes.

Si une police manque dans le moteur, garder l'intention (condensée, géométrique, technique, italique) avec la pile de repli la plus proche. Tailles données pour du 1080p.

## Table mot → visuel
| La voix dit… | Visuel prioritaire | Secours |
|---|---|---|
| un nom de pièce | gros plan vidéo de la vraie pièce, ou rayons X avec la pièce surlignée | schéma annoté + mise en évidence |
| un geste d'entretien | mains en action, plan serré ou POV | tutoriel 9:16 sur fond flou |
| une situation de conduite | voiture en mouvement (travelling, drone, POV) | mains sur le volant |
| un kilométrage | gros plan de l'odomètre + flèche | voiture qui roule + étiquette « 300,000 MILES » |
| un coût | billets comptés, mécanicien | — (prix géant obligatoire en plus) |
| une panne | fumée, voyant moteur, voiture au bord de la route | pièce usée ou brûlée |
| une recommandation du constructeur | page du manuel en incrustation, ligne surlignée | main qui feuillette un manuel |
| un produit | capture de la fiche produit + prix géant | packshot |
| un mythe | personnage perplexe + « NOT TRUE » / « MYTH » couleur alerte | mécanicien qui secoue la tête |
| une comparaison A/B | split 50/50 (hf.split / hf.compare) | coupe rapide A → B (1.2 s chacun) |
| une durée, une température, un intervalle | visuel du contexte + mot clé géant | hf.bigStat |
| une statistique | parking ou bouchon + % | hf.bigStat / hf.chartBar |
| des étapes | vidéo de chaque étape + étiquette STEP N | hf.process / hf.checklist |

## Éléments (forme = style tiré, durées = règle R2)
- **Carte titre** (famille tirée C1 à C10) : 3.5 à 4.5 s. Elle commence 0.1 à 0.2 s avant que la voix dise le numéro. Numéro au format tiré, titre ≤ 22 caractères par ligne, texte identique à l'annonce. Entrée de la ligne 1 : opacité + y, 0.40 s, power3.out ; boîtes ou titre : scale 0.6 → 1, back.out(1.4), décalage 0.12 s ; sortie : fondu 0.30 s.
- **Mot clé géant** (style tiré K1 à K8) : police mots_cles, 90 à 140 px, 2 lignes au maximum (≤ 14 caractères par ligne). Couleur primaire pour une info, alerte pour un danger, argent pour un bon geste. Contour noir 6 à 8 px, ombre 70 %. Position au centre, ou au tiers bas (72 %) si le sujet est au centre. Variante mot par mot : chaque mot sur son début.
- **Prix** (style tiré $1 à $6) : 110 px, couleur argent, en bas au centre (78 %), 3 à 4 s, pop 0.30 s + petite secousse.
- **Étiquette** (style tiré E1 à E6) : police etiquettes 30 px, en bas à gauche (91 %), 3 à 4.5 s, glissement 0.35 s.
- **Mise en évidence** (style tiré X1 à X6) : 2.5 à 4 s ; tracé en 0.4 s ; pulsation 1 ↔ 1.1 toutes les 0.5 s.
- **Loupe** : même photo à 200 % dans un masque circulaire (35 à 40 % de la hauteur), contour blanc 4 px.
- **Pluie de billets** : 30 à 60 billets SVG en rotation, avec une profondeur par flou et par échelle, 2.5 à 4 s.
- **Bulle de pensée** : bulle blanche à contour noir avec « ? », pop 0.2 s + flottement ±8 px.
- **Split** : 50/50, séparation de 4 px, 4 à 8 s ; chaque annotation apparaît sur son mot.
- **Document** : fond = même image à 120 %, floutée 20 px et assombrie 20 % ; image au centre à 75 % de la hauteur, bordure blanche 6 px, ombre ; surlignage 40 % qui se déroule en 0.4 s sur la ligne citée ; 4 à 7 s.
- **Rush 9:16** : pré-composer en 16:9 avec ffmpeg (fond flouté du même rush), puis wawie_upload_link.
- **Schéma explicatif animé** (au moins 1 par item) : 6 à 15 s, révélations progressives sur chaque mot clé, état final tenu 0.6 à 1.0 s.
- **Bouton abonnement** (style tiré B1 à B5) : à 35-45 % de la durée, en bas au centre (81 %), 4 à 5 s.
- **Écran de fin** (mise en page tirée F1 à F4) : 20 s, la narration continue ; zone des éléments YouTube laissée libre.

## Transitions
- Coupe franche par défaut entre deux beats d'une même idée.
- Stylisées, prises dans le jeu tiré J1 à J6 :
  - flash : 0.25 à 0.40 s, environ 1 toutes les 30 à 45 s ;
  - light leak : 0.40 à 0.70 s, environ 1 toutes les 45 à 60 s ;
  - whip pan : 0.20 à 0.35 s ;
  - glitch : 0.30 à 0.60 s, cartes et mots chocs seulement ;
  - zoom traversant : 0.25 à 0.35 s, 1 par item au maximum ;
  - fondu : moins de 3 %.
- Accroche (0 à 30 s) : 30 à 40 % de transitions stylisées.
- Une transition est centrée sur le point de coupe, qui tombe dans un silence. Continuité de mouvement : même sens d'un plan à l'autre ; pas de zoom arrière brutal après un zoom avant.

## Cadre
- Ken Burns sur toute image fixe : zoom 100 → 110-115 %, ou l'inverse, ou pan de 4 à 6 % ; jamais deux fois le même mouvement de suite.
- Zoom lent sur les vidéos trop statiques : 100 → 106-108 %.
- Punch-in (100 → 120 %) sur un mot fort, 1 à 2 par item.
- Secousse de 0.3 à 0.5 s au maximum, 1 par item.
- Ralenti 50 à 70 % (liquides, étincelles) ; accéléré 120 à 150 % (atelier).
- Zoom de 130 % au maximum sur une source 1080p.

## Étalonnage
Le look est tiré (L1 à L6). Harmoniser l'exposition et la température dans une même séquence. Un rush terne se corrige avant dépôt (ffmpeg `eq=contrast=1.08:saturation=1.15`, unsharp léger), sinon on en choisit un autre. Teinte rouge ou noir et blanc ponctuels : 2 fois par vidéo au maximum.

## Gabarit d'un item (60 à 90 s)
| Temps | Contenu |
|---|---|
| 0 à 4 s | carte titre |
| 4 à 16 s | problème : 3 à 4 plans vidéo + 1 mot clé |
| 16 à 30 s | mécanisme : schéma 3D de 8 à 12 s |
| 30 à 36 s | 2 plans réels de la pièce |
| 36 à 46 s | conséquence : prix + billets ou bigStat, plan de panne, punch-in |
| 46 à 56 s | solution : geste + étiquette |
| 56 à 66 s | procédure ou comparaison (hf.process / hf.compare / manuel) |
| fin | plan de conduite apaisé → transition vers la carte suivante |

## Accroche (0 à 30 s)
- Plan le plus fort dans les 5 premières secondes, selon la structure tirée H1 à H6.
- Plans de 1.5 à 2.5 s ; 1 mot clé toutes les 4 à 6 s ; au moins 1 flash et 1 light leak.
- Carte de l'item 1 avant 40 s.
