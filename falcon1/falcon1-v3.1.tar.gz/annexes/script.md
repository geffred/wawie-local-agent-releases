# ANNEXE SCRIPT (seulement si le script n'est pas fourni)

Le script est le texte exact lu à voix haute, sans aucune indication de mise en scène. Viser 160 à 170 mots par minute, soit 2 400 à 3 400 mots.

## Structure
1. **Accroche** (10 à 40 s), selon la structure tirée H1 à H6 :
   - H1 : une statistique choc ;
   - H2 : un coût de réparation ;
   - H3 : un mythe démenti (« NOT TRUE ») ;
   - H4 : une scène de panne racontée à la 2e personne ;
   - H5 : un kilométrage record puis une promesse ;
   - H6 : une question directe.
   Elle porte une promesse chiffrée et un problème coûteux.
2. **Annonce** (5 à 15 s) : le nombre d'items et l'entrée en matière, avec une formule nouvelle à chaque vidéo.
3. **Items × N** (55 à 95 s chacun) :
   - numéro + titre court de 3 à 7 mots (= texte de la carte titre) ;
   - ce que les gens font ;
   - le mécanisme technique ;
   - la conséquence chiffrée ($, miles) ;
   - la solution chiffrée (intervalle, durée, température, prix) ;
   - une transition vers l'item suivant.
4. **Appel à l'abonnement** (4 à 6 s), à 35-45 % de la durée, après un item fort.
5. **Relance** (facultative) avant les derniers items (« Now here's the good news… »).
6. **Conclusion + renvoi** (20 à 30 s) : récap en 1 à 2 phrases, puis renvoi vers une autre vidéo. Pas de fin muette.

## Style
- Phrases de 8 à 18 mots, voix active, 2e personne.
- Un chiffre concret toutes les 2 à 3 phrases.
- Pièces nommées précisément (condenser, serpentine belt, torque converter) : chaque nom appelle un visuel.
- Une relance de rétention toutes les 60 à 90 s.
- Ponctuation soignée : elle pilote les pauses de la voix (150 à 300 ms entre deux phrases).
- Accroche, annonce, transitions, appel à l'abonnement et conclusion ne reprennent jamais mot pour mot une vidéo précédente.
- Cohérence du véhicule : boîte auto ou manuelle, essence, diesel ou électrique selon l'item.
