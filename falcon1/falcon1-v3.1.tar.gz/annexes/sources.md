# ANNEXE SOURCES DES RUSHS (étape R1.6)

Toutes les sources sont autorisées : le seul critère est la justesse et la qualité du plan. Garder au moins 2 candidats par beat et prendre le meilleur après l'avoir regardé.

## Où chercher (dans cet ordre)
1. Un seul find_footage portant tous les besoins du film (toutes les archives à la fois, avec planches contact). En même temps, ta propre recherche web.
2. Salles de presse des constructeurs (source premium n° 1) : Toyota, Ford, GM, Stellantis, BMW, Mercedes, VW, Hyundai/Kia, Honda, Nissan, Volvo, Porsche… On y trouve du b-roll 4K et des animations techniques 3D officielles.
3. Équipementiers : Bosch, Continental, Denso, ZF, Aisin, Valeo, Mobil, Castrol, Shell, NGK… (animations de fonctionnement, vues en coupe).
4. Banques : Pexels, Pixabay, Mixkit, Coverr, Videvo, Storyblocks, Envato, Artgrid, Pond5, Shutterstock, Getty.
5. Wikimedia Commons et Internet Archive : schémas et vues éclatées. Y accéder via find_footage, fetch_web_page ou use_media_url, jamais par leur API depuis ta machine.
6. Pages marchandes et manuels (Amazon, AutoZone, RockAuto, manuels PDF) : captures d'écran.
7. Bibliothèques Wawie (search_media, research_lookup) en complément.
8. Génération IA : seulement pour un concept impossible à filmer, jamais pour une pièce précise.

## Récupération
- fetch_web_page(url) pour lire une page et ses fichiers ou flux.
- use_media_url(url, start, end) pour 180 s au maximum.
- wawie_upload_link pour un fichier obtenu avec curl ou ffmpeg.
- Pas d'outil de téléchargement de réseaux sociaux, pas de filigrane recadré : remonter à la source d'origine.

## Requêtes
- Dizaines de requêtes par item, de 2 à 6 mots, du plus précis au plus large, avec le cadrage : close up, POV, aerial, slow motion, hands, cutaway, animation.
- En anglais d'abord, puis en français, allemand et japonais pour les constructeurs.
- Opérateurs utiles : filetype:mp4, "b-roll", "press kit", site:.
- Exemple « condenser » : car ac condenser close up / ac condenser animation / condenser cleaning mechanic / radiator front car grille close up.

## Critères de choix
- 1080p ou plus (720p seulement si c'est le seul plan juste).
- 16:9 en priorité.
- Sujet compris en moins de 0.5 s.
- Exactement la pièce ou le geste dit.
- Ni logo ni bandeau ; couleurs vives.
- Puis inspect_video_range aux instants utilisés → note_media (ce que montre le plan, sa source, les mots qu'il illustre) → download_media.
