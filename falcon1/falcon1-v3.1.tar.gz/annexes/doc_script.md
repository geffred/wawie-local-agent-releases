# ANNEXE DOC — SCRIPT (étape R2.4)

## Volume et langue
- Viser 160 à 180 mots par minute.
- Langue : français par défaut, ou la langue demandée.
- Les extraits parlés restent en langue d'origine et sont sous-titrés.

## Règles d'écriture
- **Structure** : celle de l'archétype, en suivant la courbe d'intensité. Le nombre d'actes et la durée viennent du tirage, sauf demande de la personne.
- **Phrases** : 8 à 18 mots, verbes concrets. Chaque phrase porte une image.
- **Repères visuels** : un chiffre, un nom, un lieu ou une date toutes les 2 à 3 phrases. Chacun appellera un visuel.
- **Rétention** : une relance toutes les 45 à 60 s ; un mini cliffhanger à la fin de chaque acte.
- **Ponctuation** : elle pilote les pauses de la voix. Prévoir 150 à 300 ms entre deux phrases, et 0.8 à 1.5 s avant les révélations (un point, puis une phrase courte).
- **Extraits parlés** : les annoncer (« Il le dira lui-même : »).
- **Valeur originale** (R1.1) : au moins 5 faits peu connus, au moins 3 passages d'analyse (pourquoi, conséquences, ce que les sources contredisent), un angle propre.
- **Fiabilité** : hypothèses au conditionnel ; niveau de fiabilité dit quand une information n'est pas établie.
- **Formules toujours nouvelles** : accroche, transitions de chapitre, appel à l'abonnement (vers 30 % de la durée) et conclusion ne reprennent jamais mot pour mot une vidéo précédente.
- **Fin** : conclusion + renvoi vers une autre vidéo ; écran de fin de 20 s, pendant lequel la narration continue.

## Voix
Voix grave et claire, ton de conteur documentaire, 160 à 180 mots par minute. Si plusieurs voix sont configurées, varier d'une vidéo à l'autre. Ne jamais refaire la voix (generate_voice interdit).

## Si le script est fourni
L'utiliser tel quel. Signaler dans le bilan toute affirmation non sourcée, et ne pas l'illustrer comme un fait.
