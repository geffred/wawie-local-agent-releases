# ANNEXE DOC — RECHERCHE ET SOURCES (étapes R2.1 et R2.7)

## Recherche documentaire
1. Commencer par les sources primaires : documents, archives, déclarations, données officielles, décisions de justice, rapports.
2. Puis la presse de référence et les travaux reconnus (livres, articles scientifiques).
3. Relever les contradictions entre sources et les dire dans le script.
4. Passer chaque fait par research_save, avec sa date et sa source.

## Images : où chercher
- **En premier** : un seul find_footage portant tous les besoins du film (toutes les archives à la fois, avec planches contact). En même temps, ta propre recherche web en plusieurs langues.
- **Archives** : nationales, télévisions, presse, Internet Archive, INA.
- **Institutions** : musées, agences spatiales et scientifiques, gouvernements, bibliothèques. Souvent du domaine public.
- **Pages de presse et sites officiels** : fichiers vidéo intégrés.
- **Wikimedia Commons et banques d'images et de vidéos** : toujours via find_footage, fetch_web_page ou use_media_url, jamais via leur API depuis ta machine.
- **Fichiers de la personne** : wawie_upload_link.
- **Bibliothèques Wawie** : search_media, research_lookup.

## Récupération
- fetch_web_page(url) pour lire une page et ses fichiers ou flux (HLS, DASH).
- use_media_url(url, start, end) pour 180 s au maximum.
- wawie_upload_link pour un fichier obtenu avec curl ou ffmpeg.
- Pas d'outil de téléchargement de réseaux sociaux, pas de filigrane recadré : remonter à la source d'origine.

## Critères de choix
- **Qualité** : 1080p ou plus de préférence. Une source en basse définition se présente dans un cadre de la bible, jamais étirée.
- **Justesse** : le plan montre exactement ce qui est dit, à l'époque dite.
- **Cohérence** : harmoniser à l'étalonnage et au grain de la bible avant dépôt (ffmpeg : eq, colorbalance, noise).
- **Répétition** : un même plan 2 fois au maximum, jamais à moins de 60 s.
- **Crédit** : discret, toujours au même coin (bible).
- **Éthique** : rien de fuité, piraté ou volé. Ne pas montrer de victimes ni de mineurs. Extraits tiers courts, transformés et crédités. Vérifier la politique de l'ayant droit au moment de la production.
