# ANNEXE SON — conception sonore 100 % code (Falcon 1, niche automobile v3)

À lire à l'étape R1.9, une fois le storyboard figé et check_sync à 0.

## 1. Principe
- Le moteur `falcon1 son` synthétise tout le son à partir de numpy, sans aucun échantillon : 40 effets (whooshs, impacts, risers, interface, argent, atelier, automobile), 7 ambiances et une musique composée acte par acte dans la direction tirée (D1 à D8).
- Il travaille en 48 kHz flottant, rend des fichiers FLAC 24 bits et limite le pic vrai à -1 dBTP sur chaque stem.
- Tous les sons sont calés sur get_timing. Le ducking sous la voix est calculé mot par mot : attaque 0.10 s, relâche 0.40 s, anticipation 0.08 s, plus une « poche » de -3 dB entre 1 et 4 kHz quand la voix parle. Le ducking de Wawie est donc désactivé (`autoDuck: false`).
- Chaque son est tiré avec la graine de la vidéo et son rang : deux vidéos n'ont jamais les mêmes sons, et deux sons du même type ne sont jamais identiques dans une vidéo.

## 2. Pourquoi des stems
Wawie accepte 40 effets par film au maximum (4 par plan, durée de 0.2 à 10 s), 8 lits d'ambiance et des volumes plafonnés (musique ≤ 0.6, ambiance ≤ 0.5). On livre donc :
1. `musique_stem.flac` : la musique, pleine durée, ducking déjà appliqué.
2. `effets_stem.flac` : tous les effets non-héros et toutes les ambiances, pleine durée, déjà calés.
3. `heros/NN_nom.wav` : les effets forts (40 au maximum), posés plan par plan.
Les stems sont rendus 6.02 dB plus fort, pour être posés au volume 0.5.

## 3. cues.json (à écrire à chaque vidéo, une centaine de lignes)
```json
{
 "total": 1085.40,
 "graine": "<graine du tirage>",
 "direction_musicale": "D4",
 "pack_sfx": "S2",
 "timing": "timing.json",
 "voix_lufs": -16,
 "actes": [
  {"start": 0, "end": 38.2, "mood": "tension"},
  {"start": 38.2, "end": 412.0, "mood": "sombre"},
  {"start": 412.0, "end": 1040.0, "mood": "positif"},
  {"start": 1040.0, "end": 1085.4, "mood": "resolution"}
 ],
 "relances": [[402.1, 406.0]],
 "sfx": [
  {"son": "braam", "at": 0.03, "hero": true},
  {"son": "riser", "at": 38.20, "duree": 2.6},
  {"son": "impact", "at": 38.20, "hero": true},
  {"son": "whoosh", "at": 52.47},
  {"son": "tick", "at": 61.30, "gain_db": -2},
  {"son": "cha_ching", "at": 95.12, "hero": true}
 ],
 "ambiances": [{"lieu": "atelier", "start": 120.0, "end": 168.5, "gain_db": 0}]
}
```
- `timing` : la réponse brute de get_timing enregistrée dans un fichier (le moteur y trouve les mots et leurs temps). Autre possibilité : `"mots": [[mot, début, fin], ...]`.
- `at` : l'instant où doit tomber le PIC du son, c'est-à-dire le début du mot (révélation, prix, mot clé) ou le point de coupe (transition). Le moteur avance lui-même le départ du son (par exemple, un riser se termine pile sur at). Avec `"cale": "debut"`, at devient l'instant de départ du son.
- `gain_db` : correction par rapport au niveau par défaut de chaque son (en général 0, entre -6 et +4).
- `pan` : de -1 à 1, pour suivre un mouvement à l'image (facultatif).
- `voix_lufs` : à mettre seulement si tu as mesuré la voix (`ffmpeg -i voix -af ebur128 -f null -`). Sinon, la valeur par défaut est -16.
- `relances` : zones où la musique remonte de 3 dB (révélation forte, avant le bouton abonnement). Les 8 dernières secondes sont ajoutées automatiquement.
- `ducking_db` (défaut 11) et `musique_pause_lu` (défaut -9 par rapport à la voix) : à ne changer que si la voix est couverte.

## 4. Sons disponibles (`python3 -m falcon1 sons`)
| Usage | Sons |
|---|---|
| Carte titre | impact (héros) + whoosh, whoosh_deep ou glitch selon la famille de cartes ; reverse_swell 1 s avant |
| Mot clé géant | pop, whoosh, whip (pas sur chaque mot clé : un sur deux) |
| Révélation interne de motion | tick (discret), hud_beep, scan (rayons X) ; impact léger sur le chiffre final |
| Entrée/sortie de motion | swoosh_soft, whoosh_bright, light_flash |
| Transition stylisée | whip (whip pan), light_flash (flash), swoosh_soft (light leak), whoosh_deep (zoom traversant), glitch |
| Prix | cha_ching (héros) + money_rustle pendant la pluie de billets, coins pour des économies |
| Mythe / NOT TRUE | buzzer (héros) |
| Bonne habitude / solution | ding ; ding_low pour un constat négatif doux |
| Document / manuel / facture | paper, mouse_click |
| Abonnement | mouse_click ×2 + notif_bell |
| Atelier (sous les plans concernés) | ratchet, wrench_clink, lock_click, impact_gun, oil_pour |
| Automobile (sous les plans concernés) | starter, starter_fail, engine_rev, turbo, tire_squeal, turn_signal, car_door, key_jingle |
| Moments forts | braam (ouverture), sub_drop (début d'acte), riser (2 à 4 s avant un tournant, "duree") |

Ambiances (`lieu`) : atelier, habitacle, autoroute, parking, garage_ferme, hiver, station_service. On les pose seulement sous les plans qui montrent ce lieu, avec un fondu d'1 s fait automatiquement.

## 5. Règles de dosage
- 6 à 15 moments sonores par minute (plus denses dans l'accroche) ; 10 à 15 % des coupes seulement portent un son.
- 60 % des sons dans le pack tiré (S1 air, S2 mécanique, S3 numérique, S4 cinéma, S5 automobile), le reste selon le besoin.
- Pas le même son à moins de 4 s d'intervalle ; au moins 3 whooshs et 2 pops différents sur la vidéo (le moteur fait varier chaque son, mais alterne aussi les noms).
- Effets héros : 40 au maximum, 4 par plan au maximum (Wawie refuse au-delà).
- Les sons diégétiques (moteur, outils) restent discrets : gain_db entre -3 et -6.

## 6. Commande, dépôt, storyboard
1. `PYTHONPATH=~/falcon1 python3 -m falcon1 son --cues cues.json --out son/`. Durée : environ 3 à 5 min pour 18 min de vidéo.
2. Lire la sortie : `problemes` doit être vide. Sinon, corriger cues.json (densité, répétitions, part du pack) et relancer.
3. Déposer `son/musique_stem.flac`, `son/effets_stem.flac` et chaque `son/heros/*.wav` avec wawie_upload_link. Chaque dépôt donne un asset A<n> audio. Si le FLAC est refusé, relancer avec `--format m4a`.
4. Storyboard, en remplaçant les `<asset de ...>` de `son/manifeste.json` par les A<n> :
   - `music` : [{"track": A_musique, "start": 0, "end": total, "volume": 0.5, "autoDuck": false, "fadeIn": 0, "fadeOut": 2}]
   - `ambience` : [{"sound": A_effets, "start": 0, "end": total, "volume": 0.5}]
   - chaque héros : dans le plan qui contient son `at`, sfx {"sound": A_n, "at": at, "volume": volume, "length": length}
5. check_sync, puis écouter un passage dense avec inspect_video_range s'il est disponible.

## 7. Contrôles faits par le moteur (rapport dans manifeste.json)
LUFS intégré, court terme max, LRA, pic vrai (suréchantillonné 4×), décalage DC, clics suspects, corrélation gauche/droite (compatibilité mono), densité par minute, part du pack, répétitions, héros éloignés d'un mot de plus de 0.25 s. Recopier dans le bilan : direction musicale et BPM, nombre d'effets et de héros, LUFS des stems.
