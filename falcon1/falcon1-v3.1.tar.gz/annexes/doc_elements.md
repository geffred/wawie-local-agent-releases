# ANNEXE DOC — ÉLÉMENTS, TRANSITIONS, IMMERSION, FLUIDITÉ (étapes R2.6 à R2.9)

Formes, couleurs, polices, courbes et lumières viennent de la bible. Les durées et le calage viennent de R6.

## Table mot → visuel
| La voix dit… | Visuel prioritaire | Secours |
|---|---|---|
| une personne | archive de l'époque dite + étiquette (1re apparition) | parallaxe 2.5D d'une photo (M1) |
| un lieu | images du lieu | globe ou carte 3D (M2), diorama (M7) |
| une date ou une époque | archive de l'époque | frise 3D (M3), compteur d'années (carte C3) |
| un chiffre | data 3D (M5) dans la matière de l'univers | hf.bigStat |
| un objet ou un mécanisme | rush ou archive de l'objet | vue éclatée 3D (M4) |
| un événement | archive de l'événement | reconstitution stylisée (M9), signalée |
| un document ou une citation | document 3D surligné (style citation tiré) | carte citation |
| une idée abstraite | objet-symbole 3D (M12) ou simulation (M11) | mot clé 3D dans une image réelle (M10) |
| une émotion | gros plan d'archive | parallaxe lente + musique |

## Éléments
| Élément | Durée | Construction |
|---|---|---|
| Archive encadrée | 2.5 à 5 s | cadre et fond de la bible, dérive lente |
| Carte de chapitre (famille tirée C1 à C10) | 3.0 à 4.5 s | matière de l'univers ; sub drop + whoosh, ou son du motif signature |
| Étiquette (style tiré) | 3.0 à 4.5 s | position fixe pour toute la vidéo |
| Mot clé (style tiré) | 2.5 à 3.5 s | — |
| Data 3D | 4 à 8 s | source en petit |
| Globe ou carte 3D | 4 à 10 s | — |
| Frise 3D | 4 à 10 s | — |
| Vue éclatée | 5 à 10 s | — |
| Document 3D | 0.35 s par mot + 1.5 s | phrase surlignée sur son mot, crédit |
| Reconstitution | 4 à 10 s | silhouettes ou maquettes + mention « Reconstitution » |
| Bouton abonnement (style tiré) | 3.5 à 4.5 s | vers 30 % de la durée, et à la fin |
| Écran de fin (mise en page tirée) | 20 s | zone libre pour l'élément de fin YouTube |

## Transitions (famille tirée J1 à J6)
- Répartition : 65 % de coupes et match cuts, 25 % stylisées, 5 à 10 % de transitions 3D continues.
- Toujours centrées sur un point de coupe placé dans un silence, chacune avec son son calé sur son pic.
- Au moins 2 coupes simples entre deux transitions stylisées.
- Entre deux actes : une transition 3D continue, ou une transition longue (0.6 à 1.0 s) de la famille.
- Le motif signature apparaît dans au moins 2 transitions.

## Immersion
- **Profondeur** : avant-plan, sujet et fond séparés ; particules en Z.
- **Lumière** : flares, faisceaux et reflets qui bougent avec la caméra, selon l'éclairage tiré.
- **Caméra** : jamais immobile, dérive de 2 à 4 % sur la durée de chaque plan fixe.
- **Micro-impacts** : secousse de 2 à 4 px sur 0.15 à 0.25 s, synchronisée avec un impact, au plus 1 toutes les 15 s.
- **Rythme** : speed ramps et ralentis sur les instants décisifs.
- **Matière** : grain, vignettage et étalonnage de la bible sur toute l'image, motions compris.
- **Effet signature** (V1 à V6) : avec constance, sans excès. Au plus 1 effet ponctuel toutes les 5 s, jamais sur un texte ou un visage.
- **Format** : celui tiré (W1 à W4). Le letterbox 2.39:1 s'applique à toute la vidéo, motions compris.

## Fluidité
- Coupes au milieu du silence entre deux mots.
- Hors rafales motivées, aucun plan sous 1.0 s ; une rafale est toujours suivie d'un plan plus long.
- Entrée et sortie de chaque motion en douceur (0.30 à 0.50 s).
- Continuité de mouvement : même sens d'un plan à l'autre ; pas de zoom arrière brutal après un zoom avant.
- Mouvements continus en ease none ou sine.inOut. Animations d'éléments selon les courbes de la bible.
- Pas plus de 2 apparitions dans la même seconde.
- Musique continue d'un acte à l'autre (le moteur fait les fondus croisés et le ducking mot à mot).
