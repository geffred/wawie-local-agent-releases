"""Tirage de l'identité visuelle et sonore d'une vidéo (graine + anti-répétition + registre local),
et test anti-gabarit (empreinte comparée aux vidéos précédentes).

Deux niches : « auto » (17 dimensions) et « doc » (fichier maître documentaire : archétype + 25 dimensions).
Seuls les choix retenus sont affichés : Falcon 1 ne lit jamais le catalogue complet des options.
"""
from __future__ import annotations

import datetime
import hashlib
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))

NICHES = {
    "auto": dict(
        options="options.json",
        registre="~/falcon1/registre_variations_auto.json",
        dims=["palette", "typographie", "famille_cartes_titre", "style_mots_cles", "style_etiquettes", "style_prix",
              "format_numerotation", "jeu_de_transitions", "styles_motion_3D", "grammaire_camera",
              "direction_musicale", "pack_sfx", "etalonnage", "structure_accroche", "style_bouton_abonnement",
              "mise_en_page_ecran_de_fin", "style_mise_en_evidence"],
        combo=("palette", "typographie", "famille_cartes_titre"),
        min_diff=12,
    ),
    "doc": dict(
        options="options_doc.json",
        registre="~/falcon1/registre_variations_documentaire.json",
        dims=["archetype_de_montage", "palette", "typographie", "eclairage_3D", "grammaire_camera", "courbes_d_animation",
              "matiere_et_grain", "famille_cadres", "famille_cartes_chapitre", "style_etiquettes", "style_mots_cles",
              "style_citations", "fond_de_composition", "jeu_de_transitions", "styles_motion_3D",
              "effets_visuels_signature", "direction_musicale", "pack_sfx", "style_de_silence", "etalonnage",
              "structure_ouverture", "style_bouton_abonnement", "mise_en_page_ecran_de_fin", "profil_de_rythme",
              "format_image", "nombre_actes_et_duree"],
        combo=("palette", "typographie", "eclairage_3D", "famille_cartes_chapitre"),
        min_diff=19,
    ),
}


def graine(run_id: str, titre: str) -> str:
    return hashlib.sha256((run_id + titre).encode("utf-8")).hexdigest()[:8]


def _options(niche):
    with open(os.path.join(HERE, NICHES[niche]["options"]), encoding="utf-8") as f:
        return json.load(f)


def _key(v):
    if isinstance(v, list):
        return "+".join(sorted(v))
    if isinstance(v, dict):
        return json.dumps(v, sort_keys=True)
    return v


def _load(path):
    if os.path.exists(path):
        try:
            with open(path, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return []
    return []


def _save(path, reg):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(reg, f, ensure_ascii=False, indent=1)


def tirer(run_id: str, titre: str, registre_path: str | None = None, ecrire: bool = True, niche: str = "auto",
          univers: str | None = None, duree_min: float | None = None) -> dict:
    cfg = NICHES[niche]
    registre_path = os.path.expanduser(registre_path or cfg["registre"])
    opts = _options(niche)
    reg = [r for r in _load(registre_path) if r.get("run_id") != run_id]
    g = graine(run_id, titre)
    base = int(g, 16)
    prev = reg[-1]["choix"] if reg else {}
    last3 = [r["choix"] for r in reg[-3:]]
    last5 = [r["choix"] for r in reg[-5:]]
    last10 = [r["choix"] for r in reg[-10:]]
    choix: dict = {}

    def compatible(dim, oid):
        o = next((x for x in opts.get(dim, []) if x["id"] == oid), {})
        return not (univers and univers in o.get("eviter", []))

    def ok(dim, val):
        if dim == "archetype_de_montage":
            return all(c.get(dim) != val for c in last3) and sum(1 for c in last10 if c.get(dim) == val) < 2
        if dim == "nombre_actes_et_duree":
            p = prev.get(dim)
            return not p or (p.get("actes") != val["actes"] and abs(p.get("duree_min", 0) - val["duree_min"]) >= 2)
        if prev.get(dim) is not None and _key(prev.get(dim)) == _key(val):
            return False
        if dim == "styles_motion_3D":
            if sum(1 for c in last5 if _key(c.get(dim)) == _key(val)) >= 2:
                return False
            return sum(1 for s in val if s not in (prev.get(dim) or [])) >= 2
        return sum(1 for c in last5 if _key(c.get(dim)) == _key(val)) < 2

    def styles_pool():
        if niche != "doc":
            return [o["id"] for o in opts["styles_motion_3D"]]
        arch = next(a for a in opts["archetype_de_montage"] if a["id"] == choix["archetype_de_montage"])
        pool = list(arch["styles"])
        for s in opts["styles_par_univers"].get(univers or "", []):
            if s not in pool:
                pool.append(s)
        for o in opts["styles_motion_3D"]:
            if o["id"] not in pool:
                pool.append(o["id"])
        return pool, set(arch["styles"]), set(opts["styles_par_univers"].get(univers or "", []))

    for rank, dim in enumerate(cfg["dims"]):
        if dim == "nombre_actes_et_duree":
            for shift in range(12):
                actes = 3 + (base // 7 + shift) % 7
                duree = duree_min if duree_min else 10 + (base // 11 + shift * 5) % 26
                val = {"actes": actes, "duree_min": duree}
                if duree_min:
                    p = prev.get(dim)
                    if not p or p.get("actes") != actes:
                        break
                elif ok(dim, val):
                    break
            choix[dim] = val
            continue
        if dim == "styles_motion_3D":
            if niche == "doc":
                pool, arch_s, univ_s = styles_pool()
                k = 3 + (base >> 5) % 2
                start = (base + rank * 7) % len(pool)
                best = None
                for shift in range(len(pool)):
                    cand = []
                    for j in range(len(pool)):
                        s = pool[(start + shift + j * 5) % len(pool)]
                        if s not in cand:
                            cand.append(s)
                        if len(cand) == k:
                            break
                    # au moins un style de l'archétype et, si l'univers est donné, un style de l'univers
                    if not arch_s & set(cand):
                        cand[-1] = sorted(arch_s)[(base + shift) % len(arch_s)]
                    if univ_s and not univ_s & set(cand):
                        cand[0] = sorted(univ_s)[(base + shift) % len(univ_s)]
                    cand = list(dict.fromkeys(cand))
                    best = best or cand
                    if len(cand) >= 3 and ok(dim, cand):
                        best = cand
                        break
                choix[dim] = best
            else:
                ids = [o["id"] for o in opts[dim]]
                start = (base + rank * 7) % len(ids)
                k = 3 + (base >> 5) % 2
                for shift in range(len(ids)):
                    val = list(dict.fromkeys(ids[(start + shift + j * 3) % len(ids)] for j in range(k)))
                    if ok(dim, val) or shift == len(ids) - 1:
                        choix[dim] = val
                        break
            continue
        ids = [o["id"] for o in opts[dim]]
        start = (base + rank * 7) % len(ids)
        chosen = None
        for shift in range(len(ids)):
            v = ids[(start + shift) % len(ids)]
            if not compatible(dim, v):
                continue
            chosen = chosen or v
            if ok(dim, v):
                chosen = v
                break
        choix[dim] = chosen

    def bump(dim):
        if dim in ("styles_motion_3D", "nombre_actes_et_duree", "archetype_de_montage"):
            return
        ids = [o["id"] for o in opts[dim]]
        i = ids.index(choix[dim])
        for s in range(1, len(ids)):
            v = ids[(i + s) % len(ids)]
            if compatible(dim, v) and ok(dim, v):
                choix[dim] = v
                return

    combo_dims = cfg["combo"]
    for _ in range(40):
        combo = tuple(choix[d] for d in combo_dims)
        if all(tuple(c.get(d) for d in combo_dims) != combo for c in last10):
            break
        bump(combo_dims[-1])
    need_same = len(cfg["dims"]) - cfg["min_diff"]
    for c in last3:
        same = [d for d in cfg["dims"] if _key(c.get(d)) == _key(choix[d])]
        for d in same[: max(0, len(same) - need_same)]:
            bump(d)

    detail = {}
    for dim in cfg["dims"]:
        v = choix[dim]
        if dim == "nombre_actes_et_duree":
            detail[dim] = v
            continue
        by = {o["id"]: o for o in opts[dim]}
        d = [dict(by[x]) for x in v] if isinstance(v, list) else dict(by[v])
        for o in (d if isinstance(d, list) else [d]):
            o.pop("eviter", None)
        detail[dim] = d
    entry = {"run_id": run_id, "titre": titre, "date": datetime.date.today().isoformat(), "graine": g,
             "univers": univers, "choix": choix}
    if ecrire:
        _save(registre_path, reg + [entry])
    return {"niche": niche, "graine": g, "univers": univers, "choix": choix, "detail": detail}


# ===================================================================== test anti-gabarit (documentaire)

def _share_diff(a: dict, b: dict) -> float:
    keys = set(a) | set(b)
    return max((abs(float(a.get(k, 0)) - float(b.get(k, 0))) for k in keys), default=0.0)


def empreinte(run_id: str, data: dict, registre_path: str | None = None, niche: str = "doc", ecrire: bool = True) -> dict:
    """Compare l'empreinte de la vidéo aux 3 précédentes (seuils du fichier maître) et l'enregistre."""
    cfg = NICHES[niche]
    registre_path = os.path.expanduser(registre_path or cfg["registre"])
    reg = _load(registre_path)
    requis = ["duree_totale_s", "nb_actes", "duree_moyenne_plans_s", "evenements_par_minute", "courbe_intensite",
              "transitions_pct", "styles_motion", "premier_plan"]
    manque = [k for k in requis if k not in data]
    if manque:
        return {"erreur": "champs manquants dans l'empreinte", "manque": manque}
    me = next((r for r in reg if r.get("run_id") == run_id), None)
    if me is None:
        return {"erreur": f"run_id {run_id} absent du registre : lancer d'abord le tirage"}
    choix = me["choix"]
    others = [r for r in reg if r.get("run_id") != run_id and r.get("empreinte")][-3:]
    res = []
    for o in others:
        oe, oc = o["empreinte"], o["choix"]
        checks = {}
        checks["archetype"] = choix.get("archetype_de_montage") != oc.get("archetype_de_montage")
        checks["duree_moyenne_plans"] = (abs(data["duree_moyenne_plans_s"] - oe["duree_moyenne_plans_s"]) >= 0.3
                                         or choix.get("profil_de_rythme") != oc.get("profil_de_rythme"))
        checks["densite_evenements"] = (abs(data["evenements_par_minute"] - oe["evenements_par_minute"]) >= 3
                                        or data.get("courbe_intensite") != oe.get("courbe_intensite"))
        mine = set(data.get("styles_motion", {}))
        theirs = set(oe.get("styles_motion", {}))
        checks["styles_motion"] = len(mine - theirs) >= 0.75 * max(1, len(mine))
        checks["transitions"] = _share_diff(data.get("transitions_pct", {}), oe.get("transitions_pct", {})) >= 10
        checks["actes_ou_duree"] = (abs(data["nb_actes"] - oe["nb_actes"]) >= 1
                                    or abs(data["duree_totale_s"] - oe["duree_totale_s"]) >= 120)
        diff = sum(1 for d in cfg["dims"] if _key(choix.get(d)) != _key(oc.get(d)))
        checks["dimensions_visuelles"] = diff >= cfg["min_diff"]
        checks["ouverture"] = (choix.get("structure_ouverture") != oc.get("structure_ouverture")
                               and data.get("premier_plan") != oe.get("premier_plan"))
        res.append({"contre": o["run_id"], "titre": o.get("titre"), "dimensions_differentes": diff,
                    "echecs": [k for k, v in checks.items() if not v]})
    ok = all(not r["echecs"] for r in res)
    if ecrire:
        me["empreinte"] = data
        me["anti_gabarit_ok"] = ok
        _save(registre_path, reg)
    return {"reussi": ok, "comparaisons": res,
            "a_faire": [] if ok else "modifier le montage (rythme, transitions, motions, ouverture) — jamais seulement "
                                     "les couleurs — puis recalculer l'empreinte"}
