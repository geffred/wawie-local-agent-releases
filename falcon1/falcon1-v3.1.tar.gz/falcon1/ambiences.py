"""Ambiances bouclables synthétisées (lits de 40 s par défaut, boucle sans couture par fondu croisé)."""
from __future__ import annotations

import math

import numpy as np

from .dsp import (SR, n_of, t_axis, stereo, mono, pan, fade, peak_normalize, smooth_random, white, pink, brown,
                  filt, lp, hp, bp, bell, chain, stft_shape, band_gain, widen, reverb, mix_into, match_lufs, moving_average)
from . import sfx
from . import sfx_doc


def _u(rng, a, b):
    return float(rng.uniform(a, b))


def _bed(n, rng, slope, shape, mod_rate=0.15, mod_depth=0.25):
    x = filt(np.stack([pink(n, rng) if slope == 1 else brown(n, rng), pink(n, rng) if slope == 1 else brown(n, rng)], 1), shape)
    m = 1 + mod_depth * smooth_random(n, mod_rate, rng)
    return x * m[:, None]


def _sprinkle(out, rng, maker, every, gain_db, space="garage", pan_range=0.8, wet=0.3):
    n = len(out)
    pos = n_of(_u(rng, 0.3, every[1]))
    while pos < n - n_of(1.0):
        a, _ = maker(rng)
        a = reverb(a, space, wet, int(rng.integers(1e6)))
        a = filt(a, lp(_u(rng, 3000, 7000), 1))
        p = _u(rng, -pan_range, pan_range)
        m = mono(a)
        mix_into(out, pan(m, p), pos, 10 ** (gain_db / 20) * _u(rng, 0.6, 1.0))
        pos += n_of(_u(rng, *every))


def _loop(x, xf=2.0):
    """Rend la fin raccord avec le début (fondu croisé à puissance constante)."""
    k = n_of(xf)
    head, body, tail = x[:k], x[k:-k] if len(x) > 2 * k else x, x[-k:]
    w = np.sin(np.linspace(0, math.pi / 2, k))[:, None]
    joined = tail * np.cos(np.linspace(0, math.pi / 2, k))[:, None] + head * w
    return np.concatenate([joined, body])


def workshop(rng, n):
    out = _bed(n, rng, 1, chain(lp(2200, 2), hp(60, 2)), 0.1, 0.15) * 0.05
    t = np.arange(n) / SR
    hum_f = _u(rng, 27, 33)
    comp = sum(np.sin(2 * math.pi * hum_f * h * t + h) / h for h in range(1, 12))
    on = (smooth_random(n, 0.05, rng) > 0.1).astype(float)
    on = moving_average(on, n_of(0.5))
    out += stereo(filt(comp, lp(350, 2)) * on * 0.02)
    radio = np.zeros(n)
    k = 0
    while k < n:
        d = n_of(_u(rng, 0.15, 0.45))
        f = sfx.mtof(int(rng.integers(55, 72)))
        tt = np.arange(d) / SR
        radio[k:k + d] += (np.sin(2 * math.pi * f * tt) + 0.5 * np.sin(4 * math.pi * f * tt))[: n - k] * np.hanning(d)[: n - k]
        k += d
    out += pan(filt(radio, bp(500, 2500, 2)) * 0.008, 0.6)
    _sprinkle(out, rng, sfx.wrench_clink, (3.0, 8.0), -30)
    _sprinkle(out, rng, sfx.ratchet, (6.0, 14.0), -32)
    _sprinkle(out, rng, sfx.impact_gun, (12.0, 25.0), -36)
    return out


def cabin(rng, n):
    out = _bed(n, rng, 2, chain(lp(260, 2), hp(25, 2)), 0.2, 0.2) * 0.25
    roar = _bed(n, rng, 1, bp(350, 1100, 2), 0.3, 0.3) * 0.05
    wind = _bed(n, rng, 1, bp(900, 3500, 1), 0.4, 0.5) * 0.02
    t = np.arange(n) / SR
    rpm = 2000 * (1 + 0.03 * smooth_random(n, 0.1, rng))
    ph = np.cumsum(rpm / 60 * 2) / SR
    drone = filt(sum(np.sin(2 * math.pi * h * ph) / h for h in (1, 2, 3)), lp(300, 2)) * 0.03
    out = out + roar + wind + stereo(drone)
    pos = n_of(_u(rng, 1, 5))
    while pos < n - n_of(1):
        th = filt(white(n_of(0.12), rng), lp(150, 2)) * np.exp(-np.arange(n_of(0.12)) / 900)
        mix_into(out, th * 0.25, pos)
        mix_into(out, th * 0.2, pos + n_of(_u(rng, 0.08, 0.12)))
        pos += n_of(_u(rng, 4, 9))
    return out


def highway(rng, n):
    out = _bed(n, rng, 1, chain(lp(1800, 2), hp(40, 2)), 0.1, 0.15) * 0.06
    pos = n_of(_u(rng, 0, 1))
    while pos < n:
        d = _u(rng, 2.5, 4.5)
        m = n_of(d)
        truck = rng.random() < 0.25
        lo, hi = (80, 900) if truck else (200, 2500)
        u = np.arange(m) / m
        env = np.exp(-((u - 0.5) / 0.18) ** 2)
        body = filt(pink(m, rng), bp(lo, hi, 2)) * env
        f0 = _u(rng, 500, 900)
        dop = f0 * (1 + 0.06 * np.tanh((0.5 - u) * 8))
        whine = np.sin(2 * math.pi * np.cumsum(dop) / SR) * env * 0.08
        dirn = 1 if rng.random() < 0.5 else -1
        mix_into(out, pan(body + whine, dirn * (u * 1.6 - 0.8)), pos, (0.35 if truck else 0.22) * _u(rng, 0.6, 1))
        pos += n_of(_u(rng, 1.2, 3.5))
    return out


def parking(rng, n):
    out = _bed(n, rng, 1, chain(lp(1200, 2), hp(50, 2)), 0.08, 0.2) * 0.035
    out += _bed(n, rng, 1, bp(2000, 8000, 1), 0.2, 0.3) * 0.004
    _sprinkle(out, rng, sfx.car_door, (6, 15), -28, "garage", 0.9, 0.35)
    _sprinkle(out, rng, lambda r: sfx.hud_beep(r), (10, 22), -36, "garage", 0.9, 0.4)
    _sprinkle(out, rng, sfx.key_jingle, (9, 20), -38, "room", 0.7, 0.2)
    return out


def garage_closed(rng, n):
    out = _bed(n, rng, 1, chain(lp(900, 2), hp(40, 2)), 0.05, 0.1) * 0.02
    t = np.arange(n) / SR
    mains = 50 if rng.random() < 0.5 else 60
    hum = sum(np.sin(2 * math.pi * mains * 2 * h * t + h) / h ** 1.5 for h in range(1, 8))
    buzz = filt(np.sign(np.sin(2 * math.pi * mains * 2 * t)), bp(2000, 6000, 1)) * 0.004
    out += stereo((hum * 0.006 + buzz) * (1 + 0.1 * smooth_random(n, 0.3, rng)))

    def drip(r):
        tt = t_axis(0.08)
        y = np.sin(2 * math.pi * np.cumsum(_u(r, 900, 1400) * (1 + 0.6 * tt / 0.08)) / SR) * np.exp(-tt / 0.015)
        return y, 0.0
    _sprinkle(out, rng, drip, (3, 9), -30, "garage", 0.6, 0.45)
    return out


def winter(rng, n):
    nz = np.stack([pink(n, rng), pink(n, rng)], 1)
    cen = lambda t: 700 + 330 * np.sin(2 * math.pi * 0.07 * t + 1.3) + 160 * np.sin(2 * math.pi * 0.17 * t)
    w = np.stack([stft_shape(nz[:, c], band_gain(cen, 1.2), 2048, 512) for c in range(2)], 1)
    gust = 0.55 + 0.45 * smooth_random(n, 0.25, rng)
    out = filt(w, lp(3500, 1)) * gust[:, None] * 0.06
    out += _bed(n, rng, 2, lp(120, 2), 0.1, 0.3) * 0.05
    return out


def gas_station(rng, n):
    out = _bed(n, rng, 1, chain(lp(1500, 2), hp(50, 2)), 0.1, 0.2) * 0.035
    t = np.arange(n) / SR
    pump = sum(np.sin(2 * math.pi * 120 * h * t) / h for h in range(1, 6)) + 0.3 * np.sin(2 * math.pi * 980 * t)
    on = (smooth_random(n, 0.06, rng) > -0.2).astype(float)
    on = moving_average(on, n_of(0.3))
    out += pan(filt(pump, lp(1500, 2)) * on * 0.006, -0.4)
    _sprinkle(out, rng, sfx.lock_click, (7, 16), -32, "room", 0.8, 0.2)
    _sprinkle(out, rng, lambda r: sfx.ding(r), (15, 30), -40, "garage", 0.8, 0.4)
    out += highway(rng, n) * 0.25
    return out


AMBIENCES = {
    "atelier": (workshop, -38.0),
    "habitacle": (cabin, -34.0),
    "autoroute": (highway, -34.0),
    "parking": (parking, -40.0),
    "garage_ferme": (garage_closed, -44.0),
    "hiver": (winter, -38.0),
    "station_service": (gas_station, -38.0),
}


# ======================================================================= lieux documentaires

def _babble(rng, n, voices=12, level=1.0):
    out = np.zeros((n, 2))
    for v in range(voices):
        p = _u(rng, -0.9, 0.9)
        pos = n_of(_u(rng, 0, 1.0))
        pitch = _u(rng, 0.8, 1.3)
        while pos < n:
            if rng.random() < 0.15:
                pos += n_of(_u(rng, 0.3, 1.2))
                continue
            d = n_of(_u(rng, 0.12, 0.28))
            f1, f2 = _u(rng, 300, 850) * pitch, _u(rng, 900, 2400) * pitch
            seg = filt(white(d, rng), bp(f1 * 0.8, f1 * 1.25, 2)) + 0.5 * filt(white(d, rng), bp(f2 * 0.85, f2 * 1.2, 2))
            mix_into(out, pan(seg * np.hanning(d), p), pos, _u(rng, 0.4, 1.0) * level)
            pos += d + n_of(_u(rng, 0.0, 0.08))
    return filt(out, lp(3500, 1))


def city(rng, n):
    out = _bed(n, rng, 1, chain(lp(900, 2), hp(35, 2)), 0.08, 0.25) * 0.07
    out += highway(rng, n) * 0.25
    _sprinkle(out, rng, lambda r: (np.sin(2 * math.pi * _u(r, 380, 460) * t_axis(_u(r, 0.25, 0.6))) * 0.3, 0.0),
              (8, 20), -34, "hall", 0.9, 0.5)
    _sprinkle(out, rng, lambda r: sfx_doc.siren_far(r), (25, 50), -36, "hall", 0.9, 0.3)
    out += reverb(_babble(rng, n, 6, 0.2), "hall", 0.4, 71, tail=False) * 0.3
    return out


def crowd(rng, n):
    out = _babble(rng, n, int(_u(rng, 14, 22)))
    out = reverb(out, "hall", 0.35, 72, tail=False) * 0.25
    out += _bed(n, rng, 1, chain(lp(1500, 2), hp(80, 2)), 0.2, 0.3) * 0.02
    return out


def forest(rng, n):
    leaves = _bed(n, rng, 1, chain(hp(1500, 1), lp(9000, 1)), 0.2, 0.6) * 0.012
    out = leaves + _bed(n, rng, 2, lp(200, 2), 0.1, 0.3) * 0.02

    def bird(r):
        y = np.zeros(n_of(1.2))
        f0 = _u(r, 2500, 5000)
        for k in range(int(_u(r, 2, 6))):
            d = _u(r, 0.04, 0.12)
            tt = t_axis(d)
            f = f0 * (1 + _u(r, -0.3, 0.3) * tt / d) * (1 + 0.05 * np.sin(2 * math.pi * _u(r, 30, 80) * tt))
            mix_into(y, np.sin(2 * math.pi * np.cumsum(f) / SR) * np.sin(np.pi * tt / d) ** 2, n_of(k * _u(r, 0.1, 0.2)))
        return y, 0.0
    _sprinkle(out, rng, bird, (1.5, 5), -30, "hall", 0.9, 0.35)
    return out


def sea(rng, n):
    t = np.arange(n) / SR
    period = _u(rng, 7, 11)
    wave = (0.5 + 0.5 * np.sin(2 * math.pi * t / period + smooth_random(n, 0.05, rng))) ** 3
    surf = _bed(n, rng, 1, bp(300, 6000, 1), 0.1, 0.1) * wave[:, None] * 0.08
    rumble = _bed(n, rng, 2, lp(250, 2), 0.1, 0.2) * (0.6 + 0.4 * wave)[:, None] * 0.1
    hiss = _bed(n, rng, 1, hp(4000, 1), 0.3, 0.3) * np.roll(wave, n_of(1.2))[:, None] * 0.02
    return surf + rumble + hiss


def desert(rng, n):
    w = winter(rng, n) * 0.8
    sand = _bed(n, rng, 1, bp(3000, 10000, 1), 0.3, 0.7) * 0.01
    return w + sand


def rain(rng, n):
    out = _bed(n, rng, 1, chain(bp(800, 9000, 1)), 0.1, 0.1) * 0.03
    k = 0
    drops = np.zeros(n)
    while k < n - 200:
        drops[k] += _u(rng, -1, 1)
        k += int(_u(rng, 20, 220))
    out += stereo(filt(drops, bp(1500, 8000, 1))) * 0.15
    out += _bed(n, rng, 2, lp(300, 2), 0.1, 0.2) * 0.03
    return out


def storm(rng, n):
    out = rain(rng, n) * 1.3
    _sprinkle(out, rng, lambda r: sfx_doc.thunder(r), (9, 20), -14, "hall", 0.7, 0.1)
    return out


def office(rng, n):
    out = _bed(n, rng, 1, chain(lp(1200, 2), hp(60, 2)), 0.05, 0.1) * 0.02
    t = np.arange(n) / SR
    out += stereo(sum(np.sin(2 * math.pi * 120 * h * t) / h ** 2 for h in range(1, 4)) * 0.002)

    def typing(r):
        y = np.zeros(n_of(2.0))
        pos = 0.0
        while pos < 1.8:
            c = sfx._modal([_u(r, 1800, 3000), _u(r, 4000, 5500)], [0.008, 0.004], [1, .4], 0.03, r, 0.05)
            mix_into(y, c * _u(r, 0.3, 0.8), n_of(pos))
            pos += _u(r, 0.06, 0.2)
        return y, 0.0
    _sprinkle(out, rng, typing, (3, 9), -38, "room", 0.8, 0.2)
    out += reverb(_babble(rng, n, 3, 0.15), "room", 0.4, 73, tail=False) * 0.15
    return out


def night(rng, n):
    out = _bed(n, rng, 1, chain(lp(800, 2), hp(40, 2)), 0.05, 0.1) * 0.012
    t = np.arange(n) / SR
    for c in range(int(_u(rng, 2, 5))):
        f = _u(rng, 3800, 5200)
        rate = _u(rng, 12, 20)
        chirp = np.sin(2 * math.pi * f * t) * (np.sin(2 * math.pi * rate * t) > 0.3)
        gate = (smooth_random(n, 0.3, rng) > -0.2).astype(float)
        out += pan(chirp * moving_average(gate, n_of(0.2)) * 0.004, _u(rng, -0.8, 0.8))
    return out


def empty_hall(rng, n):
    out = _bed(n, rng, 1, chain(lp(700, 2), hp(40, 2)), 0.03, 0.1) * 0.02
    _sprinkle(out, rng, lambda r: sfx_doc.wood_knock(r), (6, 14), -38, "cathedral", 0.8, 0.7)
    return out


AMBIENCES.update({
    "ville": (city, -36.0), "foule": (crowd, -34.0), "foret": (forest, -40.0), "mer": (sea, -36.0),
    "desert": (desert, -40.0), "pluie": (rain, -38.0), "orage": (storm, -36.0), "bureau": (office, -42.0),
    "nuit": (night, -44.0), "salle_vide": (empty_hall, -46.0),
})


def make(name: str, rng, seconds: float = 40.0) -> np.ndarray:
    """Lit d'ambiance bouclable, à son niveau de référence (LUFS de tableau ci-dessus)."""
    fn, lufs = AMBIENCES[name]
    n = n_of(seconds + 2.0)
    x = stereo(fn(rng, n))
    x = widen(mono(x), 0.5, rng) * 0.4 + x * 0.6
    x = _loop(x, 2.0)
    return match_lufs(x, lufs)
