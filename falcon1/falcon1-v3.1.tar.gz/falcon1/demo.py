"""Démonstration : exporte chaque son du catalogue et une minute de mixage (musique + effets + ambiances),
avec une « voix » simulée par des silences/paroles fictifs pour entendre le ducking."""
from __future__ import annotations

import json
import os

import numpy as np

from .dsp import write_wav, read_wav, mix_into, n_of, stereo, encode
from . import sfx as SFX
from . import ambiences as AMB
from .mix import build


def run(out: str, direction: str = "D4"):
    os.makedirs(os.path.join(out, "sons"), exist_ok=True)
    rng = np.random.default_rng(2026)
    for name in SFX.CATALOGUE:
        a, _ = SFX.make(name, rng)
        write_wav(os.path.join(out, "sons", name + ".wav"), a)
    os.makedirs(os.path.join(out, "ambiances"), exist_ok=True)
    for name in AMB.AMBIENCES:
        write_wav(os.path.join(out, "ambiances", name + ".wav"), AMB.make(name, rng, 20) * 4)
    # paroles fictives : blocs de « mots » de 0.3 s avec respirations
    words, t = [], 1.2
    while t < 58:
        for _ in range(int(rng.integers(6, 14))):
            words.append(["mot", round(t, 3), round(t + 0.28, 3)])
            t += 0.33
        t += float(rng.uniform(0.25, 1.4))
    cues = {
        "total": 60.0, "graine": "demo2026", "direction_musicale": direction, "pack_sfx": "S4",
        "mots": words,
        "actes": [{"start": 0, "end": 30, "mood": "tension"}, {"start": 30, "end": 60, "mood": "positif"}],
        "sfx": [
            {"son": "braam", "at": 0.05, "hero": True},
            {"son": "riser", "at": 6.0, "duree": 2.5},
            {"son": "impact", "at": 6.0, "hero": True},
            {"son": "whoosh", "at": 9.4}, {"son": "pop", "at": 11.2}, {"son": "tick", "at": 13.0},
            {"son": "tick", "at": 14.6, "gain_db": -2}, {"son": "cha_ching", "at": 17.0, "hero": True},
            {"son": "money_rustle", "at": 17.3}, {"son": "whip", "at": 20.5}, {"son": "glitch", "at": 23.0},
            {"son": "buzzer", "at": 25.5, "hero": True}, {"son": "reverse_swell", "at": 29.9},
            {"son": "sub_drop", "at": 30.0, "hero": True}, {"son": "light_flash", "at": 33.0},
            {"son": "ratchet", "at": 36.0}, {"son": "wrench_clink", "at": 38.2}, {"son": "ding", "at": 41.0},
            {"son": "starter", "at": 44.5, "hero": True}, {"son": "turbo", "at": 49.0}, {"son": "whoosh_deep", "at": 52.0},
            {"son": "mouse_click", "at": 54.0}, {"son": "notif_bell", "at": 55.0}, {"son": "tire_squeal", "at": 57.0},
        ],
        "ambiances": [{"lieu": "atelier", "start": 33, "end": 43}, {"lieu": "habitacle", "start": 43, "end": 60}],
    }
    with open(os.path.join(out, "cues_demo.json"), "w") as f:
        json.dump(cues, f, ensure_ascii=False, indent=1)
    m = build(cues, os.path.join(out, "stems"), out, "wav")
    # écoute de contrôle : stems à leur volume Wawie (0.5) + héros, sans voix
    mixd = read_wav(os.path.join(out, "stems", m["fichiers"]["musique_stem"])) * 0.5
    mixd += read_wav(os.path.join(out, "stems", m["fichiers"]["effets_stem"])) * 0.5
    for h in m["storyboard"]["sfx_heros"]:
        a = read_wav(os.path.join(out, "stems", h["fichier"]))
        mix_into(mixd, a, n_of(h["at"]), h["volume"])
    mixd = mixd / max(1.0, np.max(np.abs(mixd)) / 0.89)
    path = os.path.join(out, "ecoute_demo_sans_voix.wav")
    write_wav(path, mixd)
    try:
        encode(path, "mp3")
    except Exception:
        pass
    print(json.dumps(m["rapport"]["problemes"], ensure_ascii=False))
    print("démo écrite dans", out)
