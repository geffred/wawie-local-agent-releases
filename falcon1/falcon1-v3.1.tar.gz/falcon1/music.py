"""Compositeur procédural : une partition par acte, dans la direction musicale tirée (D1..D8).

Harmonie (mode + progression + conduite des voix), grille rythmique à 16 pas par mesure, couches qui
entrent par phrases de 8 mesures, respirations avant chaque changement d'acte, fondus croisés entre actes.
Tout est synthétisé (additif, FM, Karplus-Strong, modal, bruit) et mixé en quatre bus :
batterie, basse, harmonie, dessus.
"""
from __future__ import annotations

import math

import numpy as np

from .dsp import (SR, n_of, t_axis, stereo, mono, pan, fade, peak_normalize, adsr, exp_decay, smooth_random, white,
                  pink, filt, lp, hp, bp, bell, shelf, chain, saturate, widen, reverb, mix_into, convolve,
                  delay_ir, compressor, limiter, match_lufs, mtof, undb)
from . import sfx as SFX

SCALES = {
    "aeolian": [0, 2, 3, 5, 7, 8, 10], "dorian": [0, 2, 3, 5, 7, 9, 10], "phrygian": [0, 1, 3, 5, 7, 8, 10],
    "ionian": [0, 2, 4, 5, 7, 9, 11], "mixolydian": [0, 2, 4, 5, 7, 9, 10], "lydian": [0, 2, 4, 6, 7, 9, 11],
}
PROG_MINOR = [[0, 5, 2, 6], [0, 3, 5, 4], [0, 6, 5, 6], [0, 2, 6, 5], [0, 5, 3, 4], [0, 3, 0, 4], [5, 6, 0, 0]]
PROG_MAJOR = [[0, 4, 5, 3], [0, 5, 3, 4], [3, 4, 0, 5], [0, 3, 4, 3], [5, 3, 0, 4], [0, 2, 3, 4]]

# Directions musicales : tempo, instruments, groove, espace.
DIRECTIONS = {
    "D1": dict(nom="Électro documentaire", bpm=(100, 110), kit="electro", bass="pulse", harm="pad", top="arp",
               pump=0.55, space="hall", swing=0.0, sevenths=False),
    "D2": dict(nom="Trailer hybride synthétique", bpm=(95, 105), kit="trailer", bass="sub", harm="strings",
               top="ostinato", pump=0.0, space="cathedral", swing=0.0, sevenths=False),
    "D3": dict(nom="Lo-fi tech", bpm=(85, 95), kit="lofi", bass="round", harm="epiano", top="bells",
               pump=0.25, space="plate", swing=0.58, sevenths=True),
    "D4": dict(nom="Synthwave / rétro-drive", bpm=(105, 115), kit="synthwave", bass="arp16", harm="pad",
               top="arp", pump=0.5, space="hall", swing=0.0, sevenths=False),
    "D5": dict(nom="Rock instrumental feutré", bpm=(110, 120), kit="rock", bass="pick", harm="guitar",
               top="none", pump=0.0, space="room", swing=0.0, sevenths=False),
    "D6": dict(nom="Ambient industriel", bpm=(90, 100), kit="industrial", bass="sub", harm="drone",
               top="metal", pump=0.2, space="garage", swing=0.0, sevenths=False),
    "D7": dict(nom="Corporate moderne", bpm=(110, 118), kit="corporate", bass="pulse", harm="pluck",
               top="bells", pump=0.45, space="plate", swing=0.0, sevenths=True),
    "D8": dict(nom="Phonk / trap léger", bpm=(136, 144), kit="phonk", bass="808", harm="pad",
               top="cowbell", pump=0.0, space="hall", swing=0.0, sevenths=False),
}

# Directions musicales des documentaires (fichier maître) : mêmes instruments, autres dosages.
DOC_DIRECTIONS = {
    "D1": dict(nom="Hybride orchestral/électronique cinématique", bpm=(90, 110), kit="trailer", bass="pulse",
               harm="strings", top="ostinato", pump=0.3, space="hall", swing=0.0, sevenths=False),
    "D2": dict(nom="Dark ambient + pulsations", bpm=(70, 90), kit="heartbeat", bass="sub", harm="drone",
               top="none", pump=0.15, space="cathedral", swing=0.0, sevenths=False),
    "D3": dict(nom="Piano et cordes émotionnels", bpm=(68, 84), kit="none", bass="sub", harm="strings",
               top="piano", pump=0.0, space="hall", swing=0.0, sevenths=True),
    "D4": dict(nom="Percussions épiques", bpm=(100, 120), kit="epic", bass="sub", harm="strings",
               top="ostinato", pump=0.0, space="hall", swing=0.0, sevenths=False),
    "D5": dict(nom="Électro minimaliste tendue", bpm=(110, 125), kit="electro", bass="pulse", harm="drone",
               top="arp", pump=0.5, space="plate", swing=0.0, sevenths=False),
    "D6": dict(nom="Synthwave / rétro", bpm=(100, 115), kit="synthwave", bass="arp16", harm="pad",
               top="arp", pump=0.5, space="hall", swing=0.0, sevenths=False),
    "D7": dict(nom="Textures industrielles et drones", bpm=(80, 95), kit="industrial", bass="sub", harm="drone",
               top="metal", pump=0.2, space="garage", swing=0.0, sevenths=False),
    "D8": dict(nom="Couleur culturelle du sujet (gamme au choix)", bpm=(84, 104), kit="frame", bass="sub",
               harm="drone", top="motif", pump=0.0, space="hall", swing=0.0, sevenths=False),
}

# Gammes « culturelles » (D8) : une gamme à 7 notes pour l'harmonie, une gamme pour le motif. Sans caricature :
# la couleur vient des intervalles, jamais d'un cliché instrumental.
GAMMES = {
    "hijaz": dict(harm=[0, 1, 4, 5, 7, 8, 10], motif=[0, 1, 4, 5, 7, 8, 10]),
    "japonaise": dict(harm=[0, 1, 3, 5, 7, 8, 10], motif=[0, 1, 5, 7, 10]),
    "pentatonique": dict(harm=[0, 2, 4, 5, 7, 9, 11], motif=[0, 2, 4, 7, 9]),
    "pentatonique_mineure": dict(harm=[0, 2, 3, 5, 7, 8, 10], motif=[0, 3, 5, 7, 10]),
    "dorienne": dict(harm=[0, 2, 3, 5, 7, 9, 10], motif=[0, 2, 3, 5, 7, 9, 10]),
    "hongroise": dict(harm=[0, 2, 3, 6, 7, 8, 11], motif=[0, 2, 3, 6, 7, 8, 11]),
}

MOODS = {
    "tension": dict(mode="aeolian", intensity=0.65, bright=0.7),
    "sombre": dict(mode="phrygian", intensity=0.55, bright=0.55),
    "positif": dict(mode="ionian", intensity=0.85, bright=1.0),
    "resolution": dict(mode="ionian", intensity=0.5, bright=0.85),
    "mystere": dict(mode="phrygian", intensity=0.4, bright=0.45),
    "emotion": dict(mode="aeolian", intensity=0.35, bright=0.65),
    "climax": dict(mode="aeolian", intensity=1.0, bright=1.0),
}
INTENSITE = {1: 0.3, 2: 0.45, 3: 0.6, 4: 0.8, 5: 1.0}

# ===================================================================== instruments

def _saw(f, t, maxh=40, tilt=1.0, cutoff=6000.0, phase=0.0):
    """Dent de scie à bande limitée, par table d'onde (une période calculée une fois, lue en interpolant)."""
    hmax = int(min(maxh, 15000 / max(f, 1)))
    size = 4096
    h = np.arange(1, hmax + 1)
    g = (1 / h ** tilt) / (1 + (h * f / cutoff) ** 2)
    spec = np.zeros(size // 2 + 1, dtype=complex)
    spec[1:hmax + 1] = -1j * g * size / 2
    table = np.fft.irfft(spec, size)
    pos = ((f * t + phase / (2 * math.pi)) % 1.0) * size
    i = pos.astype(np.int64)
    fr = pos - i
    return table[i] * (1 - fr) + table[(i + 1) % size] * fr


def pad(notes, dur, rng, bright=1.0, attack=0.6, voices=5, detune=0.012):
    t = t_axis(dur + 1.2)
    out = np.zeros((len(t), 2))
    for i, m in enumerate(notes):
        f = mtof(m)
        for v in range(voices):
            d = (v - (voices - 1) / 2) / max(1, (voices - 1) / 2) * detune
            y = _saw(f * (1 + d), t, 30, 1.0, 1800 + 3000 * bright, rng.uniform(0, 6.28))
            out += pan(y, (v / max(1, voices - 1)) * 1.4 - 0.7) / voices
    env = adsr(len(t), attack, 0.5, 0.85, 1.0, hold=dur)
    return out * env[:, None] / max(1, len(notes)) * 0.5


def strings(notes, dur, rng, bright=1.0, attack=0.25):
    t = t_axis(dur + 0.8)
    out = np.zeros((len(t), 2))
    vib = 1 + 0.004 * np.sin(2 * math.pi * 5.2 * t) * np.clip(t / 0.6, 0, 1)
    for m in notes:
        f = mtof(m)
        for k, d in enumerate((-0.004, 0.0, 0.005)):
            ph = 2 * math.pi * np.cumsum(f * (1 + d) * vib) / SR
            y = sum(np.sin(h * ph) / h ** 1.2 / (1 + (h * f / (2500 * bright + 800)) ** 2) for h in range(1, 25) if f * h < 14000)
            out += pan(y, (k - 1) * 0.6)
    out += stereo(filt(white(len(t), rng), bp(2000, 7000, 1)) * 0.01)
    env = adsr(len(t), attack, 0.3, 0.9, 0.6, hold=dur)
    return out * env[:, None] / max(1, len(notes)) * 0.35


def stacc(m, dur, rng, bright=1.0):
    """Corde staccato (ostinato de bande-annonce)."""
    t = t_axis(max(dur, 0.12) + 0.25)
    f = mtof(m)
    y = sum(np.sin(2 * math.pi * f * h * t + rng.uniform(0, 1)) / h ** 1.1 / (1 + (h * f / (3500 * bright)) ** 2)
            for h in range(1, 30) if f * h < 14000)
    y += filt(white(len(t), rng), bp(1500, 6000, 1)) * 0.05 * np.exp(-t / 0.03)
    return y * adsr(len(t), 0.008, 0.08, 0.5, 0.12, hold=min(dur, 0.15)) * 0.5


def epiano(m, dur, rng, bright=1.0):
    t = t_axis(dur + 1.0)
    f = mtof(m)
    idx = (1.2 + 0.8 * bright) * np.exp(-t / 0.4)
    y = np.sin(2 * math.pi * f * t + idx * np.sin(2 * math.pi * f * t))
    y += 0.15 * np.sin(2 * math.pi * f * 14 * t) * np.exp(-t / 0.03)
    trem = 1 + 0.12 * np.sin(2 * math.pi * 4.5 * t)
    return y * trem * adsr(len(t), 0.003, 1.2, 0.3, 0.5, hold=dur) * 0.35


def pluck(m, dur, rng, bright=1.0):
    t = t_axis(dur + 0.6)
    f = mtof(m)
    y = sum(np.sin(2 * math.pi * f * h * t) / h * np.exp(-t * (3 + 2.5 * h / bright)) for h in range(1, 20) if f * h < 15000)
    return y * fade(np.ones(len(t)), 0.002, 0.05) * 0.5


def piano(m, dur, rng, bright=1.0):
    """Piano additif : partiels légèrement inharmoniques, aigus qui s'éteignent plus vite, marteau."""
    t = t_axis(min(dur, 2.5) + 1.2)
    f = mtof(m)
    B = 0.0004
    y = np.zeros_like(t)
    for k in range(1, 16):
        fk = f * k * math.sqrt(1 + B * k * k)
        if fk > 12000:
            break
        y += (1 / k ** (1.4 - 0.3 * bright)) * np.sin(2 * math.pi * fk * t + rng.uniform(0, 6.28)) * np.exp(-t * (0.7 + 0.45 * k))
    y[:n_of(0.004)] += SFX._click(rng, 0.004, 500, 5000)[: n_of(0.004)] * 0.05
    return y * adsr(len(t), 0.002, 0.3, 1.0, 0.35, hold=dur) * 0.4


def bellnote(m, dur, rng, bright=1.0):
    t = t_axis(1.6)
    f = mtof(m)
    y = (np.sin(2 * math.pi * f * t) + 0.4 * np.sin(2 * math.pi * f * 2.0 * t) * np.exp(-t / 0.3)
         + 0.25 * np.sin(2 * math.pi * f * 3.0 * t) * np.exp(-t / 0.15)) * np.exp(-t / 0.6)
    return y * 0.3


def ks_string(m, dur, rng, mute=0.0, bright=1.0):
    """Corde pincée Karplus-Strong vectorisée par blocs ; mute > 0 = étouffé (palm mute)."""
    f = mtof(m)
    N = max(2, int(round(SR / f)))
    total = n_of(dur + 0.3)
    y = np.zeros(total + N + 1)
    y[1:N + 1] = filt(rng.uniform(-1, 1, N), lp(2500 + 5000 * bright, 1))
    loss = 0.996 - 0.03 * mute
    pos = N + 1
    while pos < len(y):
        e = min(len(y), pos + N)
        a = y[pos - N:e - N]
        b = y[pos - N - 1:e - N - 1]
        y[pos:e] = loss * 0.5 * (a + b)
        pos = e
    y = y[1:total + 1]
    if mute > 0:
        y = filt(y, lp(900 + 1500 * (1 - mute), 2))
    return y * adsr(len(y), 0.001, 0.05, 1.0, 0.05, hold=dur)


def guitar_chord(root, dur, rng, mute=0.8):
    y = sum(ks_string(root + iv, dur, rng, mute) for iv in (0, 7, 12))
    y = saturate(y * 2.5, 12)
    y = filt(y, chain(hp(90, 2), bell(1800, 4, 1.2), lp(5200, 3)))
    return y * 0.3


def bass_note(m, dur, rng, kind="pulse", glide_from=None):
    t = t_axis(dur + 0.08)
    f = mtof(m)
    if kind == "808":
        f0 = mtof(glide_from) if glide_from is not None else f
        ff = f + (f0 - f) * np.exp(-t / 0.06)
        ph = 2 * math.pi * np.cumsum(ff) / SR
        y = saturate(np.sin(ph) * 1.6, 6) * adsr(len(t), 0.002, 0.3, 0.8, 0.15, hold=dur)
        y[:n_of(0.004)] += SFX._click(rng, 0.004, 1000, 6000)[: n_of(0.004)] * 0.3
        return y * 0.7
    sub = np.sin(2 * math.pi * f * t)
    if kind == "sub":
        return sub * adsr(len(t), 0.01, 0.3, 0.9, 0.2, hold=dur) * 0.6
    cutoff = {"pulse": 900, "arp16": 1400, "round": 500, "pick": 1800}[kind]
    harm = _saw(f, t, 24, 1.0, cutoff) * np.exp(-t * (6 if kind in ("pulse", "arp16") else 2))
    y = sub * 0.7 + harm * 0.6
    if kind == "pick":
        y[:n_of(0.003)] += SFX._click(rng, 0.003, 1500, 7000)[: n_of(0.003)] * 0.3
    return saturate(y, 3) * adsr(len(t), 0.004, 0.2, 0.85, 0.06, hold=dur) * 0.55


# ===================================================================== drums

def drum_kit(style, rng):
    k = {}
    t = t_axis(0.8)

    def kick(f0, f1, tau_p, tau_a, click=0.4, drive=4):
        f = f1 + (f0 - f1) * np.exp(-t / tau_p)
        y = np.sin(2 * math.pi * np.cumsum(f) / SR) * np.exp(-t / tau_a)
        y[:n_of(0.003)] += SFX._click(rng, 0.003, 1500, 9000)[: n_of(0.003)] * click
        return saturate(y, drive)

    def snare(tone, tau_n, bright):
        n = len(t)
        y = np.sin(2 * math.pi * tone * t) * np.exp(-t / 0.05) * 0.6
        y += filt(white(n, rng), bp(1200, 9000 * bright, 1)) * np.exp(-t / tau_n)
        return saturate(y, 3) * 0.7

    def clap():
        y = np.zeros(len(t))
        for i in range(4):
            nb = filt(white(n_of(0.02 if i < 3 else 0.25), rng), bp(900, 5000, 2))
            nb *= np.exp(-np.arange(len(nb)) / (len(nb) / 4))
            mix_into(y, nb, n_of(0.009 * i))
        return y * 0.9

    def hat(open_=False):
        y = sum(np.sign(np.sin(2 * math.pi * f * t)) for f in (205.3, 304.4, 369.6, 522.7, 540.0, 800.0))
        y = filt(y, hp(7000, 3)) * np.exp(-t / (0.25 if open_ else 0.035))
        return y * 0.25

    def shaker():
        n = n_of(0.12)
        y = filt(white(n, rng), bp(4000, 11000, 2)) * np.sin(np.linspace(0, math.pi, n)) ** 3
        return y * 0.4

    def taiko():
        f = 70 + 40 * np.exp(-t / 0.02)
        y = np.sin(2 * math.pi * np.cumsum(f) / SR) * np.exp(-t / 0.35)
        y += 0.4 * np.sin(2 * math.pi * np.cumsum(f * 1.52) / SR) * np.exp(-t / 0.15)
        y += filt(white(len(t), rng), lp(800, 2)) * np.exp(-t / 0.05) * 0.5
        return saturate(y, 4)

    def metal():
        f0 = rng.uniform(300, 700)
        return SFX._modal([f0 * r for r in (1, 2.2, 3.6, 5.3)], [0.25, 0.15, 0.08, 0.05], [1, .6, .4, .3], 0.8, rng) * 0.5

    def cowbell():
        y = (np.sign(np.sin(2 * math.pi * 540 * t)) + np.sign(np.sin(2 * math.pi * 800 * t)))
        return filt(y, bp(600, 3000, 2)) * np.exp(-t / 0.12) * 0.3

    if style == "none":
        return {}
    if style == "heartbeat":
        k["kick"] = filt(kick(85, 40, 0.03, 0.18, 0.05, 3), lp(400, 2))
        k["perc"] = filt(kick(95, 46, 0.03, 0.12, 0.05, 2), lp(400, 2)) * 0.6
        k["hat"] = filt(hat(), lp(9000, 1)) * 0.25
        return {n: v.astype(np.float64) for n, v in k.items()}
    if style == "frame":
        f = 150 + 60 * np.exp(-t / 0.015)
        frame = np.sin(2 * math.pi * np.cumsum(f) / SR) * np.exp(-t / 0.18) + filt(white(len(t), rng), bp(300, 3000, 1)) * np.exp(-t / 0.03) * 0.4
        k["kick"] = taiko() * 0.7
        k["snare"] = frame
        k["perc"] = shaker()
        k["hat"] = filt(frame, hp(600, 1)) * 0.5
        return {n: v.astype(np.float64) for n, v in k.items()}
    if style == "epic":
        style = "trailer"
        k["ohat"] = taiko() * 0.8
    if style in ("electro", "corporate"):
        k["kick"] = kick(150, 50, 0.03, 0.25, 0.3)
        k["snare"] = clap()
        k["hat"] = hat()
        k["ohat"] = hat(True)
        k["perc"] = shaker()
    elif style == "trailer":
        k["kick"] = taiko()
        k["snare"] = snare(190, 0.12, 0.7)
        k["hat"] = shaker()
        k.setdefault("ohat", shaker())
        k["perc"] = taiko() * 0.6
    elif style == "lofi":
        k["kick"] = filt(kick(110, 48, 0.025, 0.2, 0.15, 2), lp(3000, 1))
        k["snare"] = filt(snare(200, 0.08, 0.5), lp(5000, 1))
        k["hat"] = filt(hat(), lp(9000, 1)) * 0.7
        k["ohat"] = filt(hat(True), lp(9000, 1)) * 0.5
        k["perc"] = shaker() * 0.6
    elif style == "synthwave":
        k["kick"] = kick(160, 48, 0.03, 0.3, 0.5)
        k["snare"] = reverb(snare(210, 0.15, 1.0), "gated", 0.9, 3)[: len(t)].mean(axis=1) * 1.2
        k["hat"] = hat()
        k["ohat"] = hat(True)
        k["perc"] = clap()
    elif style == "rock":
        k["kick"] = kick(130, 55, 0.02, 0.2, 0.8)
        k["snare"] = snare(185, 0.14, 1.0)
        k["hat"] = hat() * 1.2
        k["ohat"] = hat(True)
        k["perc"] = snare(185, 0.05, 0.6) * 0.4
    elif style == "industrial":
        k["kick"] = kick(140, 45, 0.035, 0.35, 0.6, 6)
        k["snare"] = metal() + snare(170, 0.06, 0.8) * 0.5
        k["hat"] = filt(hat(), bp(5000, 12000, 1))
        k["ohat"] = metal() * 0.6
        k["perc"] = metal()
    elif style == "phonk":
        k["kick"] = kick(120, 45, 0.04, 0.4, 0.5, 6)
        k["snare"] = clap() + snare(220, 0.07, 1.0) * 0.5
        k["hat"] = hat()
        k["ohat"] = hat(True)
        k["perc"] = cowbell()
    return {n: v.astype(np.float64) for n, v in k.items()}


# Motifs à 16 pas : (instrument, pas, vélocité, probabilité)
PATTERNS = {
    "electro": [("kick", [0, 8], 1.0, 1), ("kick", [10], 0.7, 0.4), ("snare", [4, 12], 0.7, 1),
                ("hat", [2, 6, 10, 14], 0.6, 1), ("hat", [1, 3, 5, 7, 9, 11, 13, 15], 0.25, 0.7), ("perc", [3, 11], 0.4, 0.6)],
    "trailer": [("kick", [0, 6, 8], 1.0, 1), ("kick", [11, 14], 0.7, 0.6), ("perc", [4, 12], 0.6, 0.8),
                ("snare", [12], 0.6, 0.5), ("hat", list(range(0, 16, 2)), 0.3, 0.8)],
    "lofi": [("kick", [0, 7], 0.9, 1), ("kick", [10], 0.7, 0.6), ("snare", [4, 12], 0.75, 1),
             ("hat", list(range(0, 16, 2)), 0.5, 0.95), ("ohat", [14], 0.3, 0.3), ("perc", [6, 15], 0.3, 0.5)],
    "synthwave": [("kick", [0, 4, 8, 12], 1.0, 1), ("snare", [4, 12], 0.9, 1), ("hat", list(range(16)), 0.3, 1),
                  ("ohat", [2, 6, 10, 14], 0.35, 1)],
    "rock": [("kick", [0, 8], 1.0, 1), ("kick", [10, 3], 0.8, 0.5), ("snare", [4, 12], 1.0, 1),
             ("hat", list(range(0, 16, 2)), 0.55, 1), ("perc", [15], 0.5, 0.3)],
    "industrial": [("kick", [0, 6, 8], 1.0, 1), ("snare", [12], 0.8, 1), ("perc", [3, 9, 14], 0.5, 0.5),
                   ("hat", list(range(0, 16, 2)), 0.4, 0.9), ("ohat", [10], 0.5, 0.4)],
    "corporate": [("kick", [0, 4, 8, 12], 0.9, 1), ("snare", [4, 12], 0.8, 1), ("hat", [2, 6, 10, 14], 0.5, 1),
                  ("perc", list(range(16)), 0.25, 1)],
    "heartbeat": [("kick", [0], 0.9, 1), ("perc", [3], 0.7, 1), ("kick", [8], 0.6, 0.5), ("perc", [11], 0.45, 0.5),
                  ("hat", [6, 14], 0.2, 0.3)],
    "epic": [("kick", [0, 3, 6, 8, 11, 14], 1.0, 1), ("ohat", [4, 12], 0.9, 1), ("perc", [2, 10], 0.6, 0.7),
             ("snare", [12], 0.7, 0.8), ("hat", list(range(0, 16, 2)), 0.35, 0.9)],
    "frame": [("kick", [0, 10], 0.8, 1), ("snare", [3, 6, 8, 14], 0.6, 0.9), ("hat", [1, 5, 9, 13], 0.35, 0.7),
              ("perc", list(range(0, 16, 2)), 0.25, 0.8)],
    "phonk": [("kick", [0, 3, 10], 1.0, 1), ("kick", [6, 14], 0.8, 0.4), ("snare", [8], 1.0, 1),
              ("hat", list(range(16)), 0.35, 1), ("hat", [13, 15], 0.3, 0.5), ("perc", [0, 3, 6, 10, 12], 0.45, 0.8)],
}


# ===================================================================== composition

def _voice_chord(degree, scale, tonic, sevenths, prev, center=60):
    pcs = [scale[(degree + k) % 7] + 12 * ((degree + k) // 7) for k in ((0, 2, 4, 6) if sevenths else (0, 2, 4))]
    base = [tonic + p for p in pcs]
    cands = []
    for inv in range(len(base)):
        v = sorted(base[inv:] + [b + 12 for b in base[:inv]])
        for octv in (-24, -12, 0, 12):
            w = [x + octv for x in v]
            if 48 <= min(w) and max(w) <= 79:
                cands.append(w)
    if not cands:
        cands = [base]
    if prev is None:
        return min(cands, key=lambda w: abs(np.mean(w) - center))
    return min(cands, key=lambda w: sum(min(abs(a - b) for b in prev) for a in w) + 0.3 * abs(np.mean(w) - center))


class Composer:
    def __init__(self, direction: str, seed: int, niche: str = "auto", gamme: str | None = None):
        self.d = (DOC_DIRECTIONS if niche == "doc" else DIRECTIONS)[direction]
        self.gamme = GAMMES.get(gamme) if gamme else None
        self.direction = direction
        self.rng = np.random.default_rng(seed)
        self.bpm = float(self.rng.uniform(*self.d["bpm"]))
        self.tonic = int(self.rng.integers(45, 52))  # La1..Ré#2 : basse grave, harmonie au-dessus
        self.kit = drum_kit(self.d["kit"], self.rng)
        self.prog_minor = PROG_MINOR[int(self.rng.integers(len(PROG_MINOR)))]
        self.prog_major = PROG_MAJOR[int(self.rng.integers(len(PROG_MAJOR)))]
        self.motif = [int(x) for x in self.rng.choice([0, 1, 2, 3, 4, 5, 6], 4, replace=False)]
        self._cache: dict = {}

    @property
    def beat(self):
        return 60.0 / self.bpm

    @property
    def bar(self):
        return 4 * self.beat

    def _cached(self, key, fn):
        if key not in self._cache:
            self._cache[key] = fn()
        return self._cache[key]

    def section(self, seconds: float, mood: str, first: bool = False, last: bool = False, chunk_bars: int = 24,
                intensite: int | None = None):
        """Rend un acte de « seconds » secondes, par morceaux de chunk_bars mesures (mémoire bornée) ;
        les queues de réverbération de chaque morceau débordent sur le suivant."""
        bars = max(2, int(math.ceil(seconds / self.bar)))
        out = np.zeros((n_of(bars * self.bar + 3.0), 2), dtype=np.float32)
        prev = None
        for b0 in range(0, bars, chunk_bars):
            b1 = min(bars, b0 + chunk_bars)
            seg, prev = self._bars(b0, b1, bars, mood, first, last, prev, intensite)
            mix_into(out, seg, n_of(b0 * self.bar))
        return out

    def _bars(self, b0, b1, bars, mood, first, last, prev, intensite=None):
        M = MOODS[mood]
        rng = self.rng
        scale = SCALES[M["mode"]]
        if self.gamme and M["mode"] in ("aeolian", "phrygian", "dorian"):
            scale = self.gamme["harm"]
        if self.direction == "D6" and mood in ("tension", "sombre"):
            scale = SCALES["phrygian"]
        minor = M["mode"] in ("aeolian", "phrygian", "dorian")
        tonic = self.tonic + (0 if minor else 3)  # relatif majeur : mêmes notes, couleur claire
        prog = self.prog_minor if minor else self.prog_major
        n = n_of((b1 - b0) * self.bar + 3.0)
        bus = {k: np.zeros((n, 2)) for k in ("drums", "bass", "harm", "top")}
        kicks = []
        step = self.bar / 16
        swing = self.d["swing"]
        intens = INTENSITE.get(intensite, M["intensity"]) if intensite else M["intensity"]
        bright = M["bright"]
        for b in range(b0, b1):
            t0 = (b - b0) * self.bar
            phrase = b % 8
            deg = prog[b % len(prog)]
            chord = _voice_chord(deg, scale, tonic + 12, self.d["sevenths"], prev)
            prev = chord
            root = tonic + scale[deg % 7] - 12 * (1 if tonic + scale[deg % 7] > 52 else 0)
            build = (first and b < 4)
            breath = (b >= bars - 1 and not last)  # respiration avant l'acte suivant
            drums_on = bool(self.kit) and not build and not breath and (intens > 0.55 or b % 8 >= 2) and intens >= 0.4
            # ---- harmonie
            key = ("harm", tuple(chord), round(self.bar, 3), mood)
            hk = self.d["harm"]
            if hk in ("pad", "strings", "drone"):
                fn = {"pad": lambda: pad(chord, self.bar, rng, bright, 0.5 if intens > 0.6 else 0.9),
                      "strings": lambda: strings(chord, self.bar, rng, bright),
                      "drone": lambda: pad([chord[0] - 12, chord[0], chord[2]], self.bar, rng, bright * 0.5, 1.2, 3, 0.02)
                      }[hk]
                mix_into(bus["harm"], self._cached(key, fn), n_of(t0), 0.9)
            elif hk == "epiano":
                for i, beatpos in enumerate((0, 1.5, 2.5) if phrase % 2 else (0, 2)):
                    for j, m in enumerate(chord):
                        a = self._cached(("ep", m, mood), lambda m=m: epiano(m, self.beat * 1.5, rng, bright))
                        mix_into(bus["harm"], pan(a, (j - 1.5) * 0.3), n_of(t0 + beatpos * self.beat + 0.012 * j), 0.5)
            elif hk == "pluck":
                for s in range(8):
                    m = chord[s % len(chord)] + (12 if s % 4 == 3 else 0)
                    a = self._cached(("pl", m, mood), lambda m=m: pluck(m, self.beat / 2, rng, bright))
                    mix_into(bus["harm"], pan(a, 0.35 if s % 2 else -0.35), n_of(t0 + s * self.beat / 2), 0.6)
            elif hk == "guitar":
                if not build:
                    for s in range(8):
                        accent = s in (0, 3, 6)
                        a = self._cached(("gt", root, accent), lambda: guitar_chord(root + 12, self.beat / 2, rng, 0.5 if accent else 0.9))
                        mix_into(bus["harm"], pan(a, -0.6), n_of(t0 + s * self.beat / 2), 0.9 if accent else 0.6)
                        mix_into(bus["harm"], pan(a, 0.6), n_of(t0 + s * self.beat / 2 + 0.011), 0.9 if accent else 0.6)
                pd = self._cached(("gpad", tuple(chord)), lambda: pad(chord, self.bar, rng, 0.4, 1.0, 3))
                mix_into(bus["harm"], pd, n_of(t0), 0.35)
            # ---- basse
            bk = self.d["bass"]
            if not build or b >= 2:
                if bk == "808":
                    for s, ln in ((0, 0.75), (6, 0.25), (10, 0.5)):
                        a = self._cached(("808", root, s), lambda s=s, ln=ln: bass_note(root, self.bar * ln * 0.9, rng, "808",
                                                                                    root + 12 if s == 10 else None))
                        mix_into(bus["bass"], a, n_of(t0 + s * step), 1.0)
                elif bk == "arp16":
                    for s in range(16):
                        m = root + (12 if s % 2 else 0)
                        a = self._cached(("b16", m), lambda m=m: bass_note(m, step * 0.8, rng, "arp16"))
                        mix_into(bus["bass"], a, n_of(t0 + s * step), 0.8)
                elif bk == "pulse":
                    for s in range(0, 16, 2):
                        a = self._cached(("bp", root), lambda: bass_note(root, step * 1.6, rng, "pulse"))
                        mix_into(bus["bass"], a, n_of(t0 + s * step), 0.85 if s % 4 else 1.0)
                elif bk == "sub":
                    a = self._cached(("bs", root, round(self.bar, 3)), lambda: bass_note(root, self.bar * 0.95, rng, "sub"))
                    mix_into(bus["bass"], a, n_of(t0), 1.0)
                else:  # round / pick
                    for s, ln in ((0, 5), (6, 2), (8, 4), (14, 2)) if bk == "round" else tuple((s, 2) for s in range(0, 16, 2)):
                        a = self._cached(("br", root, ln, bk), lambda ln=ln: bass_note(root, step * ln * 0.9, rng, bk))
                        mix_into(bus["bass"], a, n_of(t0 + s * step), 1.0)
            # ---- dessus
            tk = self.d["top"]
            if tk_piano := (self.d["top"] == "piano" and not build):
                for s_ in range(0, 16, 2):
                    m = chord[(s_ // 2) % len(chord)] + (12 if s_ in (6, 14) else 0)
                    a = self._cached(("pno", m), lambda m=m: piano(m, self.beat * 1.2, rng, bright))
                    mix_into(bus["top"], pan(a, (m - 66) / 30), n_of(t0 + s_ * step + rng.normal(0, 0.006)),
                             0.55 if s_ % 8 == 0 else 0.4)
            if intens >= 0.6 and not build and phrase >= 4 and not tk_piano:
                if tk == "arp":
                    order = chord + [chord[1] + 12, chord[2] + 12] if len(chord) == 3 else chord + [chord[0] + 12]
                    for s in range(16):
                        m = order[(s * 3) % len(order)] + 12
                        a = self._cached(("arp", m, mood), lambda m=m: pluck(m, step, rng, bright * 0.7))
                        mix_into(bus["top"], a, n_of(t0 + s * step), 0.35)
                elif tk == "ostinato":
                    for s in range(16):
                        m = root + 24 + (scale[2] if s % 4 == 2 else 0) + (12 if s % 8 == 7 else 0)
                        a = self._cached(("st", m), lambda m=m: stacc(m, step * 0.7, rng, bright))
                        mix_into(bus["top"], pan(a, (s % 2) * 0.6 - 0.3), n_of(t0 + s * step), 0.4 + 0.2 * (s % 4 == 0))
                elif tk == "bells" and phrase in (4, 6):
                    for i, dg in enumerate(self.motif):
                        m = tonic + 24 + scale[dg]
                        a = self._cached(("bell", m), lambda m=m: bellnote(m, 1, rng))
                        mix_into(bus["top"], pan(a, 0.3), n_of(t0 + i * self.beat), 0.5)
                elif tk == "cowbell":
                    for s in (0, 3, 6, 10, 12):
                        m = tonic + 36 + scale[self.motif[s % 4]]
                        tt = t_axis(0.25)
                        f = mtof(m)
                        a = filt((np.sign(np.sin(2 * math.pi * f * tt)) + np.sign(np.sin(2 * math.pi * f * 1.48 * tt))),
                                 bp(500, 4000, 2)) * np.exp(-tt / 0.09) * 0.18
                        mix_into(bus["top"], pan(a, 0.2), n_of(t0 + s * step), 1.0)
                elif tk == "motif":
                    sc = self.gamme["motif"] if self.gamme else scale
                    for i, s_ in enumerate((0, 3, 6, 10) if phrase % 2 == 0 else (0, 6, 8)):
                        m = tonic + 24 + sc[self.motif[i % 4] % len(sc)]
                        a = self._cached(("mot", m), lambda m=m: pluck(m, self.beat, rng, 0.8))
                        mix_into(bus["top"], pan(a, 0.25), n_of(t0 + s_ * step), 0.6)
                elif tk == "metal":
                    for s in rng.choice(16, 3, replace=False):
                        mix_into(bus["top"], pan(self.kit["perc"], rng.uniform(-0.8, 0.8)), n_of(t0 + s * step), 0.3)
            # ---- batterie
            if drums_on:
                fill = (phrase == 7)
                for inst, steps, vel, prob in PATTERNS[self.d["kit"]]:
                    for s in steps:
                        if fill and s >= 12 and inst != "kick":
                            continue
                        if rng.random() > prob:
                            continue
                        tt = t0 + s * step
                        if swing and s % 2 == 1:
                            tt += (swing - 0.5) * 2 * step
                        tt += rng.normal(0, 0.003)
                        v = vel * rng.uniform(0.85, 1.0) * (0.75 + 0.25 * intens)
                        snd = self.kit[inst]
                        p = {"hat": 0.25, "ohat": -0.25, "perc": -0.35}.get(inst, 0.0)
                        mix_into(bus["drums"], pan(snd, p), n_of(tt), v)
                        if inst == "kick":
                            kicks.append(tt)
                if fill:
                    for s in range(12, 16):
                        mix_into(bus["drums"], stereo(self.kit["snare"]), n_of(t0 + s * step), 0.35 + 0.12 * (s - 12))
            if breath:
                r, _ = SFX.reverse_swell(rng, min(self.bar * 0.9, 1.6))
                mix_into(bus["top"], r, n_of(t0 + self.bar) - len(r), 0.25)
        return self._mixdown(bus, kicks, n).astype(np.float32), prev

    def _mixdown(self, bus, kicks, n):
        pump = np.ones(n)
        depth = self.d["pump"]
        if depth > 0 and kicks:
            imp = np.zeros(n)
            for k in kicks:
                i = n_of(max(0.0, k))
                if i < n:
                    imp[i] = 1
            kern = np.exp(-np.arange(n_of(0.35)) / (0.09 * SR)) * depth
            kern[:n_of(0.005)] *= np.linspace(0, 1, n_of(0.005))
            pump = 1 - np.minimum(depth, convolve(imp, kern))
        space = self.d["space"]
        drums = filt(bus["drums"], chain(hp(30, 2), shelf(9000, 1.5)))
        drums = drums + reverb(drums, "room", 0.12, 2, tail=False)
        bass = filt(bus["bass"], chain(hp(32, 3), lp(5000, 2))) * pump[:, None]
        bass = mono(bass)[:, None] * np.ones((1, 2))  # basse en mono
        harm = filt(bus["harm"], chain(hp(140, 2), bell(350, -2.5, 1.2))) * pump[:, None]
        harm = reverb(harm, space, 0.35, 5, tail=False)
        top = filt(bus["top"], chain(hp(300, 2), bell(3000, -1.5, 1.0)))
        top = top + convolve(top, delay_ir(self.beat * 0.75, 0.35, 4)) * 0.35
        top = reverb(top, space, 0.4, 6, tail=False) * pump[:, None]
        mix = drums * 0.9 + bass * 0.85 + harm * 0.8 + top * 0.6
        mix = compressor(mix, -20, 2.0, 0.02, 0.2, 6)
        mix = saturate(mix * 0.9, 1.5, 0.5)
        return mix


def compose(direction: str, acts: list[dict], total: float, seed: int, lufs: float = -18.0, niche: str = "auto",
            gamme: str | None = None):
    """acts = [{start, end, mood}], couvre [0, total]. Fondus croisés de 2 s, fin en fondu de 2 s."""
    comp = Composer(direction, seed, niche, gamme)
    xf = 2.0
    out = np.zeros((n_of(total + 0.5), 2), np.float32)
    for i, a in enumerate(acts):
        s = max(0.0, float(a["start"]) - (xf / 2 if i else 0))
        e = min(total, float(a["end"]) + (xf / 2 if i < len(acts) - 1 else 0))
        seg = comp.section(e - s, a["mood"], first=(i == 0), last=(i == len(acts) - 1), intensite=a.get("intensite"))
        seg = match_lufs(seg[: n_of(e - s)], lufs)
        seg = fade(seg, xf if i else 0.01, xf if i < len(acts) - 1 else 2.0)
        mix_into(out, seg, n_of(s))
    out = out[: n_of(total)]
    return limiter(out, -1.0), {"bpm": round(comp.bpm, 2), "tonique_midi": comp.tonic, "direction": direction,
                                "nom": comp.d["nom"]}
