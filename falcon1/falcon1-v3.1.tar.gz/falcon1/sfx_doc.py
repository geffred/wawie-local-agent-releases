"""Sons supplémentaires pour les documentaires (papier, bureau, organique, horlogerie, silences dramatiques,
et quelques sons propres aux grandes niches : enquête, jeu vidéo, combat, célébrités, histoire).
Même contrat que sfx.py : chaque fonction renvoie (audio stéréo, instant du pic)."""
from __future__ import annotations

import math

import numpy as np

from .dsp import (SR, n_of, t_axis, stereo, mono, pan, fade, peak_normalize, adsr, exp_decay, smooth_random, white,
                  pink, brown, filt, lp, hp, bp, bell, chain, stft_shape, band_gain, saturate, widen, reverb, mix_into,
                  mtof)
from .sfx import _u, _modal, _click, _finish, CATALOGUE, coins


# ---------------------------------------------------------------- papier / bureau

def page_turn(rng):
    dur = _u(rng, 0.45, 0.7)
    n = n_of(dur)
    t = np.arange(n) / SR
    flutter = 0.55 + 0.45 * np.abs(np.sin(2 * math.pi * np.cumsum(_u(rng, 25, 45) * (1 - 0.6 * t / dur)) / SR))
    y = filt(white(n, rng), bp(700, 7000, 1)) * flutter * np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 0.8
    slap = filt(white(n_of(0.05), rng), bp(300, 3000, 1)) * exp_decay(n_of(0.05), 0.012)
    mix_into(y, slap * 0.8, n - n_of(0.06))
    return _finish(pan(y, np.linspace(-0.4, 0.4, n)), "room", 0.1, 41, -4.0), dur - 0.06


def stamp(rng):
    out = np.zeros(n_of(0.6))
    t = t_axis(0.3)
    thump = np.sin(2 * math.pi * np.cumsum(90 + 80 * np.exp(-t / 0.01)) / SR) * np.exp(-t / 0.06)
    wood = _modal([_u(rng, 170, 210), _u(rng, 390, 450), _u(rng, 650, 760)], [0.05, 0.03, 0.02], [1, .6, .3], 0.3, rng)
    slap = filt(white(len(t), rng), bp(400, 4000, 1)) * np.exp(-t / 0.008)
    mix_into(out, thump + wood * 0.6 + slap * 0.7, 0)
    return _finish(out, "room", 0.12, 42, -2.0), 0.0


def typewriter(rng, keys=None):
    keys = keys or int(_u(rng, 6, 12))
    out = np.zeros(n_of(keys / 9 + 1.2))
    pos = 0.0
    for k in range(keys):
        c = _modal([_u(rng, 1800, 2600), _u(rng, 3500, 4800)], [0.012, 0.006], [1, .5], 0.05, rng, 0.03)
        c[:n_of(0.001)] += _click(rng, 0.001, 1500, 12000)
        thunk = np.sin(2 * math.pi * 160 * t_axis(0.04)) * exp_decay(n_of(0.04), 0.008)
        mix_into(out, c * _u(rng, 0.6, 1.0) + np.pad(thunk, (0, len(c) - len(thunk))) * 0.5, n_of(pos))
        pos += _u(rng, 0.07, 0.16)
    if rng.random() < 0.6:
        b = _modal([_u(rng, 2900, 3300), 7600], [0.5, 0.2], [1, .3], 1.0, rng)
        mix_into(out, b * 0.4, n_of(pos + 0.05))
    return _finish(out, "room", 0.1, 43, -4.0), 0.0


def pen_scribble(rng):
    dur = _u(rng, 0.7, 1.2)
    n = n_of(dur)
    strokes = np.clip(smooth_random(n, 9, rng), 0, 1) ** 0.7
    y = filt(white(n, rng), bp(2200, 7000, 2)) * strokes * 0.5
    return _finish(fade(y, 0.02, 0.05), "room", 0.05, 44, -6.0), 0.0


def drawer(rng):
    dur = _u(rng, 0.5, 0.8)
    n = n_of(dur)
    slide = stft_shape(white(n, rng), band_gain(lambda t: 900 + 700 * np.clip(t / dur, 0, 1), 1.2), 512, 128)
    slide *= np.sin(np.pi * np.arange(n) / n) ** 0.6 * 0.4
    out = np.zeros(n + n_of(0.5))
    out[:n] += slide
    clunk = _modal([_u(rng, 300, 420), _u(rng, 900, 1200), 2300], [0.15, 0.08, 0.04], [1, .5, .3], 0.4, rng)
    mix_into(out, clunk * 0.8, n - n_of(0.02))
    return _finish(out, "room", 0.15, 45, -3.0), dur


def camera_shutter(rng):
    out = np.zeros(n_of(0.35))
    for k, at in enumerate((0.0, _u(rng, 0.05, 0.09))):
        c = _modal([_u(rng, 2500, 3200), 5200, 900], [0.006, 0.004, 0.012], [1, .5, .6], 0.03, rng)
        c[:n_of(0.0008)] += _click(rng, 0.0008, 1500, 14000)
        mix_into(out, c, n_of(at))
    spring = filt(white(n_of(0.05), rng), bp(3000, 9000, 2)) * exp_decay(n_of(0.05), 0.01) * 0.2
    mix_into(out, spring, n_of(0.01))
    return _finish(out, "room", 0.06, 46, -4.0), 0.0


def flash_photo(rng):
    """Flash de photographe : sifflement de charge + déclencheur."""
    whine_d = _u(rng, 0.35, 0.6)
    t = t_axis(whine_d)
    whine = np.sin(2 * math.pi * np.cumsum(3000 + 5000 * t / whine_d) / SR) * (t / whine_d) * 0.15
    s, _ = camera_shutter(rng)
    out = np.zeros((len(t) + len(s), 2))
    mix_into(out, whine, 0)
    mix_into(out, s, len(t))
    return peak_normalize(out, -4.0), whine_d


def projector(rng, seconds=3.0):
    """Projecteur de film (archives) : claquement à 24 i/s + moteur ; bouclable."""
    n = n_of(seconds)
    out = np.zeros(n)
    rate = 24.0
    for k in range(int(seconds * rate)):
        c = _click(rng, 0.004, 800, 6000) * _u(rng, 0.4, 0.7)
        mix_into(out, c, n_of(k / rate))
    t = np.arange(n) / SR
    out += filt(sum(np.sin(2 * math.pi * 75 * h * t) / h for h in range(1, 6)), lp(600, 2)) * 0.05
    return _finish(out, "room", 0.1, 47, -8.0), 0.0


# ---------------------------------------------------------------- horlogerie / tension

def clock_tick(rng, seconds=4.0):
    period = _u(rng, 0.95, 1.05)
    out = np.zeros(n_of(seconds))
    k = 0
    while k * period < seconds - 0.1:
        f = _u(rng, 2800, 3400) if k % 2 == 0 else _u(rng, 2200, 2700)
        c = _modal([f, f * 1.7, 600], [0.008, 0.005, 0.02], [1, .4, .5], 0.05, rng, 0.01)
        c[:n_of(0.0008)] += _click(rng, 0.0008, 1500, 10000)
        mix_into(out, c, n_of(k * period))
        k += 1
    return _finish(out, "room", 0.15, 48, -6.0), 0.0


def gear(rng):
    dur = _u(rng, 0.8, 1.3)
    out = np.zeros(n_of(dur + 0.4))
    rate = _u(rng, 7, 11)
    for k in range(int(dur * rate)):
        c = _modal([_u(rng, 500, 700), _u(rng, 1300, 1700), 2900], [0.04, 0.02, 0.01], [1, .6, .3], 0.1, rng, 0.03)
        mix_into(out, c, n_of(k / rate))
    out += filt(white(len(out), rng), bp(300, 2500, 1)) * 0.06 * np.clip(np.arange(len(out)) / n_of(dur), 0, 1)[::-1]
    return _finish(out, "garage", 0.15, 49, -4.0), 0.0


def heartbeat(rng, beats=None):
    """Battement sourd (style de silence Q3s) : lub-dub grave."""
    beats = beats or int(_u(rng, 2, 4))
    period = _u(rng, 0.8, 1.0)
    out = np.zeros(n_of(beats * period + 0.6))
    for k in range(beats):
        for j, (f, a) in enumerate(((_u(rng, 48, 56), 1.0), (_u(rng, 58, 66), 0.65))):
            t = t_axis(0.25)
            th = np.sin(2 * math.pi * np.cumsum(f * (1 + 0.6 * np.exp(-t / 0.02))) / SR) * np.exp(-t / 0.07)
            mix_into(out, saturate(th, 3) * a, n_of(k * period + j * 0.18))
    out = filt(out, lp(180, 2))
    return _finish(out, "room", 0.08, 50, -2.0), 0.0


def note_tenue(rng, seconds=None):
    """Note tenue qui s'éteint (style de silence Q4s) : quinte douce, battements lents."""
    seconds = seconds or _u(rng, 2.5, 4.0)
    t = t_axis(seconds)
    f = mtof(int(rng.integers(52, 60)))
    y = sum(a * np.sin(2 * math.pi * f * r * (1 + d) * t) for r, a in ((1, 1), (1.5, .5), (2, .3)) for d in (-0.002, 0.002))
    y *= adsr(len(t), 0.4, 0.5, 0.8, seconds * 0.6, hold=seconds * 0.35)
    return _finish(widen(y, 0.7, rng), "cathedral", 0.4, 51, -6.0), 0.4


def bell_toll(rng):
    """Cloche d'église lointaine (histoire, deuil)."""
    f0 = _u(rng, 180, 260)
    y = _modal([f0 * r for r in (0.5, 1, 1.183, 1.506, 2.0, 2.514, 2.662)], [4, 3, 2.2, 1.8, 1.4, 1.0, 0.9],
               [.6, 1, .5, .4, .35, .2, .2], 5.0, rng)
    return _finish(filt(y, lp(3500, 1)), "cathedral", 0.35, 52, -3.0, 0.4, rng), 0.0


def thunder(rng):
    dur = _u(rng, 3.5, 5.5)
    n = n_of(dur)
    t = np.arange(n) / SR
    crack = filt(white(n, rng), hp(800, 1)) * np.exp(-t / 0.08) * 0.6
    roll = filt(brown(n, rng), lp(220, 2)) * (np.exp(-t / (dur * 0.35)) * (1 + 0.6 * smooth_random(n, 3, rng)))
    return _finish(widen(crack + roll * 1.5, 0.8, rng), "hall", 0.2, 53, -1.5), 0.02


# ---------------------------------------------------------------- organique

def breath(rng):
    dur = _u(rng, 0.9, 1.5)
    n = n_of(dur)
    y = filt(pink(n, rng), bp(350, 2500, 1)) * np.sin(np.pi * np.arange(n) / n) ** 1.5
    return _finish(y, "room", 0.1, 54, -6.0), dur * 0.5


def wind_gust(rng):
    dur = _u(rng, 1.6, 2.6)
    n = n_of(dur)
    c = lambda t: 450 + 650 * np.sin(np.pi * np.clip(t / dur, 0, 1))
    y = stft_shape(pink(n, rng), band_gain(c, 1.3), 2048, 512) * np.sin(np.pi * np.arange(n) / n) ** 1.2
    return _finish(widen(y, 0.8, rng), "room", 0.05, 55, -3.0), dur * 0.5


def water_splash(rng):
    out = np.zeros(n_of(1.2))
    burst = filt(white(n_of(0.25), rng), bp(400, 6000, 1)) * exp_decay(n_of(0.25), 0.06)
    mix_into(out, burst, 0)
    for _ in range(int(_u(rng, 6, 12))):
        d = _u(rng, 0.02, 0.05)
        tt = t_axis(d)
        b = np.sin(2 * math.pi * np.cumsum(_u(rng, 400, 1200) * (1 + tt / d)) / SR) * np.sin(np.pi * tt / d) ** 2
        mix_into(out, b * _u(rng, 0.2, 0.5), n_of(_u(rng, 0.02, 0.6)))
    return _finish(out, "room", 0.12, 56, -3.0), 0.0


def wood_knock(rng):
    out = np.zeros(n_of(0.6))
    for k in range(int(_u(rng, 1, 3))):
        w = _modal([_u(rng, 180, 240), _u(rng, 480, 600), _u(rng, 900, 1100)], [0.06, 0.03, 0.015], [1, .7, .3], 0.2, rng)
        w[:n_of(0.001)] += _click(rng, 0.001, 800, 8000) * 0.5
        mix_into(out, w, n_of(k * 0.16))
    return _finish(out, "room", 0.12, 57, -3.0), 0.0


def fire_whoosh(rng):
    dur = _u(rng, 1.0, 1.6)
    n = n_of(dur)
    t = np.arange(n) / SR
    roar = filt(brown(n, rng), lp(900, 2)) * (1 - np.exp(-t / 0.05)) * np.exp(-t / (dur * 0.6))
    out = roar * 1.4
    for _ in range(int(_u(rng, 15, 30))):
        mix_into(out, _click(rng, 0.003, 1500, 9000) * _u(rng, 0.1, 0.4), n_of(_u(rng, 0, dur)))
    return _finish(out, "room", 0.1, 58, -2.0), 0.03


# ---------------------------------------------------------------- niches

def police_radio(rng):
    dur = _u(rng, 0.8, 1.2)
    n = n_of(dur)
    st = filt(white(n, rng), bp(500, 3000, 3)) * (0.5 + 0.5 * (smooth_random(n, 20, rng) > 0)) * 0.5
    out = np.zeros(n + n_of(0.2))
    out[:n] += st
    t = t_axis(0.12)
    mix_into(out, np.sin(2 * math.pi * _u(rng, 1100, 1400) * t) * 0.4, n)
    return _finish(fade(out, 0.005, 0.02), "room", 0.05, 59, -5.0), 0.0


def siren_far(rng):
    dur = _u(rng, 3.0, 4.5)
    t = t_axis(dur)
    f = 700 + 350 * (0.5 + 0.5 * np.sin(2 * math.pi * _u(rng, 0.25, 0.4) * t))
    y = np.sin(2 * math.pi * np.cumsum(f) / SR) + 0.3 * np.sin(4 * math.pi * np.cumsum(f) / SR)
    y = filt(y, lp(1800, 2)) * adsr(len(t), 0.6, 0.2, 1.0, 1.0)
    return _finish(widen(y, 0.6, rng), "hall", 0.45, 60, -8.0), dur * 0.5


def blade_clash(rng):
    f0 = _u(rng, 1800, 2600)
    y = _modal([f0 * r for r in (1, 1.41, 2.13, 2.97, 4.1)], [0.9, 0.6, 0.4, 0.25, 0.15], [1, .7, .5, .3, .2], 1.6, rng)
    y[:n_of(0.004)] += _click(rng, 0.004, 2000, 14000) * 1.2
    return _finish(y, "hall", 0.25, 61, -2.0, 0.3, rng), 0.0


def body_hit(rng):
    """Coup porté (arts martiaux) : impact sourd + tissu."""
    t = t_axis(0.4)
    thud = np.sin(2 * math.pi * np.cumsum(70 + 90 * np.exp(-t / 0.012)) / SR) * np.exp(-t / 0.07)
    cloth = filt(white(len(t), rng), bp(800, 5000, 1)) * np.exp(-t / 0.03) * 0.6
    return _finish(saturate(thud * 1.4, 4) + cloth, "room", 0.1, 62, -1.5), 0.0


def ui_select(rng):
    """Bip de menu 8 bits (jeu vidéo)."""
    out = np.zeros(n_of(0.25))
    for k, m in enumerate((int(rng.integers(76, 84)), None)):
        if m is None:
            m = 79 + int(rng.integers(3, 8))
        t = t_axis(0.06)
        sq = np.sign(np.sin(2 * math.pi * mtof(m) * t)) * 0.3
        mix_into(out, sq * fade(np.ones(len(t)), 0.001, 0.01), n_of(0.06 * k))
    return _finish(filt(out, lp(9000, 1)), None, 0, 63, -8.0), 0.0


def level_up(rng):
    out = np.zeros(n_of(0.9))
    base = int(rng.integers(68, 74))
    for k, iv in enumerate((0, 4, 7, 12, 16)):
        t = t_axis(0.12 if k < 4 else 0.4)
        sq = (np.sign(np.sin(2 * math.pi * mtof(base + iv) * t)) * 0.25) * fade(np.ones(len(t)), 0.001, 0.03)
        mix_into(out, sq, n_of(0.08 * k))
    return _finish(filt(out, lp(8000, 1)), "room", 0.1, 64, -6.0), 0.32


def applause(rng):
    dur = _u(rng, 2.0, 3.0)
    n = n_of(dur)
    out = np.zeros((n, 2))
    k = 0
    while k < n:
        g = n_of(_u(rng, 0.004, 0.012))
        c = filt(white(g, rng), bp(_u(rng, 600, 1500), _u(rng, 3000, 7000), 1)) * np.hanning(g)
        mix_into(out, pan(c, _u(rng, -1, 1)), k, _u(rng, 0.3, 1))
        k += n_of(_u(rng, 0.001, 0.006))
    out *= adsr(n, 0.3, 0.2, 0.9, 0.8)[:, None]
    return _finish(out, "hall", 0.2, 65, -4.0), 0.4


DOC_SOUNDS = {
    "page_turn": (page_turn, "papier", "page de document, archive, chapitre"),
    "stamp": (stamp, "papier", "tampon, verdict, sceau"),
    "typewriter": (typewriter, "papier", "texte tapé, rapport, carte chapitre C4"),
    "pen_scribble": (pen_scribble, "papier", "signature, annotation"),
    "drawer": (drawer, "papier", "dossier, classeur"),
    "camera_shutter": (camera_shutter, "papier", "photo d'archive qui apparaît"),
    "projector": (projector, "papier", "archive filmée (sous le plan)"),
    "clock_tick": (clock_tick, "meca", "compte à rebours, heure exacte"),
    "gear": (gear, "meca", "mécanisme, engrenage, machine"),
    "heartbeat": (heartbeat, "cinema", "silence Q3s, tension avant révélation"),
    "note_tenue": (note_tenue, "cinema", "silence Q4s, émotion"),
    "bell_toll": (bell_toll, "organique", "histoire, deuil, époque"),
    "thunder": (thunder, "organique", "orage, menace, climax"),
    "breath": (breath, "organique", "souffle, transition douce"),
    "wind_gust": (wind_gust, "organique", "vent, lieu extérieur, transition"),
    "water_splash": (water_splash, "organique", "eau, mer, plongée"),
    "wood_knock": (wood_knock, "organique", "bois, porte, coup frappé"),
    "fire_whoosh": (fire_whoosh, "organique", "feu, embrasement"),
    "police_radio": (police_radio, "num", "enquête, true crime"),
    "siren_far": (siren_far, "organique", "ville la nuit, urgence (lointain)"),
    "blade_clash": (blade_clash, "meca", "lames, arts martiaux, histoire militaire"),
    "body_hit": (body_hit, "cinema", "coup porté, combat"),
    "ui_select": (ui_select, "num", "jeu vidéo, menu"),
    "level_up": (level_up, "num", "jeu vidéo, progression"),
    "flash_photo": (flash_photo, "papier", "célébrités, paparazzi, tapis rouge"),
    "applause": (applause, "organique", "scène, cérémonie, victoire"),
}

for _k, _v in DOC_SOUNDS.items():
    CATALOGUE.setdefault(_k, _v)
