"""Briques DSP du moteur son Falcon 1 : numpy seul (ffmpeg en option pour l'encodage).

Tout travaille en 48 kHz, flottant. Les signaux stéréo ont la forme (n, 2).
Les filtres sont appliqués dans le domaine fréquentiel, en phase minimale par défaut
(pas de pré-écho devant les attaques), ou en phase nulle pour l'analyse.
"""
from __future__ import annotations

import math
import shutil
import subprocess
import wave

import numpy as np

SR = 48000
F32 = np.float32


# ---------------------------------------------------------------- bases

def n_of(seconds: float) -> int:
    return max(1, int(round(seconds * SR)))


def t_axis(seconds: float) -> np.ndarray:
    return np.arange(n_of(seconds)) / SR


def db(x):
    return 20.0 * np.log10(np.maximum(np.abs(x), 1e-12))


def undb(d):
    return 10.0 ** (np.asarray(d) / 20.0)


def mtof(m):
    return 440.0 * 2.0 ** ((np.asarray(m, dtype=float) - 69.0) / 12.0)


def stereo(x: np.ndarray) -> np.ndarray:
    return x if x.ndim == 2 else np.stack([x, x], axis=1)


def mono(x: np.ndarray) -> np.ndarray:
    return x if x.ndim == 1 else x.mean(axis=1)


def pad_to(x: np.ndarray, n: int) -> np.ndarray:
    if x.shape[0] >= n:
        return x[:n]
    shape = (n - x.shape[0],) + x.shape[1:]
    return np.concatenate([x, np.zeros(shape, x.dtype)])


def pan(x: np.ndarray, p) -> np.ndarray:
    """Panoramique à puissance constante. p dans [-1, 1], scalaire ou courbe."""
    x = mono(x)
    p = np.clip(np.asarray(p, dtype=float), -1, 1)
    a = (p + 1) * math.pi / 4
    return np.stack([x * np.cos(a), x * np.sin(a)], axis=1)


def fade(x: np.ndarray, fin: float = 0.002, fout: float = 0.005) -> np.ndarray:
    x = x.copy()
    a, b = min(n_of(fin), len(x)), min(n_of(fout), len(x))
    if a > 1:
        r = np.sin(np.linspace(0, math.pi / 2, a)) ** 2
        x[:a] *= r if x.ndim == 1 else r[:, None]
    if b > 1:
        r = np.cos(np.linspace(0, math.pi / 2, b)) ** 2
        x[-b:] *= r if x.ndim == 1 else r[:, None]
    return x


def peak_normalize(x: np.ndarray, peak_db: float = -1.0) -> np.ndarray:
    p = np.max(np.abs(x))
    return x if p < 1e-9 else x * (undb(peak_db) / p)


def mix_into(dst: np.ndarray, src: np.ndarray, at: int, gain: float = 1.0) -> None:
    """Ajoute src dans dst à l'échantillon at (découpe automatique aux bords)."""
    if at >= len(dst) or at + len(src) <= 0:
        return
    s0 = max(0, -at)
    d0 = max(0, at)
    n = min(len(src) - s0, len(dst) - d0)
    src = stereo(src) if dst.ndim == 2 else mono(src)
    dst[d0:d0 + n] += (src[s0:s0 + n] * gain).astype(dst.dtype)


# ---------------------------------------------------------------- envelopes

def adsr(n: int, a: float, d: float, s: float, r: float, hold: float | None = None) -> np.ndarray:
    """Enveloppe ADSR de n échantillons ; hold = durée avant release (défaut : n - release)."""
    na, nd, nr = n_of(a), n_of(d), n_of(r)
    nh = n - nr if hold is None else n_of(hold)
    env = np.full(n, s, dtype=float)
    i = np.arange(n)
    env[:na] = np.sin(np.linspace(0, math.pi / 2, na))[: min(na, n)] if na else 1
    dd = (i >= na) & (i < na + nd)
    env[dd] = 1 - (1 - s) * ((i[dd] - na) / max(nd, 1)) ** 0.7
    rel_start = max(0, min(nh, n))
    if rel_start < n:
        lvl = env[rel_start - 1] if rel_start > 0 else s
        k = np.arange(n - rel_start) / max(nr, 1)
        env[rel_start:] = lvl * np.exp(-5.0 * k)
    return env


def exp_decay(n: int, tau: float) -> np.ndarray:
    return np.exp(-np.arange(n) / (tau * SR))


def smooth_random(n: int, rate_hz: float, rng: np.random.Generator) -> np.ndarray:
    """Bruit lent et lisse dans [-1, 1] (interpolation cosinus de points aléatoires)."""
    k = max(2, int(n / SR * rate_hz) + 2)
    pts = rng.uniform(-1, 1, k)
    x = np.linspace(0, k - 1, n)
    i = np.floor(x).astype(int).clip(0, k - 2)
    f = (1 - np.cos((x - i) * math.pi)) / 2
    return pts[i] * (1 - f) + pts[i + 1] * f


# ---------------------------------------------------------------- noise

def white(n: int, rng) -> np.ndarray:
    return rng.standard_normal(n)


def colored(n: int, rng, slope: float) -> np.ndarray:
    """Bruit coloré : slope = 0 blanc, 1 rose, 2 brun (puissance en 1/f^slope)."""
    N = 1 << int(math.ceil(math.log2(n + 16)))
    X = np.fft.rfft(rng.standard_normal(N))
    f = np.fft.rfftfreq(N, 1 / SR)
    f[0] = f[1]
    X *= (f / 1000.0) ** (-slope / 2)
    X[0] = 0
    y = np.fft.irfft(X, N)[:n]
    return y / (np.std(y) + 1e-12)


def pink(n, rng):
    return colored(n, rng, 1.0)


def brown(n, rng):
    return colored(n, rng, 2.0)


# ---------------------------------------------------------------- filter shapes (|H(f)|)

def lp(fc, order=2):
    return lambda f: 1 / np.sqrt(1 + (np.asarray(f) / fc) ** (2 * order))


def hp(fc, order=2):
    return lambda f: 1 / np.sqrt(1 + (fc / np.maximum(np.asarray(f), 1e-3)) ** (2 * order))


def bp(lo, hi, order=2):
    a, b = hp(lo, order), lp(hi, order)
    return lambda f: a(f) * b(f)


def bell(fc, gain_db, octaves=1.0):
    def g(f):
        x = np.log2(np.maximum(np.asarray(f), 1e-3) / fc) / (octaves / 2)
        return undb(gain_db * np.exp(-0.5 * x * x * 2.77))
    return g


def shelf(fc, gain_db, high=True, width=1.0):
    def g(f):
        x = np.log2(np.maximum(np.asarray(f), 1e-3) / fc) / width
        s = 0.5 * (1 + np.tanh(1.5 * x))
        return undb(gain_db * (s if high else 1 - s))
    return g


def chain(*shapes):
    def g(f):
        out = np.ones_like(np.asarray(f, dtype=float))
        for s in shapes:
            out = out * s(f)
        return out
    return g


def _minphase(mag: np.ndarray, N: int) -> np.ndarray:
    logm = np.log(np.maximum(mag, 1e-7))
    c = np.fft.irfft(logm, N)
    c[1:N // 2] *= 2
    c[N // 2 + 1:] = 0
    return np.exp(np.fft.rfft(c, N))


_FIR_CACHE: dict = {}


def fir(shape, taps: int = 8192, phase: str = "min", key=None) -> np.ndarray:
    """Réponse impulsionnelle FIR d'une forme |H(f)|."""
    if key is not None and (key, taps, phase) in _FIR_CACHE:
        return _FIR_CACHE[(key, taps, phase)]
    N = taps
    f = np.fft.rfftfreq(N, 1 / SR)
    mag = shape(f)
    if phase == "min":
        h = np.fft.irfft(_minphase(mag, N), N)
        w = np.hanning(2 * N)[N:]
        h = h * w
    else:
        h = np.roll(np.fft.irfft(mag, N), N // 2) * np.hanning(N)
    if key is not None:
        _FIR_CACHE[(key, taps, phase)] = h
    return h


def convolve(x: np.ndarray, h: np.ndarray, block: int = 1 << 16) -> np.ndarray:
    """Convolution par blocs (overlap-add). x mono/stéréo, h mono/stéréo. Sortie de longueur len(x)."""
    st = x.ndim == 2 or h.ndim == 2
    xs = stereo(x) if st else x[:, None]
    hs = stereo(h) if st else h[:, None]
    L = len(hs)
    block = max(block, 1 << int(math.ceil(math.log2(L))))
    N = 1 << int(math.ceil(math.log2(block + L)))
    H = np.fft.rfft(hs, N, axis=0)
    out = np.zeros((len(xs) + L, xs.shape[1]), dtype=np.float64)
    for s in range(0, len(xs), block):
        seg = xs[s:s + block]
        Y = np.fft.irfft(np.fft.rfft(seg, N, axis=0) * H, N, axis=0)
        e = min(len(out), s + len(seg) + L - 1)
        out[s:e] += Y[: e - s]
    out = out[: len(xs)]
    return out if st else out[:, 0]


def filt_chunked(x: np.ndarray, shape, phase: str = "zero", chunk_s: float = 30.0, dtype=np.float32) -> np.ndarray:
    """Comme filt, mais par morceaux avec marges : mémoire bornée sur des signaux de 20 min."""
    n = len(x)
    out = np.empty(x.shape, dtype=dtype)
    c = n_of(chunk_s)
    m = 1 << 15
    for s0 in range(0, n, c):
        a, b = max(0, s0 - m), min(n, s0 + c + m)
        y = filt(x[a:b].astype(np.float64), shape, phase)
        out[s0:min(n, s0 + c)] = y[s0 - a:s0 - a + min(c, n - s0)]
    return out


def filt(x: np.ndarray, shape, phase: str = "min") -> np.ndarray:
    """Applique une forme |H(f)| à x. Signal court : FFT d'un seul bloc ; long : FIR par blocs."""
    n = len(x)
    if n <= 1 << 20:
        N = 1 << int(math.ceil(math.log2(n + 4096)))
        f = np.fft.rfftfreq(N, 1 / SR)
        mag = shape(f)
        H = _minphase(mag, N) if phase == "min" else mag
        X = np.fft.rfft(x, N, axis=0)
        Y = X * (H[:, None] if x.ndim == 2 else H)
        return np.fft.irfft(Y, N, axis=0)[:n]
    if phase == "min":
        return convolve(x, fir(shape, 16384, "min"))
    h = fir(shape, 16384, "zero")
    y = convolve(np.concatenate([x, np.zeros((8192,) + x.shape[1:])]), h)
    return y[8192:8192 + n]


# ---------------------------------------------------------------- time-varying filter (STFT)

def stft_shape(x: np.ndarray, gain_tf, win: int = 2048, hop: int = 512) -> np.ndarray:
    """Filtre variable dans le temps. gain_tf(t[frames], f[bins]) -> (frames, bins)."""
    x1 = mono(x)
    n = len(x1)
    pad = win
    xp = np.concatenate([np.zeros(pad), x1, np.zeros(pad + win)])
    w = np.hanning(win + 1)[:-1]
    frames = 1 + (len(xp) - win) // hop
    idx = np.arange(win)[None, :] + hop * np.arange(frames)[:, None]
    S = np.fft.rfft(xp[idx] * w, axis=1)
    t = (np.arange(frames) * hop + win / 2 - pad) / SR
    f = np.fft.rfftfreq(win, 1 / SR)
    S *= gain_tf(t[:, None], f[None, :])
    y = np.fft.irfft(S, win, axis=1) * w
    out = np.zeros(len(xp))
    norm = np.zeros(len(xp))
    for i in range(frames):
        out[i * hop:i * hop + win] += y[i]
        norm[i * hop:i * hop + win] += w * w
    out /= np.maximum(norm, 1e-6)
    return out[pad:pad + n]


def band_gain(center, q):
    """Gain passe-bande gaussien en octaves ; center et q peuvent dépendre du temps (colonnes)."""
    def g(t, f):
        c = center(t) if callable(center) else center
        qq = q(t) if callable(q) else q
        x = np.log2(np.maximum(f, 1.0) / np.maximum(c, 20.0))
        return np.exp(-0.5 * (x * qq) ** 2)
    return g


# ---------------------------------------------------------------- non-linear

def saturate(x: np.ndarray, drive_db: float = 6.0, mix: float = 1.0) -> np.ndarray:
    """Saturation tanh, compensée en niveau. Assez douce pour ne pas exiger de suréchantillonnage."""
    g = undb(drive_db)
    y = np.tanh(x * g) / np.tanh(g)
    return x * (1 - mix) + y * mix


def bitcrush(x: np.ndarray, bits: int = 6, down: int = 4) -> np.ndarray:
    q = 2 ** (bits - 1)
    y = np.round(x * q) / q
    if down > 1:
        y = np.repeat(y[::down], down, axis=0)[: len(x)]
    return y


# ---------------------------------------------------------------- spatial

def widen(x: np.ndarray, amount: float = 0.6, rng=None) -> np.ndarray:
    """Élargit un mono par décorrélation de phase (reste compatible mono : la somme L+R garde le signal)."""
    rng = rng or np.random.default_rng(7)
    m = mono(x)
    n = len(m)
    N = 1 << int(math.ceil(math.log2(n + 4096)))
    X = np.fft.rfft(m, N)
    ph = np.exp(1j * rng.uniform(-math.pi, math.pi, len(X)) * amount * 0.5)
    f = np.fft.rfftfreq(N, 1 / SR)
    ph[f < 180] = 1  # le grave reste mono
    side = np.fft.irfft(X * ph, N)[:n] - m
    return np.stack([m + side, m - side], axis=1)


def delay_ir(seconds: float, feedback: float, repeats: int, pingpong=True, tone_hz=4500.0) -> np.ndarray:
    """IR d'un écho calé au tempo (ping-pong), filtré à chaque répétition."""
    d = n_of(seconds)
    h = np.zeros((d * repeats + 1, 2))
    for k in range(1, repeats + 1):
        ch = (k % 2) if pingpong else None
        g = feedback ** k
        if ch is None:
            h[d * k, :] = g
        else:
            h[d * k, ch] = g
    return filt(h, lp(tone_hz * 1.0, 1))


# ---------------------------------------------------------------- reverb

_IR_CACHE: dict = {}


def reverb_ir(space: str = "hall", seed: int = 1) -> np.ndarray:
    """IR stéréo synthétique : réflexions précoces + queue diffuse à décroissance dépendante de la fréquence."""
    key = (space, seed)
    if key in _IR_CACHE:
        return _IR_CACHE[key]
    P = {
        "room":   dict(rt=0.55, pre=0.008, er=10, hf=0.45, bright=7000, build=0.010),
        "garage": dict(rt=1.30, pre=0.012, er=14, hf=0.55, bright=6000, build=0.015),
        "plate":  dict(rt=1.80, pre=0.004, er=0,  hf=0.75, bright=11000, build=0.004),
        "hall":   dict(rt=2.60, pre=0.022, er=16, hf=0.50, bright=8000, build=0.030),
        "cathedral": dict(rt=4.20, pre=0.035, er=18, hf=0.45, bright=6500, build=0.045),
        "gated":  dict(rt=0.90, pre=0.002, er=6,  hf=0.70, bright=9000, build=0.003),
    }[space]
    rng = np.random.default_rng(seed * 7919 + len(space))
    L = n_of(P["rt"] * 1.25 + P["pre"] + 0.05)
    out = np.zeros((L, 2))
    for ch in range(2):
        nz = rng.standard_normal(L)
        rt = P["rt"]

        def g(t, f, rt=rt):
            rtf = rt * (P["hf"] + (1 - P["hf"]) / (1 + (f / 2500.0) ** 1.2))
            rtf = rtf * (1 + 0.25 / (1 + (f / 150.0) ** 2))  # grave un peu plus long
            tt = np.maximum(t, 0)
            return np.exp(-6.91 * tt / rtf) * (1 - np.exp(-tt / P["build"])) / (1 + (f / P["bright"]) ** 2)
        tail = stft_shape(nz, g, 1024, 256)
        out[:, ch] = tail
    pre = n_of(P["pre"])
    out = np.concatenate([np.zeros((pre, 2)), out])[:L]
    for k in range(P["er"]):
        tsec = P["pre"] * 0.4 + rng.uniform(0.002, P["pre"] + 0.045)
        i = n_of(tsec)
        if i < L:
            out[i, rng.integers(0, 2)] += rng.uniform(0.25, 0.7) * math.exp(-tsec * 22) * 6 * (1 if rng.random() < .5 else -1)
    out = filt(out, hp(90, 1))
    out /= np.sqrt(np.sum(out ** 2) / 2) + 1e-12
    if space == "gated":
        cut = n_of(0.22)
        out[cut:] *= np.exp(-np.arange(L - cut) / (0.012 * SR))[:, None]
    _IR_CACHE[key] = out
    return out


def reverb(x: np.ndarray, space: str = "hall", wet: float = 0.2, seed: int = 1, tail: bool = True) -> np.ndarray:
    ir = reverb_ir(space, seed)
    src = stereo(x)
    if tail:
        src = np.concatenate([src, np.zeros((len(ir), 2))])
    w = convolve(src, ir) * 0.35
    dry = src
    return dry * (1 - wet * 0.5) + w * wet


def trim_tail(x: np.ndarray, floor_db: float = -70.0) -> np.ndarray:
    a = np.max(np.abs(stereo(x)), axis=1)
    thr = undb(floor_db) * (a.max() + 1e-12)
    idx = np.nonzero(a > thr)[0]
    end = (idx[-1] + n_of(0.02)) if len(idx) else len(x)
    return fade(x[: min(len(x), end)], 0.0005, 0.03)


# ---------------------------------------------------------------- dynamics

def _follow(level: np.ndarray, att_blocks: float, rel_blocks: float) -> np.ndarray:
    a = math.exp(-1 / max(att_blocks, 1e-3))
    r = math.exp(-1 / max(rel_blocks, 1e-3))
    out = np.empty_like(level)
    s = level[0]
    for i, v in enumerate(level):
        c = a if v > s else r
        s = c * s + (1 - c) * v
        out[i] = s
    return out


def _blocks_to_samples(g_blocks: np.ndarray, block: int, n: int) -> np.ndarray:
    xs = (np.arange(len(g_blocks)) + 0.5) * block
    return np.interp(np.arange(n), xs, g_blocks)


def compressor(x, thr_db=-18.0, ratio=3.0, attack=0.010, release=0.150, knee_db=6.0,
               makeup_db=0.0, sidechain=None, block=48):
    """Compresseur feed-forward (détection RMS par blocs de 1 ms, gain lissé attaque/relâche)."""
    sc = mono(stereo(sidechain if sidechain is not None else x))
    n = len(sc)
    nb = int(math.ceil(n / block))
    p = np.pad(sc ** 2, (0, nb * block - n)).reshape(nb, block).mean(axis=1)
    lvl = 10 * np.log10(p + 1e-12)
    over = lvl - thr_db
    k = knee_db / 2
    gr = np.where(over <= -k, 0.0,
                  np.where(over >= k, over * (1 - 1 / ratio),
                           (1 - 1 / ratio) * (over + k) ** 2 / (4 * k + 1e-9)))
    blocks_per_s = SR / block
    gr = _follow(gr, attack * blocks_per_s, release * blocks_per_s)
    g = undb(-gr + makeup_db)
    gs = _blocks_to_samples(g, block, len(x))
    return x * (gs[:, None] if x.ndim == 2 else gs)


def tp_blocks(x: np.ndarray, block: int = 48, margin: int = 256, thr: float | None = None) -> np.ndarray:
    """Pic vrai (suréchantillonnage x4) par blocs de `block` échantillons.
    Seuls les blocs dont le pic échantillon dépasse -6 dB sous le maximum global sont suréchantillonnés
    (fenêtres courtes vectorisées) : rapide et économe en mémoire sur 20 min de son."""
    xs = stereo(x)
    n = len(xs)
    nb = int(math.ceil(n / block))
    a = np.abs(xs).max(axis=1)
    a = np.pad(a, (0, nb * block - n))
    sp = a.reshape(nb, block).max(axis=1)
    out = sp.copy()
    thr = sp.max() * 0.5 if thr is None else thr
    cand = np.nonzero(sp > thr)[0]
    if len(cand) == 0:
        return out
    xp = np.pad(xs, ((margin, nb * block - n + margin), (0, 0)))
    W = block + 2 * margin
    taper = np.ones(W)
    r = np.hanning(2 * margin)
    taper[:margin], taper[-margin:] = r[:margin], r[margin:]
    step = max(1, 2_000_000 // W)
    for s in range(0, len(cand), step):
        c = cand[s:s + step]
        idx = c[:, None] * block + np.arange(W)[None, :]
        for ch in range(2):
            seg = xp[idx, ch] * taper
            X = np.fft.rfft(seg, axis=1)
            Y = np.zeros((len(c), 2 * W + 1), dtype=complex)
            Y[:, : X.shape[1]] = X
            up = np.fft.irfft(Y, 4 * W, axis=1) * 4
            mid = np.abs(up[:, 4 * margin:4 * (margin + block)]).max(axis=1)
            out[c] = np.maximum(out[c], mid)
    return out


def true_peak_db(x: np.ndarray) -> float:
    return float(db(np.max(tp_blocks(x, 4800))))


def limiter(x: np.ndarray, ceiling_db: float = -1.0, lookahead: float = 0.005, release: float = 0.08) -> np.ndarray:
    """Limiteur à anticipation sur le pic vrai (x4)."""
    xs = stereo(x)
    ceil = undb(ceiling_db)
    block = 48
    n = len(xs)
    pk = tp_blocks(xs, block, thr=ceil * 0.5)
    nb = len(pk)
    need = np.minimum(1.0, ceil * 0.97 / np.maximum(pk, 1e-12))  # 0.26 dB de marge pour l'interpolation
    la = max(1, int(round(lookahead * SR / block)))
    # fenêtre [i-1, i+la] : le gain interpolé entre deux blocs ne dépasse jamais le besoin du bloc précédent
    padded = np.concatenate([[1.0], need, np.ones(la)])
    win = np.lib.stride_tricks.sliding_window_view(padded, la + 2)[:nb]
    need = win.min(axis=1)
    r = math.exp(-1 / (release * SR / block))
    g = np.empty(nb)
    s = 1.0
    for i, v in enumerate(need):
        s = v if v < s else r * s + (1 - r) * v
        g[i] = s
    gs = interp_curve(n, np.arange(nb) * block, g)
    y = np.array(xs, dtype=np.float32, copy=True)
    y *= gs[:, None]
    np.clip(y, -ceil, ceil, out=y)
    return y


# ---------------------------------------------------------------- loudness (ITU-R BS.1770-4)

def _k_weight_mag(f):
    w = 2 * np.pi * np.asarray(f) / SR
    z = np.exp(-1j * w)

    def h(b, a):
        return (b[0] + b[1] * z + b[2] * z * z) / (a[0] + a[1] * z + a[2] * z * z)
    h1 = h([1.53512485958697, -2.69169618940638, 1.19839281085285], [1, -1.69065929318241, 0.73248077421585])
    h2 = h([1.0, -2.0, 1.0], [1, -1.99004745483398, 0.99007225036621])
    return np.abs(h1 * h2)


def loudness(x: np.ndarray) -> dict:
    """LUFS intégré (avec portes), court terme max, pic vrai, LRA approchée."""
    xs = stereo(x)
    if len(xs) < n_of(0.5):
        xs = pad_to(xs, n_of(0.5))
    k = filt_chunked(xs, _k_weight_mag, phase="zero")
    blk, hop = n_of(0.4), n_of(0.1)
    p = np.sum(k.astype(np.float64) ** 2, axis=1)
    del k
    cs = np.concatenate([[0], np.cumsum(p)])
    starts = np.arange(0, len(p) - blk + 1, hop)
    ms = (cs[starts + blk] - cs[starts]) / blk
    lk = -0.691 + 10 * np.log10(ms + 1e-15)
    gated = ms[lk > -70]
    if len(gated) == 0:
        integ = -120.0
    else:
        rel = -0.691 + 10 * np.log10(gated.mean()) - 10
        g2 = ms[(lk > -70) & (lk > rel)]
        integ = -0.691 + 10 * np.log10(g2.mean()) if len(g2) else -120.0
    sblk = n_of(3.0)
    if len(p) >= sblk:
        s_st = np.arange(0, len(p) - sblk + 1, n_of(0.1))
        st = -0.691 + 10 * np.log10((cs[s_st + sblk] - cs[s_st]) / sblk + 1e-15)
        stg = st[st > -70]
        if len(stg):
            stg = stg[stg > integ - 20]
        lra = float(np.percentile(stg, 95) - np.percentile(stg, 10)) if len(stg) > 2 else 0.0
        stmax = float(st.max())
    else:
        lra, stmax = 0.0, float(integ)
    return {"lufs": round(float(integ), 2), "short_term_max": round(stmax, 2), "lra": round(lra, 2),
            "true_peak_dbtp": round(true_peak_db(xs), 2)}


def match_lufs(x: np.ndarray, target: float) -> np.ndarray:
    cur = loudness(x)["lufs"]
    return x if cur < -100 else x * undb(target - cur)


# ---------------------------------------------------------------- files

def write_wav(path: str, x: np.ndarray, bits: int = 24) -> None:
    xs = stereo(x)
    with wave.open(path, "wb") as w:
        w.setnchannels(2)
        w.setframerate(SR)
        w.setsampwidth(2 if bits == 16 else 3)
        for s in range(0, len(xs), 1 << 20):
            c = np.clip(xs[s:s + (1 << 20)].astype(np.float64), -1.0, 1.0 - 1e-7)
            if bits == 16:
                w.writeframes((c * 32767).round().astype("<i2").tobytes())
            else:
                iv = (c * 8388607).round().astype("<i4")
                w.writeframes(iv.view(np.uint8).reshape(-1, 4)[:, :3].tobytes())


def read_wav(path: str) -> np.ndarray:
    with wave.open(path, "rb") as w:
        ch, sw, sr, n = w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()
        raw = w.readframes(n)
    if sw == 2:
        a = np.frombuffer(raw, "<i2").astype(np.float64) / 32768
    elif sw == 3:
        b = np.frombuffer(raw, np.uint8).reshape(-1, 3)
        iv = (b[:, 0].astype(np.int32) | (b[:, 1].astype(np.int32) << 8) | (b[:, 2].astype(np.int32) << 16))
        iv = np.where(iv & 0x800000, iv - 0x1000000, iv)
        a = iv / 8388608.0
    else:
        a = np.frombuffer(raw, "<i4").astype(np.float64) / 2147483648.0
    a = a.reshape(-1, ch)
    if sr != SR:
        raise ValueError(f"{path}: {sr} Hz, attendu {SR} Hz (convertir avec ffmpeg -ar 48000)")
    return a if ch == 2 else np.repeat(a, 2, axis=1)


def encode(wav_path: str, fmt: str = "flac") -> str:
    """Encode un WAV en FLAC 24 bits (ou m4a AAC 320k / mp3 320k) avec ffmpeg. Renvoie le chemin produit."""
    if not shutil.which("ffmpeg"):
        return wav_path
    out = wav_path.rsplit(".", 1)[0] + "." + fmt
    args = {"flac": ["-c:a", "flac", "-sample_fmt", "s32", "-compression_level", "8"],
            "m4a": ["-c:a", "aac", "-b:a", "320k"],
            "mp3": ["-c:a", "libmp3lame", "-b:a", "320k"]}[fmt]
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav_path, *args, out], check=True)
    return out


def moving_average(x: np.ndarray, k: int) -> np.ndarray:
    """Moyenne glissante centrée de longueur k (sommes cumulées, sans tableaux d'index : O(n), peu de mémoire)."""
    k = max(1, int(k))
    xp = np.concatenate([np.zeros(k // 2 + 1, np.float64), np.asarray(x, np.float64), np.zeros(k - k // 2, np.float64)])
    c = np.cumsum(xp)
    del xp
    n = len(x)
    return ((c[k:k + n] - c[:n]) / k).astype(np.float32)


def interp_curve(n: int, xs: np.ndarray, ys: np.ndarray, chunk: int = 1 << 20) -> np.ndarray:
    """np.interp(arange(n), xs, ys) par morceaux, en float32."""
    out = np.empty(n, np.float32)
    for s in range(0, n, chunk):
        e = min(n, s + chunk)
        out[s:e] = np.interp(np.arange(s, e), xs, ys)
    return out
