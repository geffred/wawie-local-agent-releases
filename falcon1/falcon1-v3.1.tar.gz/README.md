# Falcon 1 — boîte à outils locale (v3.1) : niche automobile + fichier maître documentaire

Ce paquet s'installe **une fois** sur la machine Cowork. Il évite de renvoyer environ 70 000 caractères d'instructions et de faire réécrire le code du son à Falcon 1 à chaque montage.

| Fichier | Rôle |
|---|---|
| `NICHE_AUTOMOBILE_v3_noyau.md` | Texte à coller dans les **instructions de niche** de Wawie (environ 10 000 caractères, une seule partie). |
| `annexes/*.md` | Détails lus à la demande (`python3 -m falcon1 annexe son`…). Automobile : script, sources, elements, motion3d, son, reference. Documentaire : doc_archetypes, doc_script, doc_sources, doc_motion3d (univers 3D par sujet), doc_elements, doc_son, doc_controle. |
| `falcon1/variation.py` + `options*.json` | Tirage (automobile : 17 dimensions ; documentaire : archétype + 25 dimensions, compatibles avec l'univers du sujet), anti-répétition, registre local, test anti-gabarit (`empreinte`). |
| `falcon1/sfx.py`, `sfx_doc.py` | 66 effets synthétisés (air, cinéma, interface, argent, atelier, automobile, papier/bureau, organique, horlogerie, enquête, jeu vidéo, combat, célébrités). |
| `falcon1/ambiences.py` | 17 ambiances bouclables (atelier… ville, foule, forêt, mer, désert, pluie, orage, bureau, nuit, salle vide). |
| `falcon1/music.py` | Compositeur : 8 directions automobile + 8 directions documentaires (dont gammes culturelles), 7 humeurs, intensité 1-5 par acte. |
| `falcon1/mix.py` | Calage sur get_timing, ducking mot à mot, stems pour Wawie, contrôle qualité. |
| `falcon1/dsp.py` | Filtres, réverbérations synthétiques, compresseur, limiteur au pic vrai, LUFS (BS.1770-4). |

Dépendances : Python ≥ 3.10, numpy et ffmpeg (pour FLAC, m4a et mp3). Aucune banque de sons, aucun appel réseau.

## Installation sur Cowork
```bash
mkdir -p ~/falcon1 && curl -fsSL https://raw.githubusercontent.com/geffred/wawie-local-agent-releases/main/falcon1/falcon1-v3.1.tar.gz | tar xz -C ~/falcon1 && python3 -m pip install -q numpy
PYTHONPATH=~/falcon1 python3 -m falcon1 version --min 3.1.0   # code 0 = à jour
```
L'archive est publiée dans le dépôt public `geffred/wawie-local-agent-releases` (`falcon1/`, avec sa somme SHA-256). Pour une nouvelle version : `./empaqueter.sh`, publier l'archive sous un nouveau nom (falcon1-v3.2.tar.gz…), mettre VERSION à jour dans `falcon1/__main__.py`, puis changer l'URL et le `--min` dans les deux noyaux.

## Commandes
```bash
python3 -m falcon1 tirage --run-id R --titre "T"      # automobile : choix de la vidéo (JSON), écrit le registre
python3 -m falcon1 tirage --niche doc --univers histoire --run-id R --titre "T"   # documentaire
python3 -m falcon1 empreinte --run-id R --fichier empreinte.json             # test anti-gabarit (code 2 = trop proche)
python3 -m falcon1 son --cues cues.json --out son/    # stems + héros + manifeste.json
python3 -m falcon1 sons                               # liste des sons, ambiances, humeurs
python3 -m falcon1 annexe son                         # affiche une annexe
python3 -m falcon1 demo --out demo/                   # pack d'écoute + 60 s de démonstration
```
Le format de `cues.json` est décrit dans `annexes/son.md`.

## Performances mesurées (machine de test 4 cœurs)
- Un effet : moins de 0.8 s.
- Une ambiance de 40 s : environ 4 s.
- Musique : environ 0.2 × le temps réel.
- Vidéo de 18 min complète (musique en 4 actes, 186 effets dont 26 héros, 3 ambiances) : environ 4 min, 3.2 Go de mémoire au maximum.

## Limites connues (honnêtes)
- Tout est de la synthèse. Les effets « cinéma » (impacts, risers, whooshs, braams) et les musiques électroniques (D1, D4, D7, D8) sont le terrain naturel de la synthèse. Les directions à instruments acoustiques (D2 cordes, D3 piano électrique, D5 guitare) sonnent synthétiques : D2 est donc définie comme « trailer hybride synthétique ».
- Le niveau de la voix Wawie n'est pas mesurable avant le rendu. Par défaut, le moteur suppose -16 LUFS ; si la voix est accessible, mesure-la et mets `voix_lufs`.

## Texte de lancement Cowork (documentaire)
> Tu es Falcon 1. Applique les instructions de la niche (noyau documentaire v3.1) et le skill wawie-monteur. Sujet : [SUJET]. Angle souhaité (facultatif) : [ANGLE]. Durée cible : [DURÉE] minutes. Langue : [LANGUE]. Résolution : 1080p. Fais la recherche, tire l'archétype et la bible (tirage --niche doc --univers adapté), écris le script, monte un documentaire ultra dynamique et cohérent, surtout en motion 3D dans l'univers du sujet, calé au mot près, avec un son entièrement créé par la boîte à outils. Passe l'empreinte anti-gabarit, rends une seule fois, contrôle le rendu et livre avec un bilan honnête en français.
