FALCON 1 — NICHE AUTOMOBILE v3.0 (noyau). Vidéos YouTube faceless au format liste (« X habitudes / erreurs / astuces »), niveau premium. Ces règles sont obligatoires. Les détails sont dans les annexes locales, à lire seulement à l'étape indiquée. Chaque valeur chiffrée est une valeur par défaut : si tu t'en écartes, dis-le dans le bilan.

PRIORITÉ EN CAS DE CONFLIT : 1. la demande de la personne > 2. les contraintes des outils Wawie > 3. ce noyau > 4. la charte Wawie.

== 0. BOÎTE À OUTILS LOCALE (une fois par machine, 10 s) ==
R0.1 Vérifier : `PYTHONPATH=~/falcon1 python3 -m falcon1 version --min 3.1.1` (code de sortie 0). Sinon : `mkdir -p ~/falcon1 && curl -fsSL https://raw.githubusercontent.com/geffred/wawie-local-agent-releases/main/falcon1/falcon1-v3.1.1.tar.gz | tar xz -C ~/falcon1 && python3 -m pip install -q numpy`. ffmpeg doit être présent.
R0.2 Ne jamais réécrire ce que fait la boîte à outils : tirage des variations, synthèse des sons, musique, mixage, contrôle du son. Tu l'appelles.
R0.3 Annexes : `PYTHONPATH=~/falcon1 python3 -m falcon1 annexe <nom>`. Noms : script, sources, elements, motion3d, son, reference. Lis une annexe au moment où tu fais l'étape correspondante, pas avant.

== 1. DÉROULÉ ==
R1.1 Script : s'il est fourni, l'utiliser tel quel. Sinon l'écrire avant wawie_start (lire l'annexe script) : 2 400 à 3 400 mots, en anglais sauf demande contraire.
R1.2 wawie_niches → wawie_start(script, titre, niche automobile, 16:9) → wawie_open → wawie_niche_plan → wawie_status jusqu'à readyForClaude.
R1.3 Tirage : `python3 -m falcon1 tirage --run-id <run_id> --titre "<titre>"`. Il renvoie la graine et les 17 choix de la vidéo (palette, typographie, cartes titre, style des mots clés, étiquettes, prix, numérotation, transitions, 3 ou 4 styles de motion 3D, caméra, direction musicale, pack de sons, étalonnage, accroche, bouton abonnement, écran de fin, mise en évidence). Ces choix remplacent toute couleur, police ou variante citée ailleurs. Ils restent identiques du début à la fin de la vidéo. Recopie-les dans save_edit_plan (style bible) et dans le bilan.
R1.4 get_project → get_timing : grille mot à mot. Tous les temps (coupes, textes, motions, sons) viennent de get_timing, jamais d'une estimation.
R1.5 save_edit_plan → set_scene_plan (une scène par item) → shot list : un beat par mot déclencheur (pièce, chiffre, prix, geste, lieu, émotion).
R1.6 Rushs : lire l'annexe sources. Au moins 2 candidats par beat, chacun regardé avec inspect_*, puis note_media et download_media. Chaque chiffre affiché passe par research_save.
R1.7 Motions : lire l'annexe motion3d. Envoyer tous les draw_motion ensemble et tôt.
R1.8 set_storyboard → relire get_timing et get_timeline → recalculer at[] et les débuts de textes sur les débuts RÉELS des plans → régénérer tout motion décalé de plus d'une image → check_sync jusqu'à 0 point.
R1.9 Son, sur le storyboard figé : lire l'annexe son. Écrire cues.json → `python3 -m falcon1 son --cues cues.json --out son/` → déposer les fichiers avec wawie_upload_link → coller les extraits de son/manifeste.json dans le storyboard → check_sync.
R1.10 Revue plan par plan, puis quality_check : 90 visé, 80 minimum. render_final une seule fois → inspect_preview(purpose "final") → wawie_deliver avec le bilan en français.
R1.11 Ne pas demander de validation intermédiaire. Poser une question seulement si le sujet ou le script manque ou est ambigu.

== 2. CALAGE ET DURÉES (prioritaire sur toute autre durée) ==
R2.1 Un texte apparaît au début exact de son mot : 0 à +0.1 s, jamais avant. Entrée en 0.30 à 0.40 s (power3.out ou back.out(1.4)). Il reste jusqu'à la fin de la proposition + 0.5 à 0.8 s, puis sort en fondu de 0.25 à 0.35 s, dans un silence.
R2.2 Durées minimales : mot clé 2.5 s ; prix ou chiffre 3 s ; étiquette 3 s ; carte titre 3.5 s ; surlignage 3 s. Maximum 6 s. Il faut aussi au moins 0.4 s par mot affiché + 1.0 s.
R2.3 Au moins 1.0 s sans texte entre deux textes au même endroit. Jamais deux textes qui se chevauchent. Jamais la phrase entière recopiée.
R2.4 Un motion explique pas à pas, comme un professeur au tableau. Il commence 0.07 à 0.20 s avant son premier mot, dans le silence. Il finit dans le silence qui suit l'explication + 0.6 à 1.0 s. Durée minimale 4 s, typique 5 à 9 s ; une explication de mécanisme dure 8 à 15 s (au-delà, 2 motions séparés par de la vidéo réelle).
R2.5 seconds de draw_motion = durée exacte du plan, à l'image près. Chaque révélation : at = début du mot − début du plan. Animation de 0.35 à 0.60 s (tracés de 0.6 à 1.2 s). Les éléments s'ajoutent et restent affichés. La caméra bouge en continu (scale 1 → 1.06, ease none). Aucune révélation avant son mot, ni plus de 0.1 s après.
R2.6 Coupes au milieu du silence entre deux mots. Le plan d'un mot commence 0.07 à 0.2 s avant ce mot. Temps arrondis à 1/30 s.
R2.7 Si Wawie répond « sync: N cut(s) moved » ou si un plan change : tous les at[], les débuts de textes et cues.json sont à refaire.
R2.8 Avant render_final, vérifier : chaque texte (écart avec son mot, durée) ; chaque motion avec inspect_video_range à at et à at + 0.5 s ; check_sync = 0. Noter dans le bilan les nombres vérifiés et l'écart maximal mesuré.

== 3. RYTHME ET IMAGE ==
R3.1 Durée 14 à 22 min ; 10 à 17 items (13 idéal) ; item 1 avant 40 s. Le format est 16:9, 1080p, 30 i/s.
R3.2 Durée des plans : accroche 1.5 à 2.5 s ; 30 à 90 s : 2.5 à 3.2 s ; corps 3.0 à 4.2 s. Pas de plan sous 1.5 s dans le corps, sauf rafale voulue. Plan vidéo de 7 s maximum (10 s pour une démonstration continue justifiée). Un nouveau visuel à chaque objet, chiffre, pièce ou idée nouvelle, et au plus tard toutes les 4 s.
R3.3 Part du temps : vidéo réelle ≥ 60 % (cible 65 %) ; motions et cartes 15 à 20 %, soit 2 à 3 motions par minute dont au moins 1 schéma explicatif par item ; images fixes toujours en mouvement (Ken Burns), jamais un plan figé.
R3.4 Motion obligatoire pour : chaque mécanisme, chaque chiffre clé, chaque comparaison A/B, chaque liste d'étapes, chaque recommandation du constructeur.
R3.5 Jamais deux motions ou cartes de suite sans vidéo réelle entre elles ; jamais trois cartes d'affilée ; jamais deux images fixes consécutives (sauf séquence de schémas, 3 au maximum).
R3.6 ≥ 70 % des motions en 3D ou en profondeur réelle, dans les 3 ou 4 styles tirés. Jamais deux motions consécutifs du même style. Aucun style au-dessus de 40 % des motions. Aucun modèle hf.* plus de 3 fois. Au moins un hf.custom par item.
R3.7 L'image montre exactement ce que dit la voix : la bonne pièce, le bon type de boîte, le bon carburant. Un plan hors sujet se remplace, même long. Pas de plan « d'ambiance » sans rapport avec les mots.
R3.8 Un rush 2 fois au maximum, jamais à moins de 60 s d'intervalle. Pas de logo, bandeau ou texte parasite. Jamais 3 plans de même valeur de suite (large → moyen → serré → POV).
R3.9 Transitions : 65 % de coupes franches, 25 % stylisées (prises dans le jeu tiré), 10 % de section. Au moins 2 coupes franches entre deux transitions stylisées. Entrée et sortie de chaque motion en douceur (0.30 à 0.50 s). Pas de transition gadget.
R3.10 Mots clés : 3 à 5 par minute. Prix géant sur chaque montant prononcé. Bouton abonnement entre 35 et 45 % de la durée. Écran de fin de 20 s qui laisse libre la zone des éléments YouTube (≈ 45 % de la largeur, centre-droite).
R3.11 Les détails de construction (cartes, étiquettes, prix, flèches, split, documents, rushs 9:16, Ken Burns, punch-in) sont dans l'annexe elements.

== 4. SON (100 % créé par le code) ==
R4.1 Interdit : generate_sound, generate_music, search_sounds, search_music, generate_voice. Toute la musique, toutes les ambiances et tous les effets sortent de `python3 -m falcon1 son`. Les sons varient avec la graine : jamais deux fois le même son.
R4.2 Une seule passe son, sur le storyboard figé. Si le montage bouge ensuite, refaire cues.json et la passe son, puis redéposer les fichiers.
R4.3 Une musique par acte (humeurs : tension, sombre, positif, resolution), dans la direction tirée. Changement d'acte de préférence sur une carte titre. La musique remonte dans les respirations et sur les 8 dernières secondes.
R4.4 Effets : 6 à 15 moments sonores par minute ; 60 % dans le pack tiré. Le pic de l'effet tombe sur le mot ou la coupe : c'est le champ at de cues.json, que l'outil aligne tout seul. Jamais un effet sur chaque coupe (10 à 15 % des coupes). Pas plus de 4 effets par plan. Jamais un effet qui masque un mot important.
R4.5 Effets « héros », 40 au maximum, posés en sfx dans les plans : impacts de cartes titre, cha-ching, buzzer, sub drops. Tout le reste va dans le stem effets.
R4.6 La voix reste toujours devant. Wawie masterise à -14 LUFS et sous -1 dBTP. Le rapport de l'outil doit indiquer « problemes: [] », sinon corriger cues.json et relancer.

== 5. EXACTITUDE ET LIVRAISON ==
R5.1 Chaque chiffre affiché vient d'une source lue et enregistrée (research_save). Formuler en fourchettes prudentes. Zéro faute dans les textes à l'écran. Cartes titre identiques mot pour mot à l'annonce, numéros dans l'ordre.
R5.2 Interdits : un plan qui ne correspond pas aux mots ; un plan noir, figé ou un silence non voulu ; plusieurs rendus ; reprendre la palette, la typographie, les cartes ou la direction musicale de la vidéo précédente (le tirage s'en charge).
R5.3 Terminé = check_sync à 0 ; quality_check ≥ 80 ; calage vérifié (R2.8) ; rapport son sans problème ; rendu final vérifié (voix et image au mot près, orthographe, ni noir ni silence) ; wawie_deliver envoyé.
R5.4 Bilan honnête : part de vidéo réelle, nombre de plans et durée moyenne, sources, motions (nombre, part 3D, styles), choix tirés et graine, son (direction musicale, nombre d'effets et héros, LUFS des stems), corrections faites, défauts restants.
R5.5 wawie_niche_plan : réponds par numéro de règle (« R2.5 : appliqué — at[] recalculés après le storyboard final »), sans recopier les règles.
