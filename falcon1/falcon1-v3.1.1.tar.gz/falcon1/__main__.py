"""Falcon 1 — outils locaux (niche automobile et fichier maître documentaire).

  python3 -m falcon1 version [--min 3.1.0]          (code de sortie 1 si la version installée est plus ancienne)
  python3 -m falcon1 tirage --run-id R --titre "T" [--niche auto|doc] [--univers histoire] [--duree 18]
  python3 -m falcon1 empreinte --run-id R --fichier empreinte.json [--niche doc]
  python3 -m falcon1 son --cues cues.json --out sortie/ [--format flac|m4a|mp3|wav]
  python3 -m falcon1 sons                       (liste des sons disponibles)
  python3 -m falcon1 annexe <nom>               (affiche une annexe ; sans nom valide : liste des annexes)
  python3 -m falcon1 demo --out demo/           (pack de sons + 60 s de mixage de démonstration)
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

VERSION = "3.1.1"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main(argv=None):
    ap = argparse.ArgumentParser(prog="falcon1")
    sub = ap.add_subparsers(dest="cmd", required=True)
    v = sub.add_parser("version")
    v.add_argument("--min")
    t = sub.add_parser("tirage")
    t.add_argument("--run-id", required=True)
    t.add_argument("--titre", required=True)
    t.add_argument("--niche", default="auto", choices=["auto", "doc"])
    t.add_argument("--univers")
    t.add_argument("--duree", type=float, help="durée demandée par la personne (minutes)")
    t.add_argument("--registre")
    t.add_argument("--sans-ecrire", action="store_true")
    e = sub.add_parser("empreinte")
    e.add_argument("--run-id", required=True)
    e.add_argument("--fichier", required=True)
    e.add_argument("--niche", default="doc", choices=["auto", "doc"])
    e.add_argument("--registre")
    s = sub.add_parser("son")
    s.add_argument("--cues", required=True)
    s.add_argument("--out", required=True)
    s.add_argument("--format", default="flac", choices=["flac", "m4a", "mp3", "wav"])
    sub.add_parser("sons")
    a = sub.add_parser("annexe")
    a.add_argument("nom")
    d = sub.add_parser("demo")
    d.add_argument("--out", required=True)
    d.add_argument("--direction", default="D4")
    args = ap.parse_args(argv)

    if args.cmd == "version":
        print(VERSION)
        if args.min:
            def tup(x):
                return tuple(int(p) for p in x.split("."))
            return 0 if tup(VERSION) >= tup(args.min) else 1
    elif args.cmd == "tirage":
        from .variation import tirer, NICHES
        if args.univers and args.niche == "doc":
            from .variation import _options
            if args.univers not in _options("doc")["univers"]:
                print(json.dumps({"erreur": "univers inconnu", "univers": _options("doc")["univers"]}, ensure_ascii=False))
                return 1
        print(json.dumps(tirer(args.run_id, args.titre, args.registre, not args.sans_ecrire, args.niche,
                               args.univers, args.duree), ensure_ascii=False))
    elif args.cmd == "empreinte":
        from .variation import empreinte
        with open(args.fichier, encoding="utf-8") as f:
            data = json.load(f)
        r = empreinte(args.run_id, data, args.registre, args.niche)
        print(json.dumps(r, ensure_ascii=False))
        return 0 if r.get("reussi") else 2
    elif args.cmd == "son":
        from .mix import build
        with open(args.cues, encoding="utf-8") as f:
            cues = json.load(f)
        t0 = time.time()
        m = build(cues, args.out, os.path.dirname(os.path.abspath(args.cues)), args.format)
        r = m["rapport"]
        print(json.dumps({"fichiers": m["fichiers"], "sfx_heros": len(m["storyboard"]["sfx_heros"]),
                          "moments_par_minute": r["moments_sonores_par_minute"],
                          "stems": [{k: x[k] for k in ("stem", "lufs", "true_peak_dbtp")} for x in r["stems"]],
                          "problemes": r["problemes"], "secondes": round(time.time() - t0, 1),
                          "manifeste": os.path.join(args.out, "manifeste.json")}, ensure_ascii=False))
    elif args.cmd == "sons":
        from .sfx import CATALOGUE
        from .ambiences import AMBIENCES
        from . import sfx_doc  # noqa: F401
        print("SONS:", "; ".join(f"{k} [{v[1]}] {v[2]}" for k, v in CATALOGUE.items()))
        print("AMBIANCES:", ", ".join(AMBIENCES))
        print("HUMEURS D'ACTE: tension, sombre, positif, resolution, mystere, emotion, climax (+ intensite 1-5)")
        print("GAMMES (direction D8 documentaire): hijaz, japonaise, pentatonique, pentatonique_mineure, dorienne, hongroise")
    elif args.cmd == "annexe":
        p = os.path.join(ROOT, "annexes", args.nom + ".md")
        if not os.path.exists(p):
            print("annexes :", ", ".join(sorted(x[:-3] for x in os.listdir(os.path.join(ROOT, "annexes")))))
            return 1
        with open(p, encoding="utf-8") as f:
            print(f.read())
    elif args.cmd == "demo":
        from .demo import run
        run(args.out, args.direction)
    return 0


if __name__ == "__main__":
    sys.exit(main())
