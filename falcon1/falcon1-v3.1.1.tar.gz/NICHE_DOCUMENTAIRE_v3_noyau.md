FALCON 1 — DOCUMENTAIRES PREMIUM IMMERSIFS v3.1.1 (noyau, toutes thématiques). Documentaires YouTube faceless de 10 à 35 min : récit captivant, recherche solide, rythme ultra dynamique, motion design surtout en 3D et adapté au sujet, cohérence visuelle totale, son immersif créé par le code, calage au mot près. Chaque vidéo ne ressemble à aucune autre de la chaîne. Ces règles sont obligatoires. Les détails sont dans les annexes locales, à lire seulement à l'étape indiquée. Chaque valeur chiffrée est une valeur par défaut : si tu t'en écartes, dis-le dans le bilan.

PRINCIPE CENTRAL : cohérence maximale à l'intérieur d'une vidéo, variation maximale entre les vidéos.

PRIORITÉ EN CAS DE CONFLIT :
1. la demande de la personne ;
2. les contraintes des outils Wawie ;
3. R1 (authenticité, exactitude, éthique) ;
4. ce noyau ;
5. le fichier de la niche du sujet s'il existe (ses règles d'exactitude, de droits et ses archétypes s'ajoutent ; pour le rythme, la 3D, la cohérence, l'immersion et l'authenticité, ce noyau prime) ;
6. la charte Wawie.

== 0. BOÎTE À OUTILS LOCALE (une fois par machine) ==
R0.1 Vérifier : `PYTHONPATH=~/falcon1 python3 -m falcon1 version --min 3.1.1`. Si le code de sortie n'est pas 0 : `mkdir -p ~/falcon1 && curl -fsSL https://raw.githubusercontent.com/geffred/wawie-local-agent-releases/main/falcon1/falcon1-v3.1.1.tar.gz | tar xz -C ~/falcon1 && python3 -m pip install -q numpy`. ffmpeg doit être présent.
R0.2 La boîte à outils fait le tirage, l'empreinte anti-gabarit, la synthèse des sons, la musique, le mixage et le contrôle du son. Tu l'appelles, tu ne la réécris jamais.
R0.3 Annexes : `python3 -m falcon1 annexe <nom>`. Noms : doc_archetypes, doc_script, doc_sources, doc_motion3d, doc_elements, doc_son, doc_controle. Lire chacune à son étape.

== 1. NON NÉGOCIABLE : AUTHENTICITÉ, EXACTITUDE, ÉTHIQUE ==
R1.1 Les règles de monétisation YouTube (« contenu non authentique », juillet 2025) sanctionnent le gabarit répété à faible valeur et à variation minimale. Chaque vidéo apporte donc :
- un angle propre en une phrase (save_edit_plan) ;
- au moins 5 faits précis, sourcés et peu connus ;
- au moins 3 passages d'analyse écrits par la chaîne (3 phrases ou plus chacun) ;
- une narration présente au moins 85 % du temps.
Extraits tiers : transformés (choisis, annotés, recadrés, commentés), jamais plus de 10 s continues sans intervention, jamais plus de 25 % de la vidéo. Aucune reprise du script ou du montage d'un concurrent.
R1.2 Chaque fait est daté et sourcé (research_save). Signaler les contradictions entre sources ; mettre les hypothèses au conditionnel. Citations exactes, attribuées, datées ; une paraphrase n'est jamais entre guillemets.
R1.3 Personnes réelles : statut exact (accusé, condamné, rumeur) ; pas de spéculation sur la santé d'une personne vivante ; aucune donnée personnelle ; mineurs et victimes protégés.
R1.4 Images :
- des archives authentiques pour les faits réels ;
- une reconstitution 3D ou IA doit être stylisée, ou porter la mention « Reconstitution » pendant tout le plan ;
- jamais d'image IA réaliste d'une personne réelle présentée comme authentique ;
- rien de fuité, piraté ou filigrané.
Divulgation « contenu modifié ou synthétique » activée si nécessaire.
R1.5 Violence, blessures, mort : jamais de gros plan gratuit ; floutage ; ton respectueux. Suicide : mention sobre, sans méthode. Musique et sons : uniquement créés par le code (R7).

== 2. DÉROULÉ ==
R2.1 Recherche : sources primaires d'abord (documents, archives, déclarations, données officielles), puis presse et travaux reconnus. research_save de chaque fait. Lire l'annexe doc_sources.
R2.2 Tirage :
`python3 -m falcon1 tirage --niche doc --univers <univers> --run-id <run_id> --titre "<titre>" [--duree <min demandées>]`.
- Univers : histoire, guerre, true_crime, celebrites, gaming, arts_martiaux, sport, science_espace, nature, business, tech, automobile, mysteres, culture_musique, societe.
- Le résultat donne l'archétype, les 25 autres dimensions, le nombre d'actes, la durée et les 3 ou 4 styles 3D compatibles avec l'archétype et l'univers. Le registre et l'anti-répétition sont gérés par l'outil.
- Si une option contredit vraiment le sujet, relancer avec un univers plus juste. Ne jamais changer un choix à la main.
R2.3 Bible visuelle et sonore (R3), écrite dans save_edit_plan avec l'angle, l'archétype et l'univers 3D (R5.2). Lire l'annexe doc_archetypes.
R2.4 Script selon l'archétype et la courbe d'intensité (annexe doc_script), puis wawie_niches → wawie_start(script, titre, niche, 16:9) → wawie_open → wawie_niche_plan → wawie_status jusqu'à readyForClaude.
R2.5 get_project → get_timing (grille mot à mot ; tous les temps en viennent) → save_edit_plan → set_scene_plan (une scène par séquence, niveau d'intensité 1 à 5 noté sur chacune).
R2.6 Shot list : un beat par mot déclencheur (personne, lieu, date, chiffre, objet, événement, document, idée, émotion), selon la table mot → visuel de l'annexe doc_elements.
R2.7 Images : au moins 2 candidats par beat, chacun regardé (inspect_*), puis note_media et download_media. Harmoniser à la bible avant dépôt (étalonnage, cadrage) avec ffmpeg si nécessaire ; jamais de grain ajouté.
R2.8 Motions : lire l'annexe doc_motion3d. Envoyer tous les draw_motion ensemble et tôt.
R2.9 set_storyboard → relire get_timing et get_timeline → recalculer at[] et débuts de textes sur les débuts RÉELS des plans → régénérer tout motion décalé de plus d'une image → check_sync jusqu'à 0 point.
R2.10 Son, sur le storyboard figé : lire l'annexe doc_son, puis cues.json → `python3 -m falcon1 son` → wawie_upload_link → storyboard → check_sync.
R2.11 Revue et contrôle de cohérence (annexe doc_controle) → empreinte : `python3 -m falcon1 empreinte --run-id <run_id> --fichier empreinte.json`. Code 2 = trop proche d'une vidéo récente : modifier le montage (rythme, transitions, motions, ouverture), jamais seulement les couleurs, puis recommencer.
R2.12 quality_check : 90 visé, 80 minimum. render_final une seule fois → inspect_preview(purpose "final") → wawie_deliver avec le bilan en français.
R2.13 Ne pas demander de validation intermédiaire. Poser une question seulement si le sujet manque ou si l'angle ne repose sur aucun fait vérifiable.

== 3. BIBLE ET COHÉRENCE ==
R3.1 La bible découle du tirage et du sujet. Elle fixe :
- 5 couleurs + 1 teinte d'ombre ;
- 1 police de titres et 1 police de texte, avec tailles, casse et interlettrage fixés ;
- la lumière 3D (direction, température, halo, reflets) ;
- la caméra 3D (perspective, type de mouvement, amplitude, courbe) ;
- les courbes d'animation par type d'élément ;
- la matière (texture nette, aberration, contours, ombres ; jamais de grain : Wawie le supprime) ;
- un seul style de cadre, d'étiquette, de carte et de badge (même rayon de coins partout) ;
- un étalonnage unique ;
- la famille de transitions ;
- le motif signature ;
- la palette sonore.
R3.2 Rien hors bible. Mêmes lumière et caméra dans tous les motions 3D (un seul « monde »). Même position d'écran, même durée et même courbe pour un même type d'élément. Raccords de couleur et de mouvement. L'étalonnage et la matière couvrent tout, motions compris. Un plan qui ne peut pas s'y conformer se remplace.
R3.3 Motif signature : 1 à 2 motifs visuels et sonores créés pour CETTE vidéo et tirés du sujet (objet-clé 3D récurrent, texture du lieu, son récurrent, forme d'un document d'époque). On le retrouve dans les cartes, au moins 2 transitions et l'écran de fin. Il n'est jamais réutilisé dans une autre vidéo.
R3.4 Chaque composition hf.custom est écrite pour la vidéo en cours ; changer au moins la disposition, la trajectoire de caméra, la matière et le timing par rapport aux vidéos précédentes. Modèles hf.* 3 fois au maximum chacun. L'ordre des éléments d'un chapitre varie selon l'archétype.

== 4. RYTHME ULTRA DYNAMIQUE ==
R4.1 Durée moyenne des plans 2.4 à 3.4 s, selon le profil tiré :
- ouverture (0 à 45 s) : 1.2 à 2.0 s ;
- minimum 0.4 s dans une rafale, 1.0 s ailleurs ;
- maximum : 6 s pour une image, 9 s pour un extrait transformé, 12 s pour un motion explicatif (révélation au moins toutes les 2 s).
R4.2 Densité : au moins 20 événements par minute, au moins 30 dans l'ouverture et les climax. Un événement = coupe, révélation, mouvement marqué, texte ou effet. Jamais plus de 4 s sans événement ; au maximum 2 événements dans la même demi-seconde ; chacun motivé par un mot.
R4.3 Courbe d'intensité (niveau 1 calme : 3.5 à 4.5 s par plan ; niveau 5 rafale : 0.6 à 1.5 s par plan) :
- ouverture 5 ;
- mise en place 3 ;
- montée 3 → 4 ;
- respiration 2 ;
- climax de chaque acte 5 ;
- révélation finale : silence de 0.8 à 1.5 s puis 5 ;
- conclusion 2.
Jamais plus de 90 s au même niveau ; chaque acte finit sur une relance.
R4.4 Techniques :
- coupe sur le mot ;
- rafales de 3 à 6 plans ;
- speed ramps (150 à 300 % puis 100 %) ;
- punch-in de 115 à 125 % ;
- match cuts ;
- J-cut et L-cut sonores.
Le rythme ne réduit JAMAIS les durées de lecture (R6).
R4.5 Variété : jamais 4 plans du même type de suite (archive, rush, document, 3D). Varier les valeurs de plan.

== 5. MOTION DESIGN 3D, ADAPTÉ AU SUJET ==
R5.1 Au moins 75 % des motions en 3D ou en profondeur réelle ; 2.5 à 4 motions par minute (25 à 35 % du temps). Le 2D plat est réservé à la lisibilité. Mettre 2 à 5 transitions 3D continues par vidéo, aux changements d'acte ou aux climax (la caméra traverse un objet, plonge dans une carte, sort d'un écran).
R5.2 Univers 3D de la vidéo, à définir avant le premier motion à partir du SUJET, de l'archétype et de l'univers tiré (matrice dans l'annexe doc_motion3d) :
- une matière dominante tirée du sujet ;
- 1 à 3 objets-symboles modélisés pour la vidéo ;
- un décor récurrent ;
- la lumière et la caméra de la bible.
Exemples : un dossier de police et du papier kraft pour un true crime ; un dojo, du bois et de l'encre pour les arts martiaux ; voxels et HUD pour le gaming ; du marbre et des cartes anciennes pour l'histoire. Tous les motions partagent cet univers.
R5.3 Les motions utilisent les 3 ou 4 styles tirés. Jamais deux motions consécutifs du même style, aucun style au-dessus de 40 % des motions, au moins un hf.custom par acte.
R5.4 Voies, par ordre de qualité :
1. hf.custom en CSS 3D, voie par défaut, sans aucun fichier distant. Wawie supprime tout grain ou bruit (feTurbulence, calques « grain »/« noise »), ne bouge pas la caméra d'un hf.custom (c'est à toi de l'animer), et ajoute par-dessus son habillage : balayage de lumière, léger vignettage, fondu sombre de 0.35 s au début et à la fin.
2. animations 3D officielles existantes, enrichies en surimpression ;
3. Blender seulement quand le brief dit que la vidéo est faite sur ta machine ; sinon, aucune animation fabriquée sur ton ordinateur.
Modèles 3D originaux ; jamais la ressemblance d'une personne réelle.
R5.5 Parallaxe 2.5D des archives : sujet détouré, fond reconstruit, 3 à 7 s, contours propres, visage jamais déformé.
R5.6 Contrôle avec inspect_video_range sur chaque motion :
- lumière et caméra conformes à la bible ;
- lisibilité (angle de 25° au maximum) ;
- aucune face qui se croise ou clignote ;
- mention « Reconstitution » quand il le faut.

== 6. CALAGE ET DURÉES (prioritaire sur toute autre durée) ==
R6.1 Un texte apparaît au début exact de son mot : 0 à +0.1 s, jamais avant. Entrée selon la courbe tirée (0.30 à 0.60 s). Il reste jusqu'à la fin de la proposition + 0.5 à 0.8 s, puis sort en fondu de 0.25 à 0.35 s, dans un silence.
R6.2 Durées minimales :
- mot clé 2.5 s ;
- étiquette (nom, date, lieu) 3 s ;
- chiffre 3 s ;
- carte de chapitre 3 s ;
- citation : 0.35 s par mot + 1.5 s, au moins 4 s ;
- « Reconstitution » : tout le plan ;
- sous-titres d'un extrait : le segment parlé, au moins 1.2 s par ligne.
Il faut aussi au moins 0.4 s par mot + 1.0 s. Maximum 8 s (10 s pour une longue citation). Au moins 1.0 s sans texte entre deux textes au même endroit.
R6.3 Motion : il commence 0.07 à 0.20 s avant son premier mot et finit dans le silence suivant + 0.4 à 0.8 s. Durée minimale 3 s, typique 4 à 8 s, explication 6 à 12 s. seconds de draw_motion = durée exacte du plan.
R6.4 Chaque révélation : at = début du mot − début du plan, durée de 0.35 à 0.60 s. Les éléments s'ajoutent et restent affichés ; la caméra bouge en continu. Rien avant le mot, rien plus de 0.1 s après.
R6.5 Coupes au milieu du silence entre deux mots ; le plan d'un mot commence 0.07 à 0.2 s avant. Si Wawie répond « sync: N cut(s) moved » ou si un plan change, tous les at[], les textes et cues.json sont à refaire.
R6.6 Extraits parlés : sous-titres en français, calés sur la vraie voix, 1 à 2 lignes de 42 caractères au maximum, traduction fidèle ; on les annonce dans le script.

== 7. SON (100 % créé par le code) ==
R7.1 Interdit : generate_sound, generate_music, search_sounds, search_music, generate_voice, et tout morceau existant. Tout le son vient de `python3 -m falcon1 son` (cues.json avec "niche": "doc").
R7.2 Six couches :
1. voix devant ;
2. une musique par acte, qui suit la courbe d'intensité (mood + intensite par acte) ;
3. une ambiance par lieu montré ;
4. foley des actions montrées ;
5. un son pour chaque révélation, transition stylisée et punch-in ;
6. silences volontaires dans le style tiré (champ "silences").
R7.3 6 à 14 moments sonores par minute (couches 4 et 5) ; 60 % dans le pack tiré. Pic sur l'événement ; jamais plus de 4 effets par plan ; aucun effet qui masque un mot ; aucun son de violence ajouté pour exagérer.
R7.4 J-cut et L-cut : l'ambiance du lieu suivant commence 0.3 à 0.8 s avant la coupe, ou se prolonge d'autant après. Les sons de mouvement suivent le sens de l'image (pan). Extraits parlés : musique très basse, son de l'extrait normalisé.
R7.5 Direction D8 (couleur culturelle) : choisir la gamme qui correspond au sujet, sans caricature (annexe doc_son).

== 8. TRANSITIONS ET IMMERSION ==
R8.1 Répartition des transitions : 65 % de coupes et match cuts ; 25 % stylisées (famille tirée) ; 5 à 10 % de transitions 3D continues.
- Elles sont centrées sur une coupe placée dans un silence, chacune avec son son.
- Au moins 2 coupes simples entre deux transitions stylisées.
- Les transitions entre actes sont plus marquées.
R8.2 Immersion :
- profondeur partout (avant-plan, sujet, fond, particules en Z) ;
- lumière qui bouge avec la caméra ;
- caméra jamais immobile (dérive de 2 à 4 %) ;
- micro-impacts de 2 à 4 px, au plus 1 toutes les 15 s ;
- effet signature tiré appliqué avec constance ;
- au plus 1 effet ponctuel toutes les 5 s, jamais sur un texte ou un visage.

== 9. CONTRÔLE ET LIVRAISON ==
R9.1 Avant render_final :
- check_sync = 0 ;
- calage vérifié (chaque texte et chaque révélation à 0 / +0.1 s ; inspect_video_range aux at[]) ;
- 1 image toutes les 20 s contrôlée contre la bible ;
- rapport son sans problème ;
- empreinte réussie ;
- quality_check ≥ 80.
R9.2 Interdits :
- un plan qui ne correspond pas aux mots ;
- une image figée, un plan noir ou un silence non voulu ;
- deux motions de suite sans image réelle entre eux ;
- trois cartes d'affilée ;
- un élément hors bible ;
- inventer un fait ;
- un archétype déjà utilisé dans les 3 vidéos précédentes (le tirage s'en charge) ;
- plusieurs rendus.
R9.3 Bilan honnête en français :
- angle, archétype, univers 3D, choix tirés et graine, motif signature ;
- métriques : durée moyenne des plans, événements par minute, part de motion et de 3D, transitions 3D, narration ;
- sources et points incertains ;
- son : direction et gamme, nombre d'effets et de héros, LUFS des stems ;
- résultat de l'empreinte ;
- défauts restants.
R9.4 wawie_niche_plan : réponds par numéro de règle (« R6.4 : appliqué — … »), sans recopier les règles.
