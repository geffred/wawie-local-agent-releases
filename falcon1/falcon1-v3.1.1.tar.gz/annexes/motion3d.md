# ANNEXE MOTION 3D (étape R1.7)

## Trois voies, par ordre de qualité
1. **Vraies animations 3D sourcées** : vues en coupe de constructeurs et d'équipementiers (moteur, boîte, clim, freins), posées comme rushs, puis enrichies en surimpression (étiquettes, flux, chiffres) calées sur la voix.
2. **Rendu Blender sur la machine Cowork** (seulement quand le brief dit que la vidéo est faite sur ta machine ; sinon, aucune animation fabriquée sur ton ordinateur) : script bpy sans interface, Eevee 1920x1080 à 30 i/s, durée = durée exacte du plan, révélations calées sur get_timing, dépôt avec wawie_upload_link. Pour les moments forts : cartes titre C4 à C8, rayons X, vues éclatées.
3. **3D temps réel en hf.custom** (voie par défaut) : CSS 3D + GSAP, sans aucun script ni fichier distant (pas de three.js chargé depuis le web).

## Recettes hf.custom
- **Scène** : `#stage{perspective:1400px;perspective-origin:50% 45%}`, `#world{transform-style:preserve-3d}`, tous les éléments placés en translateZ.
- **Caméra** : animer #world sur toute la durée, en ease sine.inOut ou none, jamais immobile. Dolly translateZ -200 → 0, orbite rotateY -18° → 12°, plongée rotateX 8° → 2°. Amplitude selon la grammaire caméra tirée (G1 lente, G2 dynamique, G3 technique, G4 cinéma).
- **Texte extrudé** : 12 à 20 copies en translateZ -1 à -20 px, dégradé du foncé au clair de la palette ; la copie de face en couleur primaire avec un reflet (background-clip:text).
- **Volumes** : cubes et plaques à 6 faces, cylindres de 12 à 24 faces, barres extrudées, panneaux avec une épaisseur réelle.
- **Vue éclatée** : photos détourées (imageAssets) sur 3 à 6 plans en profondeur, qui s'écartent en translateZ sur le mot clé, avec étiquettes reliées par des lignes.
- **Lumière** : spéculaire qui glisse pendant l'orbite, ombre portée douce (ellipse floutée), halo (radial + blend screen), reflet au sol (copie inversée, 15 %, flou 6 px).
- **Profondeur de champ** : fond flou 4 à 10 px, avant-plan 2 à 4 px, sujet net ; particules réparties en Z avec parallaxe.
- **Matière** : textures nettes (dégradés, motifs SVG), légère aberration chromatique sur les bords pour les styles techniques. Jamais de grain ni de feTurbulence : Wawie les supprime, et il ajoute déjà un léger vignettage, un balayage de lumière et un fondu de 0.35 s au début et à la fin. La caméra d'un hf.custom, c'est toi qui l'animes.
- **Performance** : 150 éléments animés au maximum ; filtres lourds sur 3 calques au maximum ; si le rendu échoue, tester d'abord avec un seconds court.

## Styles (tirer 3 ou 4 par vidéo, jamais deux fois de suite le même)
- **M1** vue éclatée
- **M2** blueprint qui devient volumique
- **M3** rayons X avec orbite (pièce en surbrillance_3D)
- **M4** infographie 3D (barres, jauges, compteurs)
- **M5** flux 3D (huile, chaleur, air, courant)
- **M6** fiches flottantes en parallaxe
- **M7** tableau de bord 3D qui réagit à la voix
- **M8** diorama isométrique

## Calage
Les règles R2.4 et R2.5 s'appliquent. Exemple : plan de 42.10 à 50.30 s (seconds 8.20) ; mots « condenser » 42.30, « heat » 44.05, « fan » 46.40, « 30% » 48.15 → at = [0.20, 1.95, 4.30, 6.05].
```
tl.from('#condenser',{opacity:0,scale:.9,duration:.5,ease:'power3.out'},0.20);
tl.to('#heatArrows',{strokeDashoffset:0,duration:.9,ease:'power2.inOut'},1.95);
tl.from('#fan',{opacity:0,rotation:-30,duration:.5},4.30);
tl.from('#stat',{opacity:0,y:30,duration:.4,ease:'back.out(1.4)'},6.05);
tl.fromTo('#world',{rotationY:-14,z:-160},{rotationY:10,z:0,duration:8.2,ease:'none'},0);
```
Les sons des révélations (tick, scan, impact léger) sont déclarés dans cues.json aux mêmes instants que les mots (annexe son).

## Contrôle
Passer inspect_video_range sur chaque motion 3D, juste avant chaque at et à at + 0.5 s. Vérifier :
- le texte en perspective reste lisible (angle de 25° au maximum) ;
- aucune face ne se croise ni ne clignote ;
- le sujet est net ;
- la durée de l'asset est égale à la durée du plan.

Règle de répartition : les 2D plats ne servent que pour la lisibilité (petits chiffres, listes courtes). Ils restent sous 30 % des motions.
