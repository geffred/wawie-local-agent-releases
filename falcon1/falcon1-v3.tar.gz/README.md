# Falcon 1 — boîte à outils locale de la niche automobile (v3.0)

Ce paquet s'installe **une fois** sur la machine Cowork. Il évite de renvoyer environ 70 000 caractères d'instructions et de faire réécrire le code du son à Falcon 1 à chaque montage.

| Fichier | Rôle |
|---|---|
| `NICHE_AUTOMOBILE_v3_noyau.md` | Texte à coller dans les **instructions de niche** de Wawie (environ 10 000 caractères, une seule partie). |
| `annexes/*.md` | Détails lus à la demande (`python3 -m falcon1 annexe son`…) : script, sources, elements, motion3d, son, reference. |
| `falcon1/variation.py` + `options.json` | Tirage des 17 dimensions de style, anti-répétition, registre local. |
| `falcon1/sfx.py` | 40 effets synthétisés (air, cinéma, interface, argent, atelier, automobile). |
| `falcon1/ambiences.py` | 7 ambiances bouclables. |
| `falcon1/music.py` | Compositeur : 8 directions musicales (D1 à D8), 4 humeurs d'acte. |
| `falcon1/mix.py` | Calage sur get_timing, ducking mot à mot, stems pour Wawie, contrôle qualité. |
| `falcon1/dsp.py` | Filtres, réverbérations synthétiques, compresseur, limiteur au pic vrai, LUFS (BS.1770-4). |

Dépendances : Python ≥ 3.10, numpy et ffmpeg (pour FLAC, m4a et mp3). Aucune banque de sons, aucun appel réseau.

## Installation sur Cowork
```bash
mkdir -p ~/falcon1 && curl -fsSL URL_PAQUET_FALCON1 | tar xz -C ~/falcon1 && python3 -m pip install -q numpy
PYTHONPATH=~/falcon1 python3 -m falcon1 version   # 3.0.0
```
`URL_PAQUET_FALCON1` est l'URL publique de l'archive produite par `./empaqueter.sh`. Remplace-la aussi dans le noyau.

## Commandes
```bash
python3 -m falcon1 tirage --run-id R --titre "T"      # choix de la vidéo (JSON), écrit le registre
python3 -m falcon1 son --cues cues.json --out son/    # stems + héros + manifeste.json
python3 -m falcon1 sons                               # liste des sons, ambiances, humeurs
python3 -m falcon1 annexe son                         # affiche une annexe
python3 -m falcon1 demo --out demo/                   # pack d'écoute + 60 s de démonstration
```
Le format de `cues.json` est décrit dans `annexes/son.md`.

## Performances mesurées (machine de test 4 cœurs)
- Un effet : moins de 0.8 s.
- Une ambiance de 40 s : environ 4 s.
- Musique : environ 0.2 × le temps réel.
- Vidéo de 18 min complète (musique en 4 actes, 186 effets dont 26 héros, 3 ambiances) : environ 4 min, 3.2 Go de mémoire au maximum.

## Limites connues (honnêtes)
- Tout est de la synthèse. Les effets « cinéma » (impacts, risers, whooshs, braams) et les musiques électroniques (D1, D4, D7, D8) sont le terrain naturel de la synthèse. Les directions à instruments acoustiques (D2 cordes, D3 piano électrique, D5 guitare) sonnent synthétiques : D2 est donc définie comme « trailer hybride synthétique ».
- Le niveau de la voix Wawie n'est pas mesurable avant le rendu. Par défaut, le moteur suppose -16 LUFS ; si la voix est accessible, mesure-la et mets `voix_lufs`.
