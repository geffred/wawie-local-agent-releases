"""Assemblage sur la timeline de la vidéo : calage au mot, ducking sous la voix, stems pour Wawie, contrôle qualité.

Entrée : un petit fichier cues.json écrit par Falcon 1 à chaque vidéo (voir README).
Sorties (dossier --out) :
  musique_stem.flac   -> storyboard music [{"track": A_musique, "start": 0, "end": total, "volume": 0.5,
                         "autoDuck": false, "fadeIn": 0, "fadeOut": 2}]
  effets_stem.flac    -> storyboard ambience [{"sound": A_effets, "start": 0, "end": total, "volume": 0.5}]
  heros/NN_nom.wav    -> sfx des plans [{"sound": A_n, "at": ..., "volume": ..., "length": ...}] (40 max)
  manifeste.json      -> extraits de storyboard prêts à coller + rapport qualité
"""
from __future__ import annotations

import hashlib
import json
import math
import os

import numpy as np

from .dsp import (SR, n_of, stereo, mono, pan, fade, undb, db, filt, bp, mix_into, limiter, loudness, write_wav,
                  encode, _follow, peak_normalize, true_peak_db, moving_average, interp_curve)
from . import sfx as SFX
from . import ambiences as AMB
from . import music as MUS

WAWIE_STEM_VOLUME = 0.5          # volume posé dans le storyboard pour les deux stems
STEM_PREGAIN_DB = -db(WAWIE_STEM_VOLUME)  # +6.02 dB compensés à l'intérieur du fichier
MAX_HEROS = 40
VOICE_REF_LUFS = -16.0           # niveau supposé de la voix Wawie si voix_lufs n'est pas donné

# Niveau par défaut de chaque son par rapport à une voix à -16 LUFS (gain appliqué au son normalisé).
DEFAULT_GAIN_DB = {
    "whoosh": -13, "whoosh_deep": -12, "whoosh_bright": -14, "whip": -13, "swoosh_soft": -16, "light_flash": -14,
    "swipe": -16, "impact": -7, "sub_drop": -8, "riser": -14, "reverse_swell": -13, "braam": -8, "pop": -14,
    "bubble_pop": -14, "tick": -20, "glitch": -13, "hud_beep": -18, "scan": -16, "mouse_click": -12, "ding": -12,
    "ding_low": -14, "buzzer": -10, "notif_bell": -12, "cha_ching": -8, "money_rustle": -16, "paper": -16,
    "coins": -15, "ratchet": -15, "wrench_clink": -15, "lock_click": -14, "impact_gun": -14, "car_door": -12,
    "key_jingle": -16, "engine_rev": -12, "starter": -12, "starter_fail": -12, "turbo": -13, "tire_squeal": -14,
    "turn_signal": -18, "oil_pour": -17,
}


def _seed_int(graine: str, *salt) -> int:
    h = hashlib.sha256((str(graine) + "|" + "|".join(map(str, salt))).encode()).hexdigest()
    return int(h[:12], 16)


def load_words(cues: dict, base: str) -> list:
    """Mots [mot, début, fin] : cues["mots"], ou un export brut de get_timing (fichier JSON) dans cues["timing"]."""
    if "mots" in cues:
        return [[str(w[0]), float(w[1]), float(w[2])] for w in cues["mots"]]
    path = cues.get("timing")
    if not path:
        return []
    with open(os.path.join(base, path)) as f:
        data = json.load(f)
    out = []

    def walk(o):
        if isinstance(o, list):
            if len(o) >= 3 and isinstance(o[0], str) and all(isinstance(v, (int, float)) for v in o[1:3]):
                out.append([o[0], float(o[1]), float(o[2])])
            else:
                for v in o:
                    walk(v)
        elif isinstance(o, dict):
            w = o.get("word", o.get("w", o.get("mot")))
            s = o.get("start", o.get("s", o.get("debut")))
            e = o.get("end", o.get("e", o.get("fin")))
            if isinstance(w, str) and isinstance(s, (int, float)) and isinstance(e, (int, float)):
                out.append([w, float(s), float(e)])
            else:
                for v in o.values():
                    walk(v)
    walk(data)
    out.sort(key=lambda w: w[1])
    return out


def voice_activity(words: list, total: float, merge_gap: float = 0.35) -> list:
    spans = []
    for _, s, e in words:
        if spans and s - spans[-1][1] < merge_gap:
            spans[-1][1] = max(spans[-1][1], e)
        else:
            spans.append([s, e])
    return [[max(0.0, s), min(total, e)] for s, e in spans]


def duck_curve(spans, total, depth_db, lift=(), lift_db=3.0, lookahead=0.08, attack=0.10, release=0.40,
               min_pause=0.8):
    """Courbe de gain (dB) : -depth sous la voix, 0 dans les pauses >= min_pause, +lift sur les zones de relance."""
    block = 48
    nb = int(math.ceil(n_of(total) / block))
    tb = (np.arange(nb) + 0.5) * block / SR
    target = np.zeros(nb)
    filled = []
    for i, (s, e) in enumerate(spans):
        # une pause trop courte reste baissée : on prolonge la zone jusqu'au mot suivant
        nxt = spans[i + 1][0] if i + 1 < len(spans) else None
        end = nxt if nxt is not None and nxt - e < min_pause else e
        filled.append((s - lookahead, end + 0.05))
    for s, e in filled:
        target[(tb >= s) & (tb < e)] = -depth_db
    for s, e in lift:
        m = (tb >= s) & (tb < e)
        target[m] = np.maximum(target[m], 0) + lift_db
    bps = SR / block
    # attaque = descente du gain : le suiveur travaille sur la « réduction » (valeur positive)
    red = _follow(-target, attack * bps, release * bps)
    return interp_curve(n_of(total), (np.arange(nb) + 0.5) * block, -red)


def _apply_duck(x, gain_db, pocket_db, active_mask, chunk_s=30.0):
    """Gain large bande + poche supplémentaire dans 1-4 kHz (là où la voix est intelligible). Par morceaux."""
    out = np.empty(x.shape, dtype=np.float32)
    n = len(x)
    c = n_of(chunk_s)
    m = 1 << 15
    for s0 in range(0, n, c):
        a, b = max(0, s0 - m), min(n, s0 + c + m)
        seg = x[a:b].astype(np.float64)
        mid = filt(seg, bp(1000, 4000, 2), phase="zero")
        k0, k1 = s0 - a, s0 - a + min(c, n - s0)
        g = undb(gain_db[s0:s0 + (k1 - k0)])[:, None]
        gp = undb(gain_db[s0:s0 + (k1 - k0)] - pocket_db * active_mask[s0:s0 + (k1 - k0)])[:, None]
        out[s0:s0 + (k1 - k0)] = (seg[k0:k1] - mid[k0:k1]) * g + mid[k0:k1] * gp
    return out


def _active_mask(spans, total):
    m = np.zeros(n_of(total), np.float32)
    for s, e in spans:
        m[n_of(max(0, s - 0.05)):n_of(min(total, e + 0.1))] = 1
    return moving_average(m, n_of(0.08))


def _qa_signal(x, name, skip=()):
    xs = stereo(x)
    L = loudness(xs)
    clicks = 0
    num = dl = dr = 0.0
    for s in range(0, len(xs), 1 << 21):
        c = xs[s:s + (1 << 21)].astype(np.float64)
        d = np.abs(np.diff(c.mean(axis=1)))
        loc = moving_average(d, 480) + 1e-6
        hit = np.nonzero((d > 0.25) & (d > 25 * loc))[0] + s
        clicks += sum(1 for h in hit if not any(a <= h / SR <= b for a, b in skip))
        num += float(np.sum(c[:, 0] * c[:, 1]))
        dl += float(np.sum(c[:, 0] ** 2))
        dr += float(np.sum(c[:, 1] ** 2))
    corr = num / math.sqrt(dl * dr) if dl > 0 and dr > 0 else 1.0
    rep = {"stem": name, **L, "dc": round(float(np.mean(xs)), 6), "clics_suspects": clicks,
           "correlation_LR": round(corr, 3), "nan": bool(not np.isfinite(xs).all())}
    probs = []
    if rep["nan"]:
        probs.append("valeurs NaN")
    if L["true_peak_dbtp"] > -1.0:
        probs.append(f"pic vrai {L['true_peak_dbtp']} dBTP > -1")
    if clicks:
        probs.append(f"{clicks} clic(s) suspect(s)")
    if corr < 0:
        probs.append("corrélation L/R négative (risque en mono)")
    if abs(rep["dc"]) > 0.002:
        probs.append("décalage DC")
    rep["problemes"] = probs
    return rep


def build(cues: dict, out_dir: str, base: str = ".", fmt: str = "flac") -> dict:
    os.makedirs(out_dir, exist_ok=True)
    total = float(cues["total"])
    graine = str(cues.get("graine", "0"))
    words = load_words(cues, base)
    spans = voice_activity(words, total)
    voix = float(cues.get("voix_lufs", VOICE_REF_LUFS))
    offset = voix - VOICE_REF_LUFS
    active = _active_mask(spans, total)
    report = {"total_s": total, "graine": graine, "mots": len(words), "problemes": []}

    # ----------------------------------------------------------- musique
    acts = cues.get("actes") or [{"start": 0, "end": total, "mood": "tension"}]
    acts = sorted(acts, key=lambda a: a["start"])
    acts[0]["start"] = 0.0
    acts[-1]["end"] = total
    music, info = MUS.compose(cues.get("direction_musicale", "D1"), acts, total, _seed_int(graine, "musique"))
    pause_lufs = voix + float(cues.get("musique_pause_lu", -9.0))   # niveau dans les respirations
    music = np.asarray(music, np.float32) * np.float32(undb(pause_lufs - (-18.0)))
    depth = float(cues.get("ducking_db", 11.0))                     # -> ~ -20 dB sous la voix
    lift = [tuple(x) for x in cues.get("relances", [])]
    lift.append((max(0.0, total - 8.0), total))                      # la musique remonte sur la fin
    curve = duck_curve(spans, total, depth, lift)
    music = _apply_duck(music, curve, 3.0, active)
    del curve
    music = fade(music, 0.01, 2.0)
    music *= np.float32(undb(STEM_PREGAIN_DB))
    music_stem = limiter(music, -1.0)
    del music
    report["musique"] = info

    # ----------------------------------------------------------- effets + ambiances
    fx = np.zeros((n_of(total), 2), dtype=np.float32)
    heros = []
    events = []
    plain_sfx = sorted(cues.get("sfx", []), key=lambda e: float(e["at"]))
    hero_list = [e for e in plain_sfx if e.get("hero")]
    if len(hero_list) > MAX_HEROS:
        report["problemes"].append(f"{len(hero_list)} sons héros > {MAX_HEROS} : les suivants passent dans le stem")
        for e in hero_list[MAX_HEROS:]:
            e["hero"] = False
    hdir = os.path.join(out_dir, "heros")
    os.makedirs(hdir, exist_ok=True)
    last_by_name = {}
    for i, e in enumerate(plain_sfx):
        name = e["son"]
        if name not in SFX.CATALOGUE:
            report["problemes"].append(f"son inconnu '{name}' (à {e['at']} s) ignoré")
            continue
        rng = np.random.default_rng(_seed_int(graine, "sfx", i, name))
        if name == "riser" and "duree" in e:
            a, pic = SFX.riser(rng, float(e["duree"]))
        else:
            a, pic = SFX.make(name, rng)
        target = float(e["at"])
        start = target - pic if e.get("cale", "pic") == "pic" else target
        g_db = DEFAULT_GAIN_DB.get(name, -14) + float(e.get("gain_db", 0)) + offset
        if "pan" in e:
            a = pan(mono(a), float(e["pan"])) * math.sqrt(2) * 0.5 + a * 0.5
        if name in last_by_name and target - last_by_name[name] < 4.0:
            report["problemes"].append(f"'{name}' répété à moins de 4 s ({last_by_name[name]:.2f} puis {target:.2f})")
        last_by_name[name] = target
        events.append({"son": name, "at": round(target, 3), "famille": SFX.CATALOGUE[name][1], "hero": bool(e.get("hero"))})
        if e.get("hero"):
            if start < 0:
                a = a[n_of(-start):]
                start = 0.0
            a = a[: n_of(10.0)]
            a = fade(a, 0.0005, 0.05)
            path = os.path.join(hdir, f"{len(heros) + 1:02d}_{name}.wav")
            vol = float(np.clip(undb(g_db + 1.0), 0.02, 1.0))  # fichier normalisé à -1 dBFS
            write_wav(path, peak_normalize(a, -1.0))
            heros.append({"fichier": os.path.relpath(path, out_dir), "son": name, "at": round(start, 3),
                          "pic_sur": round(target, 3), "volume": round(vol, 3), "length": round(len(a) / SR, 2)})
        else:
            mix_into(fx, a, n_of(start), undb(g_db))
    # anti-masquage : poche 1-4 kHz sous la voix sur les effets du stem
    fx = _apply_duck(fx, np.zeros(len(fx)), 3.0, active)

    beds = np.zeros((n_of(total), 2), dtype=np.float32)
    for j, b in enumerate(sorted(cues.get("ambiances", []), key=lambda b: b["start"])):
        lieu = b["lieu"]
        if lieu not in AMB.AMBIENCES:
            report["problemes"].append(f"ambiance inconnue '{lieu}' ignorée")
            continue
        s, e = float(b["start"]), min(total, float(b["end"]))
        loop = AMB.make(lieu, np.random.default_rng(_seed_int(graine, "amb", j, lieu)), 40.0)
        reps = int(math.ceil((e - s + 2) / (len(loop) / SR)))
        seg = np.concatenate([loop] * max(1, reps))[: n_of(e - s + 1.0)]
        seg = fade(seg, 1.0, 1.0)
        mix_into(beds, seg, n_of(max(0, s - 0.5)), undb(float(b.get("gain_db", 0)) + offset))
    beds *= undb(-3.0 * active).astype(np.float32)[:, None]
    fx += beds
    del beds
    fx *= np.float32(undb(STEM_PREGAIN_DB))
    fx_stem = limiter(fx, -1.0)
    del fx

    # ----------------------------------------------------------- écriture
    files = {}
    for name, sig in (("musique_stem", music_stem), ("effets_stem", fx_stem)):
        wav = os.path.join(out_dir, name + ".wav")
        write_wav(wav, sig)
        files[name] = os.path.basename(encode(wav, fmt)) if fmt != "wav" else os.path.basename(wav)
        if fmt != "wav" and files[name] != os.path.basename(wav):
            os.remove(wav)

    # ----------------------------------------------------------- contrôle qualité
    voulus = [(ev["at"] - 0.2, ev["at"] + 1.2) for ev in events if ev["son"] == "glitch"]  # ruptures voulues
    report["stems"] = [_qa_signal(music_stem, "musique"), _qa_signal(fx_stem, "effets", voulus)]
    for r in report["stems"]:
        report["problemes"] += [f"{r['stem']} : {p}" for p in r["problemes"]]
    minutes = max(total / 60, 1e-6)
    report["moments_sonores_par_minute"] = round(len(events) / minutes, 1)
    if not 6 <= report["moments_sonores_par_minute"] <= 15:
        report["problemes"].append(f"densité {report['moments_sonores_par_minute']}/min hors 6-15")
    fam = {}
    for ev in events:
        fam[ev["famille"]] = fam.get(ev["famille"], 0) + 1
    pack = cues.get("pack_sfx")
    if pack and events:
        share = round(100 * fam.get(pack, 0) / len(events))
        report["part_pack_tire_pct"] = share
        if share < 50:
            report["problemes"].append(f"pack tiré {pack} = {share} % des sons (cible ≈ 60 %)")
    report["familles"] = fam
    if words:
        starts = np.array([w[1] for w in words])
        far = [ev for ev in events if ev["hero"] and np.min(np.abs(starts - ev["at"])) > 0.25]
        report["heros_loin_d_un_mot"] = len(far)
    report["sons"] = events

    manifest = {
        "fichiers": files,
        "storyboard": {
            "music": [{"track": "<asset de " + files["musique_stem"] + ">", "start": 0, "end": round(total, 3),
                       "volume": WAWIE_STEM_VOLUME, "autoDuck": False, "fadeIn": 0, "fadeOut": 2}],
            "ambience": [{"sound": "<asset de " + files["effets_stem"] + ">", "start": 0, "end": round(total, 3),
                          "volume": WAWIE_STEM_VOLUME}],
            "sfx_heros": heros,
        },
        "rapport": report,
    }
    with open(os.path.join(out_dir, "manifeste.json"), "w") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=1)
    return manifest
