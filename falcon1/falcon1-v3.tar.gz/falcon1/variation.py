"""Tirage de l'identité visuelle et sonore d'une vidéo (graine + anti-répétition + registre local).

Seuls les choix retenus sont affichés : Falcon 1 ne lit jamais le catalogue complet des options.
"""
from __future__ import annotations

import datetime
import hashlib
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DIMENSIONS = ["palette", "typographie", "famille_cartes_titre", "style_mots_cles", "style_etiquettes", "style_prix",
              "format_numerotation", "jeu_de_transitions", "styles_motion_3D", "grammaire_camera",
              "direction_musicale", "pack_sfx", "etalonnage", "structure_accroche", "style_bouton_abonnement",
              "mise_en_page_ecran_de_fin", "style_mise_en_evidence"]
COMBO = ("palette", "typographie", "famille_cartes_titre")


def graine(run_id: str, titre: str) -> str:
    return hashlib.sha256((run_id + titre).encode("utf-8")).hexdigest()[:8]


def _options():
    with open(os.path.join(HERE, "options.json"), encoding="utf-8") as f:
        return json.load(f)


def _key(v):
    return "+".join(v) if isinstance(v, list) else v


def tirer(run_id: str, titre: str, registre_path: str, ecrire: bool = True) -> dict:
    opts = _options()
    reg = []
    if os.path.exists(registre_path):
        try:
            with open(registre_path, encoding="utf-8") as f:
                reg = json.load(f)
        except (OSError, ValueError):
            reg = []
    reg = [r for r in reg if r.get("run_id") != run_id]
    g = graine(run_id, titre)
    base = int(g, 16)
    prev = reg[-1]["choix"] if reg else {}
    last3 = [r["choix"] for r in reg[-3:]]
    last5 = [r["choix"] for r in reg[-5:]]
    last10 = [r["choix"] for r in reg[-10:]]
    choix: dict = {}

    def ok(dim, val):
        if prev.get(dim) is not None and _key(prev.get(dim)) == _key(val):
            return False
        if dim == "styles_motion_3D":
            # le jeu de styles est l'option : jamais le même jeu dans 2 des 5 dernières,
            # et au moins 2 styles absents de la vidéo précédente
            if sum(1 for c in last5 if sorted(c.get(dim) or []) == sorted(val)) >= 2:
                return False
            return sum(1 for s in val if s not in (prev.get(dim) or [])) >= 2
        return sum(1 for c in last5 if _key(c.get(dim)) == _key(val)) < 2

    for rank, dim in enumerate(DIMENSIONS):
        ids = [o["id"] for o in opts[dim]]
        start = (base + rank * 7) % len(ids)
        for shift in range(len(ids)):
            i = (start + shift) % len(ids)
            if dim == "styles_motion_3D":
                k = 3 + (base >> 5) % 2
                val = [ids[(i + j * 3) % len(ids)] for j in range(k)]
                val = list(dict.fromkeys(val))
            else:
                val = ids[i]
            if ok(dim, val) or shift == len(ids) - 1:
                choix[dim] = val
                break

    def bump(dim):
        ids = [o["id"] for o in opts[dim]]
        cur = choix[dim][0] if isinstance(choix[dim], list) else choix[dim]
        i = ids.index(cur)
        for s in range(1, len(ids)):
            v = ids[(i + s) % len(ids)]
            val = [ids[(i + s + j * 3) % len(ids)] for j in range(len(choix[dim]))] if isinstance(choix[dim], list) else v
            if ok(dim, val):
                choix[dim] = val
                return

    # combinaison palette + typo + cartes jamais vue dans les 10 dernières
    for _ in range(40):
        combo = tuple(choix[d] for d in COMBO)
        if all(tuple(c.get(d) for d in COMBO) != combo for c in last10):
            break
        bump("famille_cartes_titre")
    # au moins 12 dimensions sur 17 différentes de chacune des 3 dernières
    for c in last3:
        same = [d for d in DIMENSIONS if _key(c.get(d)) == _key(choix[d])]
        for d in same[: max(0, len(same) - 5)]:
            bump(d)

    detail = {}
    for dim in DIMENSIONS:
        by = {o["id"]: o for o in opts[dim]}
        v = choix[dim]
        detail[dim] = [by[x] for x in v] if isinstance(v, list) else by[v]
    entry = {"run_id": run_id, "titre": titre, "date": datetime.date.today().isoformat(), "graine": g, "choix": choix}
    if ecrire:
        os.makedirs(os.path.dirname(os.path.abspath(registre_path)), exist_ok=True)
        with open(registre_path, "w", encoding="utf-8") as f:
            json.dump(reg + [entry], f, ensure_ascii=False, indent=1)
    return {"graine": g, "choix": choix, "detail": detail}
