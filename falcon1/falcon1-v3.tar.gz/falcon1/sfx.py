"""Effets sonores synthétisés (aucun échantillon externe).

Chaque fonction reçoit un générateur aléatoire (graine de la vidéo) et renvoie (audio stéréo, pic)
où « pic » est l'instant (s) du point fort du son : c'est lui qu'on cale sur le mot ou la coupe.
Chaque son est construit en couches (attaque / corps / queue / brillance) puis passé dans un espace.
"""
from __future__ import annotations

import math

import numpy as np

from .dsp import (SR, n_of, t_axis, stereo, mono, pan, fade, peak_normalize, adsr, exp_decay, smooth_random,
                  white, pink, brown, filt, lp, hp, bp, bell, shelf, chain, stft_shape, band_gain, saturate,
                  bitcrush, widen, reverb, trim_tail, mtof, mix_into, undb)


def _u(rng, a, b):
    return float(rng.uniform(a, b))


def _modal(freqs, decays, amps, dur, rng, jitter=0.004):
    """Résonateur modal (métal, verre, cloche) : somme de partiels amortis."""
    t = t_axis(dur)
    y = np.zeros_like(t)
    for f, d, a in zip(freqs, decays, amps):
        f = f * (1 + rng.uniform(-jitter, jitter))
        y += a * np.sin(2 * math.pi * f * t + rng.uniform(0, 6.28)) * np.exp(-t / d)
    return y


def _click(rng, dur=0.004, lo=1500, hi=12000):
    n = n_of(dur)
    c = white(n, rng) * np.exp(-np.arange(n) / (n / 5))
    return filt(c, bp(lo, hi, 1))


def _finish(x, space=None, wet=0.0, seed=1, peak_db=-1.0, width=0.0, rng=None):
    x = stereo(x)
    if width > 0:
        x = widen(mono(x), width, rng) * 0.5 + x * 0.5
    if space:
        x = reverb(x, space, wet, seed)
    return peak_normalize(trim_tail(x), peak_db)


# ======================================================================= air / transitions

def whoosh(rng, dur=None, weight="mid", direction=None, sparkle=False):
    """Passage d'air : bruit rose dans une bande qui glisse, doppler, panoramique qui traverse."""
    dur = dur or _u(rng, 0.55, 1.1)
    n = n_of(dur)
    peak = _u(rng, 0.52, 0.68)
    lo, hi = {"deep": (90, 900), "mid": (300, 3200), "bright": (700, 7500)}[weight]
    hi *= _u(rng, 0.85, 1.2)
    x = pink(n, rng)

    def center(t):
        u = np.clip(t / dur, 0, 1)
        k = np.where(u < peak, np.clip(u / peak, 0, 1) ** 1.6, 1 - np.clip((u - peak) / (1 - peak), 0, 1) ** 0.8)
        return lo + (hi - lo) * np.clip(k, 0, 1)
    body = stft_shape(x, band_gain(center, lambda t: 1.4 + 0.8 * np.clip(t / dur, 0, 1)), 1024, 128)
    u = np.arange(n) / n
    env = np.where(u < peak, np.clip(u / peak, 0, 1) ** 2.2, np.exp(-np.clip((u - peak) / (1 - peak), 0, None) * 4.2))
    body *= env
    air = filt(white(n, rng), hp(5500, 2)) * env ** 1.5 * 0.12
    out = body + air
    if weight == "deep":
        t = np.arange(n) / SR
        f = 70 * np.exp(-1.2 * np.abs(u - peak))
        out += 0.6 * np.sin(2 * math.pi * np.cumsum(f) / SR) * env
    if sparkle:
        for _ in range(int(_u(rng, 18, 34))):
            at = int(n * _u(rng, peak * 0.6, min(0.98, peak + 0.3)))
            g = _modal([_u(rng, 3500, 9500)], [_u(rng, 0.015, 0.05)], [1], 0.12, rng)
            mix_into(out, g * _u(rng, 0.04, 0.12), at)
    d = direction if direction is not None else (1 if rng.random() < 0.5 else -1)
    p = d * (np.clip(u / peak, 0, 1) * 1.6 - 0.8)
    x2 = pan(out, p * 0.85)
    return _finish(x2, "room", 0.12, int(rng.integers(1e6)), -2.0, rng=rng), dur * peak


def whip(rng):
    a, p = whoosh(rng, dur=_u(rng, 0.22, 0.32), weight="bright")
    return a, p


def swoosh_soft(rng):
    a, p = whoosh(rng, dur=_u(rng, 0.9, 1.4), weight="mid", sparkle=True)
    return peak_normalize(filt(a, lp(6500, 1)), -3), p


def light_flash(rng):
    """Whoosh lumineux : souffle brillant + scintillement + petite note aérienne."""
    a, p = whoosh(rng, dur=_u(rng, 0.6, 0.9), weight="bright", sparkle=True)
    t = t_axis(len(a) / SR)
    tone = np.sin(2 * math.pi * _u(rng, 1800, 2600) * t) * np.exp(-np.abs(t - p) / 0.12) * 0.08
    return peak_normalize(a + stereo(widen(tone, 0.8, rng)), -2.5), p


def swipe(rng):
    dur = _u(rng, 0.18, 0.28)
    n = n_of(dur)
    x = stft_shape(white(n, rng), band_gain(lambda t: 2500 + 6000 * np.clip(t / dur, 0, 1), 1.2), 512, 64)
    env = np.sin(np.linspace(0, math.pi, n)) ** 1.5
    return _finish(pan(x * env, np.linspace(-0.6, 0.6, n)), "room", 0.08, 3, -4), dur * 0.5


# ======================================================================= impacts / cinema

def impact(rng, weight=1.0):
    """Impact cinéma : attaque, coup de poing grave, sub saturé, corps, queue métallique, salle."""
    dur = 2.4
    n = n_of(dur)
    t = np.arange(n) / SR
    y = np.zeros(n)
    y[:n_of(0.006)] += _click(rng, 0.006, 1800, 14000) * 1.2
    f = _u(rng, 48, 58) + _u(rng, 60, 90) * np.exp(-t / 0.035)
    y += 1.1 * np.sin(2 * math.pi * np.cumsum(f) / SR) * np.exp(-t / (0.22 * weight))
    sub = np.sin(2 * math.pi * _u(rng, 36, 44) * t) * np.exp(-t / (0.9 * weight)) * (1 - np.exp(-t / 0.01))
    y += saturate(sub * 1.4, 4) * 0.8
    y += filt(white(n, rng), lp(450, 2)) * np.exp(-t / 0.12) * 0.7
    base = _u(rng, 180, 320)
    tail = _modal([base * r for r in (1, 2.32, 3.87, 5.4, 6.8)], [0.6, 0.45, 0.3, 0.2, 0.12],
                  [0.3, 0.22, 0.15, 0.1, 0.06], dur, rng)
    y += filt(tail, bp(150, 4000, 1)) * 0.35
    y = saturate(y, 3)
    return _finish(y, "hall", 0.35, int(rng.integers(1e6)), -1.0, 0.3, rng), 0.004


def sub_drop(rng):
    dur = _u(rng, 1.4, 2.2)
    t = t_axis(dur)
    f = 30 + (_u(rng, 95, 130) - 30) * np.exp(-t / (dur * 0.28))
    y = np.sin(2 * math.pi * np.cumsum(f) / SR) * (1 - np.exp(-t / 0.004)) * np.exp(-t / (dur * 0.45))
    y = saturate(y * 1.3, 5)
    y = filt(y, lp(260, 3))
    y[:n_of(0.004)] += _click(rng, 0.004, 800, 6000) * 0.3
    return _finish(y, "hall", 0.1, 5, -1.0), 0.003


def riser(rng, dur=None, cut=True):
    """Montée : bruit qui s'ouvre, accord de scies qui glisse d'une octave, trémolo qui accélère.
    Le pic (et la coupe nette) est à la fin : on cale la fin sur le mot clé."""
    dur = dur or _u(rng, 2.0, 3.5)
    n = n_of(dur)
    t = np.arange(n) / SR
    u = t / dur
    noise = stft_shape(pink(n, rng), band_gain(lambda tt: 250 * (30 ** np.clip(tt / dur, 0, 1)), 1.0), 1024, 256)
    root = _u(rng, 110, 160)
    tones = np.zeros(n)
    for k, ratio in enumerate((1, 1.5, 2, 3)):
        for det in (-0.006, 0.0, 0.007):
            f = root * ratio * (1 + det) * 2 ** (u ** 1.5)
            ph = 2 * math.pi * np.cumsum(f) / SR
            saw = sum(np.sin(h * ph) / h for h in range(1, 12) if root * ratio * 2 * h < 16000)
            tones += saw * (0.5 if k else 1.0)
    tones = filt(tones, lp(5000, 1))
    trem_rate = 3 + 17 * u ** 2
    trem = 0.75 + 0.25 * np.sin(2 * math.pi * np.cumsum(trem_rate) / SR)
    env = u ** 2.4
    y = (noise * 0.9 + tones * 0.06) * env * trem
    y = stereo(widen(y, 0.7, rng))
    rev = reverb(y, "hall", 0.4, 11, tail=not cut)
    y = rev[:n] if cut else rev
    y = fade(y, 0.05, 0.004 if cut else 0.4)
    return peak_normalize(y, -1.5), dur - 0.004


def reverse_swell(rng, dur=None):
    """Aspiration (impact inversé passé en réverbération), finit pile sur le pic."""
    a, _ = impact(rng, 0.8)
    r = reverb(a, "cathedral", 0.9, 21)[::-1]
    dur = dur or _u(rng, 1.0, 1.8)
    r = r[-n_of(dur):]
    return peak_normalize(fade(r, 0.2, 0.003), -2), dur - 0.003


def braam(rng, dur=None):
    """Note de cuivre grave saturée façon bande-annonce (cluster d'octaves + sub)."""
    dur = dur or _u(rng, 2.0, 3.0)
    t = t_axis(dur)
    f0 = _u(rng, 46, 58)
    y = np.zeros_like(t)
    for ratio, a in ((1, 1), (2, 0.7), (3, 0.35), (1.5, 0.3)):
        for det in (-0.004, 0.0, 0.005):
            ph = 2 * math.pi * f0 * ratio * (1 + det) * t
            y += a * sum(np.sin(h * ph) / h ** 1.1 for h in range(1, 30) if f0 * ratio * h < 9000)
    env = adsr(len(t), 0.06, 0.4, 0.6, dur * 0.55)
    bright = np.exp(-t / 0.5)
    y = filt(y * env, lp(1400, 2)) * (0.6 + 0.4 * bright)
    y = saturate(y / (np.max(np.abs(y)) + 1e-9) * 1.5, 6)
    return _finish(widen(y, 0.5, rng), "hall", 0.35, 31, -1.0), 0.06


# ======================================================================= UI / graphics

def pop(rng, kind="pop"):
    dur = 0.25
    t = t_axis(dur)
    if kind == "bubble":
        f = _u(rng, 350, 500) * (1 + 1.4 * (1 - np.exp(-t / 0.02)))
    else:
        f = _u(rng, 260, 380) + _u(rng, 500, 900) * np.exp(-t / 0.012)
    y = np.sin(2 * math.pi * np.cumsum(f) / SR) * np.exp(-t / _u(rng, 0.03, 0.05))
    y[:n_of(0.002)] += _click(rng, 0.002, 2000, 9000) * 0.4
    return _finish(y, "room", 0.12, 2, -3.0), 0.002


def tick(rng):
    """Petit son discret pour chaque révélation de motion."""
    dur = 0.12
    t = t_axis(dur)
    f = _u(rng, 1400, 2600)
    y = np.sin(2 * math.pi * f * t) * np.exp(-t / 0.012) + 0.4 * np.sin(2 * math.pi * f * 2.01 * t) * np.exp(-t / 0.006)
    y[:n_of(0.0015)] += _click(rng, 0.0015, 3000, 12000) * 0.3
    return _finish(pan(y, _u(rng, -0.3, 0.3)), "room", 0.1, 4, -6.0), 0.001


def glitch(rng, dur=None):
    """Glitch numérique : grains bégayés, réduction de bits, échantillonnage bloqué, pan aléatoire."""
    dur = dur or _u(rng, 0.4, 0.6)
    n = n_of(dur)
    src_n = n_of(0.3)
    t = np.arange(src_n) / SR
    src = (np.sign(np.sin(2 * math.pi * _u(rng, 300, 900) * t)) * 0.4 + white(src_n, rng) * 0.3
           + np.sin(2 * math.pi * _u(rng, 2000, 5000) * t) * 0.4)
    out = np.zeros((n, 2))
    pos = 0
    while pos < n:
        g = n_of(_u(rng, 0.012, 0.06))
        s = int(rng.integers(0, src_n - g)) if src_n > g else 0
        grain = src[s:s + g]
        reps = int(rng.integers(1, 4))
        grain = np.tile(grain, reps)
        grain = bitcrush(grain, int(rng.integers(3, 7)), int(rng.integers(1, 9)))
        grain = fade(grain, 0.0005, 0.001)
        mix_into(out, pan(grain, _u(rng, -0.9, 0.9)) * _u(rng, 0.4, 1.0), pos)
        pos += len(grain) + (n_of(_u(rng, 0, 0.02)) if rng.random() < 0.3 else 0)
    out = filt(out, chain(hp(120, 1), bell(3000, 3, 1.5)))
    return peak_normalize(fade(out, 0.001, 0.02), -3), 0.0


def hud_beep(rng):
    dur = 0.35
    t = t_axis(dur)
    a, b = _u(rng, 1500, 2000), _u(rng, 2200, 2900)
    y = np.zeros_like(t)
    for i, f in enumerate((a, b)):
        s = n_of(0.07 * i)
        tt = t[: len(t) - s]
        y[s:] += np.sin(2 * math.pi * f * tt) * np.exp(-tt / 0.05) * (tt < 0.06)
    return _finish(y, "room", 0.15, 6, -6.0), 0.0


def scan(rng):
    dur = _u(rng, 0.7, 1.1)
    t = t_axis(dur)
    f = 400 * (8 ** (t / dur))
    y = np.sin(2 * math.pi * np.cumsum(f) / SR) * (0.6 + 0.4 * np.sign(np.sin(2 * math.pi * 24 * t)))
    y = filt(y, lp(6000, 1)) * np.sin(np.pi * t / dur)
    y += filt(white(len(t), rng), bp(4000, 9000, 2)) * 0.08 * np.sin(np.pi * t / dur)
    return _finish(pan(y, np.linspace(-0.7, 0.7, len(t))), "room", 0.1, 7, -5.0), dur * 0.5


def mouse_click(rng):
    out = np.zeros(n_of(0.15))
    for k, at in enumerate((0.0, _u(rng, 0.06, 0.09))):
        c = _modal([_u(rng, 2600, 3400), _u(rng, 5200, 6800)], [0.004, 0.002], [1, 0.5], 0.02, rng)
        c[:n_of(0.0008)] += _click(rng, 0.0008, 2000, 14000)
        mix_into(out, c * (1 if k == 0 else 0.6), n_of(at))
    return _finish(out, "room", 0.05, 8, -6.0), 0.0


def ding(rng, good=True):
    """Ding de validation (FM, deux notes ascendantes) ; good=False : une note descendante feutrée."""
    out = np.zeros(n_of(1.6))
    base = mtof(int(rng.integers(84, 89)))
    notes = (base, base * (2 ** (7 / 12) if good else 2 ** (-3 / 12)))
    for i, f in enumerate(notes):
        t = t_axis(1.4)
        idx = 2.0 * np.exp(-t / 0.08)
        y = np.sin(2 * math.pi * f * t + idx * np.sin(2 * math.pi * f * 3.5 * t)) * np.exp(-t / 0.45)
        mix_into(out, y * (0.8 if i == 0 else 1.0), n_of(0.085 * i))
    return _finish(out, "plate", 0.25, 9, -3.0, 0.4, rng), 0.0


def buzzer(rng):
    """Buzzer d'erreur : deux scies désaccordées, filtrées, saturées, double coup."""
    out = np.zeros(n_of(0.8))
    f = _u(rng, 120, 160)
    for k, (at, ln) in enumerate(((0.0, 0.17), (0.22, 0.3))):
        t = t_axis(ln)
        y = sum(np.sin(2 * math.pi * f * d * h * t) / h for d in (1, 1.03) for h in range(1, 40) if f * h < 12000)
        y = saturate(filt(y, bp(300, 2500, 2)) * 0.3, 8) * adsr(len(t), 0.004, 0.02, 0.9, 0.03)
        mix_into(out, y, n_of(at))
    return _finish(out, "room", 0.12, 10, -2.0), 0.0


def notif_bell(rng):
    dur = 1.8
    f0 = _u(rng, 1300, 1700)
    y = _modal([f0 * r for r in (1, 2.0, 2.76, 5.4, 8.93)], [0.9, 0.6, 0.45, 0.2, 0.08],
               [1, 0.5, 0.35, 0.2, 0.1], dur, rng)
    t = t_axis(dur)
    y *= 1 - 0.25 * (np.sin(2 * math.pi * 11 * t) * np.exp(-t / 0.4)) ** 2
    y[:n_of(0.002)] += _click(rng, 0.002, 2000, 12000) * 0.3
    return _finish(y, "room", 0.2, 12, -3.0, 0.3, rng), 0.0


# ======================================================================= money / paper

def coins(rng, count=None, spread=0.45):
    out = np.zeros(n_of(spread + 0.6))
    for _ in range(count or int(_u(rng, 8, 16))):
        f0 = _u(rng, 2800, 5200)
        g = _modal([f0, f0 * 2.4, f0 * 3.9], [0.12, 0.08, 0.04], [1, 0.5, 0.25], 0.4, rng)
        mix_into(out, g * _u(rng, 0.2, 0.7), n_of(_u(rng, 0, spread) ** 1.3 / spread ** 0.3))
    return out


def cha_ching(rng):
    """Caisse enregistreuse : mécanique du tiroir, deux cloches, pièces qui roulent."""
    out = np.zeros(n_of(2.0))
    mech = filt(white(n_of(0.09), rng), bp(300, 3000, 1)) * exp_decay(n_of(0.09), 0.02)
    for k in range(4):
        mix_into(out, _click(rng, 0.006, 800, 6000) * 0.6, n_of(0.018 * k))
    mix_into(out, mech * 0.5, 0)
    hit = n_of(0.11)
    for j, f0 in enumerate((_u(rng, 2000, 2400), _u(rng, 2500, 2900))):
        b = _modal([f0 * r for r in (1, 2.0, 2.76, 5.4)], [0.8, 0.5, 0.3, 0.12], [1, 0.45, 0.3, 0.15], 1.6, rng)
        mix_into(out, b * 0.8, hit + n_of(0.07 * j))
    mix_into(out, coins(rng) * 0.35, hit + n_of(0.05))
    drawer = filt(brown(n_of(0.25), rng), lp(600, 2)) * np.sin(np.linspace(0, math.pi, n_of(0.25))) * 0.6
    mix_into(out, drawer, hit + n_of(0.02))
    return _finish(widen(out, 0.4, rng), "room", 0.15, 13, -1.5), 0.11


def money_rustle(rng, dur=None):
    dur = dur or _u(rng, 1.0, 1.6)
    n = n_of(dur)
    out = np.zeros(n)
    k = 0
    while k < n:
        g = n_of(_u(rng, 0.004, 0.03))
        grain = filt(white(g, rng), bp(_u(rng, 900, 2500), _u(rng, 4000, 9000), 1)) * np.hanning(g)
        mix_into(out, grain * _u(rng, 0.2, 1.0), k)
        k += n_of(_u(rng, 0.002, 0.02))
    out *= 0.6 + 0.4 * smooth_random(n, 6, rng)
    out = fade(out, 0.05, 0.25)
    return _finish(widen(out, 0.8, rng), "room", 0.1, 14, -4.0), dur * 0.3


def paper(rng):
    a, p = money_rustle(rng, _u(rng, 0.4, 0.7))
    s, _ = swipe(rng)
    out = np.zeros((max(len(a), len(s)), 2))
    mix_into(out, a, 0)
    mix_into(out, filt(s, lp(5000, 1)) * 0.5, 0)
    return peak_normalize(out, -5), p


# ======================================================================= mechanical / workshop

def ratchet(rng, clicks=None):
    rate = _u(rng, 16, 24)
    count = clicks or int(_u(rng, 8, 14))
    out = np.zeros(n_of(count / rate + 0.3))
    f0 = _u(rng, 2000, 2600)
    for k in range(count):
        c = _modal([f0, f0 * 1.78, f0 * 2.6, 380], [0.012, 0.008, 0.005, 0.02], [1, 0.6, 0.4, 0.5], 0.06, rng, 0.02)
        c[:n_of(0.001)] += _click(rng, 0.001, 1000, 12000)
        mix_into(out, c * _u(rng, 0.7, 1.0), n_of(k / rate + _u(rng, -0.003, 0.003)))
    return _finish(out, "garage", 0.12, 15, -3.0), 0.0


def wrench_clink(rng):
    f0 = _u(rng, 700, 1100)
    y = _modal([f0 * r for r in (1, 2.756, 5.404, 8.933)], [0.5, 0.3, 0.15, 0.07], [1, 0.6, 0.35, 0.2], 1.2, rng)
    y[:n_of(0.003)] += _click(rng, 0.003, 1500, 12000) * 0.8
    return _finish(y, "garage", 0.22, 16, -3.0), 0.0


def lock_click(rng):
    out = np.zeros(n_of(0.35))
    mix_into(out, _modal([1900, 3400], [0.01, 0.006], [1, 0.5], 0.04, rng), 0)
    thunk = np.sin(2 * math.pi * 140 * t_axis(0.12)) * exp_decay(n_of(0.12), 0.025)
    mix_into(out, thunk * 0.8 + _modal([2600, 4100], [0.012, 0.007], [0.7, 0.4], 0.12, rng), n_of(_u(rng, 0.05, 0.08)))
    return _finish(out, "room", 0.1, 17, -3.0), 0.06


def impact_gun(rng):
    """Clé à chocs pneumatique : rafale de frappes + sifflement d'air."""
    dur = _u(rng, 0.7, 1.1)
    n = n_of(dur)
    rate = _u(rng, 18, 26)
    out = np.zeros(n)
    k = 0
    while k / rate < dur - 0.1:
        h = _modal([_u(rng, 900, 1300), _u(rng, 2300, 2900)], [0.015, 0.01], [1, 0.5], 0.05, rng, 0.03)
        h[:n_of(0.001)] += _click(rng, 0.001, 600, 10000)
        mix_into(out, h * _u(rng, 0.6, 1.0), n_of(k / rate))
        k += 1
    air = filt(white(n, rng), bp(2500, 9000, 1)) * 0.25 * adsr(n, 0.02, 0.1, 0.8, 0.25)
    motor = np.sign(np.sin(2 * math.pi * rate * 6 * t_axis(dur))) * 0.08
    out = out + air + filt(motor, lp(1500, 2))
    return _finish(out, "garage", 0.15, 18, -2.0), 0.02


def car_door(rng):
    out = np.zeros(n_of(0.9))
    t = t_axis(0.5)
    thump = np.sin(2 * math.pi * np.cumsum(70 + 60 * np.exp(-t / 0.02)) / SR) * exp_decay(len(t), 0.09)
    body = filt(white(len(t), rng), lp(500, 2)) * exp_decay(len(t), 0.05)
    mix_into(out, thump + body * 0.6, 0)
    mix_into(out, _modal([1700, 2900, 4100], [0.02, 0.012, 0.008], [0.6, 0.4, 0.2], 0.08, rng), n_of(0.008))
    return _finish(out, "room", 0.08, 19, -2.0), 0.0


def key_jingle(rng):
    return _finish(widen(coins(rng, int(_u(rng, 14, 22)), 0.6), 0.6, rng), "room", 0.1, 20, -5.0), 0.05


# ======================================================================= automotive

def _engine(rng, rpm_curve, cyl=4, roughness=0.15, exhaust=180.0):
    """Moteur : train d'explosions à la fréquence d'allumage, résonance d'échappement, mécanique."""
    n = len(rpm_curve)
    fire = rpm_curve / 60.0 * cyl / 2.0
    phase = np.cumsum(fire) / SR
    idx = np.nonzero(np.diff(np.floor(phase)) > 0)[0]
    pulse_len = n_of(0.03)
    pulse = filt(white(pulse_len, rng), lp(900, 2)) * np.exp(-np.arange(pulse_len) / (pulse_len / 6))
    out = np.zeros(n + pulse_len)
    for k, i in enumerate(idx):
        out[i:i + pulse_len] += pulse * (1 + roughness * rng.standard_normal()) * (1.0 if k % cyl else 1.12)
    out = out[:n]
    h = sum(np.sin(2 * math.pi * hk * phase) / hk for hk in (1, 2, 3, 4))
    out = out * 0.8 + h * 0.25
    out = filt(out, chain(bell(exhaust, 6, 1.2), lp(2600, 2), hp(28, 2)))
    mech = filt(white(n, rng), bp(1200, 5000, 1)) * 0.03 * (rpm_curve / rpm_curve.max())
    return saturate(out * 0.8 + mech, 3)


def engine_rev(rng):
    dur = _u(rng, 2.4, 3.2)
    n = n_of(dur)
    u = np.arange(n) / n
    peak_rpm = _u(rng, 4200, 6200)
    rpm = 850 + (peak_rpm - 850) * np.where(u < 0.35, (u / 0.35) ** 0.7, np.exp(-(u - 0.35) * 5))
    y = _engine(rng, rpm)
    return _finish(fade(y, 0.05, 0.3), "room", 0.06, 22, -1.5, 0.2, rng), dur * 0.35


def starter(rng, catch=True):
    """Démarreur qui lance le moteur, puis le moteur prend (ralenti qui se stabilise)."""
    crank = _u(rng, 0.8, 1.4)
    n1 = n_of(crank)
    t = np.arange(n1) / SR
    pulses = 0.6 + 0.4 * np.sign(np.sin(2 * math.pi * _u(rng, 9, 13) * t))
    whine = sum(np.sin(2 * math.pi * _u(rng, 260, 320) * h * t) / h for h in range(1, 10))
    y1 = filt(whine * 0.4 * pulses + white(n1, rng) * 0.1 * pulses, bp(150, 4000, 1))
    if not catch:
        return _finish(fade(y1, 0.01, 0.1), "room", 0.06, 23, -2.0), 0.0
    n2 = n_of(2.2)
    u = np.arange(n2) / n2
    rpm = 820 + 900 * np.exp(-u * 4) * (1 - np.exp(-u * 40))
    y2 = _engine(rng, rpm)
    out = np.zeros(n1 + n2)
    out[:n1] += y1
    mix_into(out, y2 / (np.max(np.abs(y2)) + 1e-9), n1 - n_of(0.05))
    return _finish(fade(out, 0.01, 0.4), "room", 0.06, 24, -1.5, 0.2, rng), crank


def turbo(rng):
    """Turbo : sifflement qui monte, puis soupape de décharge (pschhh)."""
    spool = _u(rng, 1.2, 1.8)
    n = n_of(spool)
    t = np.arange(n) / SR
    f = 2500 + 6500 * (t / spool) ** 1.4
    whistle = np.sin(2 * math.pi * np.cumsum(f) / SR) * (t / spool) ** 2 * 0.25
    whistle += stft_shape(white(n, rng), band_gain(lambda tt: 2500 + 6500 * np.clip(tt / spool, 0, 1) ** 1.4, 4), 512, 128) * 0.3 * (t / spool) ** 2
    bov_n = n_of(0.7)
    bov = filt(white(bov_n, rng), chain(hp(1800, 2), bell(4500, 4, 1))) * np.exp(-np.arange(bov_n) / (0.12 * SR))
    bov *= 1 - np.exp(-np.arange(bov_n) / 60)
    out = np.zeros(n + bov_n)
    out[:n] += whistle
    out[n:] += bov * 0.9
    return _finish(widen(out, 0.4, rng), "room", 0.08, 25, -2.0), spool


def tire_squeal(rng):
    dur = _u(rng, 1.0, 1.6)
    n = n_of(dur)
    c = _u(rng, 1000, 1500)
    jit = smooth_random(n, 25, rng)
    t = np.arange(n) / SR
    f = c * (1 + 0.03 * jit) * (1 - 0.12 * t / dur)
    ph = 2 * math.pi * np.cumsum(f) / SR
    y = (np.sin(ph) + 0.35 * np.sin(2 * ph) + 0.15 * np.sin(3 * ph)) * (0.7 + 0.3 * smooth_random(n, 40, rng))
    y += filt(white(n, rng), bp(c * 0.8, c * 3, 2)) * 0.4
    y *= adsr(n, 0.05, 0.1, 0.9, 0.3)
    return _finish(y, "room", 0.06, 26, -3.0, 0.3, rng), 0.05


def turn_signal(rng, seconds=3.0):
    """Clignotant (relais) : tic-tac à ~1.5 Hz ; bouclable."""
    period = 1 / _u(rng, 1.35, 1.65)
    out = np.zeros(n_of(seconds))
    k = 0
    while k * period < seconds - 0.1:
        for j, (f, at) in enumerate(((_u(rng, 2200, 2600), 0.0), (_u(rng, 1100, 1400), period / 2))):
            c = _modal([f, f * 1.9, 420], [0.01, 0.006, 0.015], [1, 0.4, 0.5], 0.05, rng, 0.01)
            c[:n_of(0.001)] += _click(rng, 0.001, 1500, 10000) * 0.5
            mix_into(out, c * (1 if j == 0 else 0.8), n_of(k * period + at))
        k += 1
    return _finish(out, "room", 0.08, 27, -6.0), 0.0


def oil_pour(rng):
    """Versement d'huile : glouglous (bulles résonnantes) + filet liquide."""
    dur = _u(rng, 1.6, 2.4)
    n = n_of(dur)
    out = filt(brown(n, rng), bp(150, 1800, 1)) * 0.25 * (0.7 + 0.3 * smooth_random(n, 8, rng))
    k = n_of(0.05)
    while k < n - n_of(0.1):
        d = _u(rng, 0.03, 0.07)
        tt = t_axis(d)
        f = _u(rng, 180, 420) * (1 + 1.2 * tt / d)
        b = np.sin(2 * math.pi * np.cumsum(f) / SR) * np.sin(np.pi * tt / d) ** 2
        mix_into(out, b * _u(rng, 0.3, 0.8), k)
        k += n_of(_u(rng, 0.06, 0.2))
    return _finish(fade(out, 0.05, 0.25), "room", 0.1, 28, -4.0), 0.1


# ======================================================================= registry

CATALOGUE = {
    # nom: (fonction, famille de pack S1..S5, usage)
    "whoosh": (lambda r: whoosh(r), "S1", "carte titre, mot clé, transition"),
    "whoosh_deep": (lambda r: whoosh(r, weight="deep"), "S4", "zoom traversant, entrée de motion"),
    "whoosh_bright": (lambda r: whoosh(r, weight="bright", sparkle=True), "S1", "flash, light leak"),
    "whip": (whip, "S1", "whip pan"),
    "swoosh_soft": (swoosh_soft, "S1", "light leak, entrée/sortie douce de motion"),
    "light_flash": (light_flash, "S1", "flash lumineux"),
    "swipe": (swipe, "S1", "étiquette qui glisse"),
    "impact": (impact, "S4", "carte titre, chiffre choc, punch-in"),
    "sub_drop": (sub_drop, "S4", "ouverture, début d'acte, révélation"),
    "riser": (riser, "S4", "2-4 s avant un tournant (fin calée sur le mot)"),
    "reverse_swell": (reverse_swell, "S4", "aspiration avant une carte ou un impact"),
    "braam": (braam, "S4", "moment le plus fort de l'accroche"),
    "pop": (pop, "S1", "mot qui apparaît, flèche, cercle"),
    "bubble_pop": (lambda r: pop(r, "bubble"), "S1", "bulle de pensée"),
    "tick": (tick, "S3", "révélation interne d'un motion (discret)"),
    "glitch": (glitch, "S3", "carte titre glitch, mot choc"),
    "hud_beep": (hud_beep, "S3", "étiquette HUD, voyant"),
    "scan": (scan, "S3", "rayons X, balayage"),
    "mouse_click": (mouse_click, "S3", "bouton abonnement, capture"),
    "ding": (ding, "S3", "bonne habitude, solution"),
    "ding_low": (lambda r: ding(r, False), "S3", "constat négatif doux"),
    "buzzer": (buzzer, "S3", "NOT TRUE, MYTH, mauvaise habitude"),
    "notif_bell": (notif_bell, "S3", "cloche abonnement"),
    "cha_ching": (cha_ching, "S5", "prix géant"),
    "money_rustle": (money_rustle, "S5", "pluie de billets"),
    "paper": (paper, "S2", "document, manuel, facture"),
    "coins": (lambda r: (peak_normalize(stereo(coins(r)), -4), 0.0), "S5", "pièces, économies"),
    "ratchet": (ratchet, "S2", "geste d'atelier, cliquet"),
    "wrench_clink": (wrench_clink, "S2", "outil posé, clé"),
    "lock_click": (lock_click, "S2", "verrou, clip, raccord"),
    "impact_gun": (impact_gun, "S2", "clé à chocs, roue"),
    "car_door": (car_door, "S5", "portière"),
    "key_jingle": (key_jingle, "S5", "clés de voiture"),
    "engine_rev": (engine_rev, "S5", "moteur qui monte en régime"),
    "starter": (starter, "S5", "démarrage"),
    "starter_fail": (lambda r: starter(r, False), "S5", "démarrage raté"),
    "turbo": (turbo, "S5", "turbo"),
    "tire_squeal": (tire_squeal, "S5", "crissement, freinage"),
    "turn_signal": (turn_signal, "S5", "clignotant"),
    "oil_pour": (oil_pour, "S2", "versement d'huile, liquide"),
}


def make(name: str, rng) -> tuple[np.ndarray, float]:
    fn = CATALOGUE[name][0]
    a, p = fn(rng)
    return stereo(a).astype(np.float64), float(p)
