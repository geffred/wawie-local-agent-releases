"""Falcon 1 — outils locaux de la niche automobile.

  python3 -m falcon1 version
  python3 -m falcon1 tirage --run-id R --titre "T" [--registre ~/falcon1/registre_variations_auto.json]
  python3 -m falcon1 son --cues cues.json --out sortie/ [--format flac|m4a|mp3|wav]
  python3 -m falcon1 sons                       (liste des sons disponibles)
  python3 -m falcon1 annexe <nom>               (affiche une annexe : son, motion3d, elements, sources, script)
  python3 -m falcon1 demo --out demo/           (pack de sons + 60 s de mixage de démonstration)
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

VERSION = "3.0.0"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main(argv=None):
    ap = argparse.ArgumentParser(prog="falcon1")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("version")
    t = sub.add_parser("tirage")
    t.add_argument("--run-id", required=True)
    t.add_argument("--titre", required=True)
    t.add_argument("--registre", default=os.path.expanduser("~/falcon1/registre_variations_auto.json"))
    t.add_argument("--sans-ecrire", action="store_true")
    s = sub.add_parser("son")
    s.add_argument("--cues", required=True)
    s.add_argument("--out", required=True)
    s.add_argument("--format", default="flac", choices=["flac", "m4a", "mp3", "wav"])
    sub.add_parser("sons")
    a = sub.add_parser("annexe")
    a.add_argument("nom")
    d = sub.add_parser("demo")
    d.add_argument("--out", required=True)
    d.add_argument("--direction", default="D4")
    args = ap.parse_args(argv)

    if args.cmd == "version":
        print(VERSION)
    elif args.cmd == "tirage":
        from .variation import tirer
        print(json.dumps(tirer(args.run_id, args.titre, args.registre, not args.sans_ecrire), ensure_ascii=False))
    elif args.cmd == "son":
        from .mix import build
        with open(args.cues, encoding="utf-8") as f:
            cues = json.load(f)
        t0 = time.time()
        m = build(cues, args.out, os.path.dirname(os.path.abspath(args.cues)), args.format)
        r = m["rapport"]
        print(json.dumps({"fichiers": m["fichiers"], "sfx_heros": len(m["storyboard"]["sfx_heros"]),
                          "moments_par_minute": r["moments_sonores_par_minute"],
                          "stems": [{k: x[k] for k in ("stem", "lufs", "true_peak_dbtp")} for x in r["stems"]],
                          "problemes": r["problemes"], "secondes": round(time.time() - t0, 1),
                          "manifeste": os.path.join(args.out, "manifeste.json")}, ensure_ascii=False))
    elif args.cmd == "sons":
        from .sfx import CATALOGUE
        from .ambiences import AMBIENCES
        print("SONS:", "; ".join(f"{k} [{v[1]}] {v[2]}" for k, v in CATALOGUE.items()))
        print("AMBIANCES:", ", ".join(AMBIENCES))
        print("HUMEURS D'ACTE: tension, sombre, positif, resolution")
    elif args.cmd == "annexe":
        p = os.path.join(ROOT, "annexes", args.nom + ".md")
        if not os.path.exists(p):
            print("annexes :", ", ".join(sorted(x[:-3] for x in os.listdir(os.path.join(ROOT, "annexes")))))
            return 1
        with open(p, encoding="utf-8") as f:
            print(f.read())
    elif args.cmd == "demo":
        from .demo import run
        run(args.out, args.direction)
    return 0


if __name__ == "__main__":
    sys.exit(main())
