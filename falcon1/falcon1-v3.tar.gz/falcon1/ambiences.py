"""Ambiances bouclables synthétisées (lits de 40 s par défaut, boucle sans couture par fondu croisé)."""
from __future__ import annotations

import math

import numpy as np

from .dsp import (SR, n_of, t_axis, stereo, mono, pan, fade, peak_normalize, smooth_random, white, pink, brown,
                  filt, lp, hp, bp, bell, chain, stft_shape, band_gain, widen, reverb, mix_into, match_lufs, moving_average)
from . import sfx


def _u(rng, a, b):
    return float(rng.uniform(a, b))


def _bed(n, rng, slope, shape, mod_rate=0.15, mod_depth=0.25):
    x = filt(np.stack([pink(n, rng) if slope == 1 else brown(n, rng), pink(n, rng) if slope == 1 else brown(n, rng)], 1), shape)
    m = 1 + mod_depth * smooth_random(n, mod_rate, rng)
    return x * m[:, None]


def _sprinkle(out, rng, maker, every, gain_db, space="garage", pan_range=0.8, wet=0.3):
    n = len(out)
    pos = n_of(_u(rng, 0.3, every[1]))
    while pos < n - n_of(1.0):
        a, _ = maker(rng)
        a = reverb(a, space, wet, int(rng.integers(1e6)))
        a = filt(a, lp(_u(rng, 3000, 7000), 1))
        p = _u(rng, -pan_range, pan_range)
        m = mono(a)
        mix_into(out, pan(m, p), pos, 10 ** (gain_db / 20) * _u(rng, 0.6, 1.0))
        pos += n_of(_u(rng, *every))


def _loop(x, xf=2.0):
    """Rend la fin raccord avec le début (fondu croisé à puissance constante)."""
    k = n_of(xf)
    head, body, tail = x[:k], x[k:-k] if len(x) > 2 * k else x, x[-k:]
    w = np.sin(np.linspace(0, math.pi / 2, k))[:, None]
    joined = tail * np.cos(np.linspace(0, math.pi / 2, k))[:, None] + head * w
    return np.concatenate([joined, body])


def workshop(rng, n):
    out = _bed(n, rng, 1, chain(lp(2200, 2), hp(60, 2)), 0.1, 0.15) * 0.05
    t = np.arange(n) / SR
    hum_f = _u(rng, 27, 33)
    comp = sum(np.sin(2 * math.pi * hum_f * h * t + h) / h for h in range(1, 12))
    on = (smooth_random(n, 0.05, rng) > 0.1).astype(float)
    on = moving_average(on, n_of(0.5))
    out += stereo(filt(comp, lp(350, 2)) * on * 0.02)
    radio = np.zeros(n)
    k = 0
    while k < n:
        d = n_of(_u(rng, 0.15, 0.45))
        f = sfx.mtof(int(rng.integers(55, 72)))
        tt = np.arange(d) / SR
        radio[k:k + d] += (np.sin(2 * math.pi * f * tt) + 0.5 * np.sin(4 * math.pi * f * tt))[: n - k] * np.hanning(d)[: n - k]
        k += d
    out += pan(filt(radio, bp(500, 2500, 2)) * 0.008, 0.6)
    _sprinkle(out, rng, sfx.wrench_clink, (3.0, 8.0), -30)
    _sprinkle(out, rng, sfx.ratchet, (6.0, 14.0), -32)
    _sprinkle(out, rng, sfx.impact_gun, (12.0, 25.0), -36)
    return out


def cabin(rng, n):
    out = _bed(n, rng, 2, chain(lp(260, 2), hp(25, 2)), 0.2, 0.2) * 0.25
    roar = _bed(n, rng, 1, bp(350, 1100, 2), 0.3, 0.3) * 0.05
    wind = _bed(n, rng, 1, bp(900, 3500, 1), 0.4, 0.5) * 0.02
    t = np.arange(n) / SR
    rpm = 2000 * (1 + 0.03 * smooth_random(n, 0.1, rng))
    ph = np.cumsum(rpm / 60 * 2) / SR
    drone = filt(sum(np.sin(2 * math.pi * h * ph) / h for h in (1, 2, 3)), lp(300, 2)) * 0.03
    out = out + roar + wind + stereo(drone)
    pos = n_of(_u(rng, 1, 5))
    while pos < n - n_of(1):
        th = filt(white(n_of(0.12), rng), lp(150, 2)) * np.exp(-np.arange(n_of(0.12)) / 900)
        mix_into(out, th * 0.25, pos)
        mix_into(out, th * 0.2, pos + n_of(_u(rng, 0.08, 0.12)))
        pos += n_of(_u(rng, 4, 9))
    return out


def highway(rng, n):
    out = _bed(n, rng, 1, chain(lp(1800, 2), hp(40, 2)), 0.1, 0.15) * 0.06
    pos = n_of(_u(rng, 0, 1))
    while pos < n:
        d = _u(rng, 2.5, 4.5)
        m = n_of(d)
        truck = rng.random() < 0.25
        lo, hi = (80, 900) if truck else (200, 2500)
        u = np.arange(m) / m
        env = np.exp(-((u - 0.5) / 0.18) ** 2)
        body = filt(pink(m, rng), bp(lo, hi, 2)) * env
        f0 = _u(rng, 500, 900)
        dop = f0 * (1 + 0.06 * np.tanh((0.5 - u) * 8))
        whine = np.sin(2 * math.pi * np.cumsum(dop) / SR) * env * 0.08
        dirn = 1 if rng.random() < 0.5 else -1
        mix_into(out, pan(body + whine, dirn * (u * 1.6 - 0.8)), pos, (0.35 if truck else 0.22) * _u(rng, 0.6, 1))
        pos += n_of(_u(rng, 1.2, 3.5))
    return out


def parking(rng, n):
    out = _bed(n, rng, 1, chain(lp(1200, 2), hp(50, 2)), 0.08, 0.2) * 0.035
    out += _bed(n, rng, 1, bp(2000, 8000, 1), 0.2, 0.3) * 0.004
    _sprinkle(out, rng, sfx.car_door, (6, 15), -28, "garage", 0.9, 0.35)
    _sprinkle(out, rng, lambda r: sfx.hud_beep(r), (10, 22), -36, "garage", 0.9, 0.4)
    _sprinkle(out, rng, sfx.key_jingle, (9, 20), -38, "room", 0.7, 0.2)
    return out


def garage_closed(rng, n):
    out = _bed(n, rng, 1, chain(lp(900, 2), hp(40, 2)), 0.05, 0.1) * 0.02
    t = np.arange(n) / SR
    mains = 50 if rng.random() < 0.5 else 60
    hum = sum(np.sin(2 * math.pi * mains * 2 * h * t + h) / h ** 1.5 for h in range(1, 8))
    buzz = filt(np.sign(np.sin(2 * math.pi * mains * 2 * t)), bp(2000, 6000, 1)) * 0.004
    out += stereo((hum * 0.006 + buzz) * (1 + 0.1 * smooth_random(n, 0.3, rng)))

    def drip(r):
        tt = t_axis(0.08)
        y = np.sin(2 * math.pi * np.cumsum(_u(r, 900, 1400) * (1 + 0.6 * tt / 0.08)) / SR) * np.exp(-tt / 0.015)
        return y, 0.0
    _sprinkle(out, rng, drip, (3, 9), -30, "garage", 0.6, 0.45)
    return out


def winter(rng, n):
    nz = np.stack([pink(n, rng), pink(n, rng)], 1)
    cen = lambda t: 700 + 330 * np.sin(2 * math.pi * 0.07 * t + 1.3) + 160 * np.sin(2 * math.pi * 0.17 * t)
    w = np.stack([stft_shape(nz[:, c], band_gain(cen, 1.2), 2048, 512) for c in range(2)], 1)
    gust = 0.55 + 0.45 * smooth_random(n, 0.25, rng)
    out = filt(w, lp(3500, 1)) * gust[:, None] * 0.06
    out += _bed(n, rng, 2, lp(120, 2), 0.1, 0.3) * 0.05
    return out


def gas_station(rng, n):
    out = _bed(n, rng, 1, chain(lp(1500, 2), hp(50, 2)), 0.1, 0.2) * 0.035
    t = np.arange(n) / SR
    pump = sum(np.sin(2 * math.pi * 120 * h * t) / h for h in range(1, 6)) + 0.3 * np.sin(2 * math.pi * 980 * t)
    on = (smooth_random(n, 0.06, rng) > -0.2).astype(float)
    on = moving_average(on, n_of(0.3))
    out += pan(filt(pump, lp(1500, 2)) * on * 0.006, -0.4)
    _sprinkle(out, rng, sfx.lock_click, (7, 16), -32, "room", 0.8, 0.2)
    _sprinkle(out, rng, lambda r: sfx.ding(r), (15, 30), -40, "garage", 0.8, 0.4)
    out += highway(rng, n) * 0.25
    return out


AMBIENCES = {
    "atelier": (workshop, -38.0),
    "habitacle": (cabin, -34.0),
    "autoroute": (highway, -34.0),
    "parking": (parking, -40.0),
    "garage_ferme": (garage_closed, -44.0),
    "hiver": (winter, -38.0),
    "station_service": (gas_station, -38.0),
}


def make(name: str, rng, seconds: float = 40.0) -> np.ndarray:
    """Lit d'ambiance bouclable, à son niveau de référence (LUFS de tableau ci-dessus)."""
    fn, lufs = AMBIENCES[name]
    n = n_of(seconds + 2.0)
    x = stereo(fn(rng, n))
    x = widen(mono(x), 0.5, rng) * 0.4 + x * 0.6
    x = _loop(x, 2.0)
    return match_lufs(x, lufs)
